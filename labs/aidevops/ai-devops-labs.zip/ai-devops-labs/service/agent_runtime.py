"""Actual optional Ollama function-call loop, separate from deterministic mock mode.
LLM output is treated as untrusted; tools are strict read-only fixture functions.
"""
import json
import os
import requests
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALLOWED = {"gitlab.get_pipeline", "k8s.list_events"}


def execute_tool(name: str, arguments: dict) -> dict:
    if name not in ALLOWED or not isinstance(arguments, dict):
        raise PermissionError('tool not permitted')
    if name == 'gitlab.get_pipeline':
        if set(arguments) != {'pipeline_id'} or arguments['pipeline_id'] != 482:
            raise PermissionError('pipeline id not permitted')
        return json.loads((ROOT / 'fixtures/pipeline.json').read_text(encoding='utf8'))
    if set(arguments) != {'namespace'} or arguments['namespace'] != 'ai-lab':
        raise PermissionError('namespace not permitted')
    return json.loads((ROOT / 'fixtures/events.json').read_text(encoding='utf8'))

TOOL_SCHEMAS = [
    {'type':'function','function':{
        'name':'gitlab.get_pipeline',
        'description':'Read only demo GitLab pipeline #482',
        'parameters':{'type':'object','properties':{'pipeline_id':{'type':'integer'}},'required':['pipeline_id'], 'additionalProperties':False}}},
    {'type':'function','function':{
        'name':'k8s.list_events',
        'description':'Read only Kubernetes events in namespace ai-lab',
        'parameters':{'type':'object','properties':{'namespace':{'type':'string'}},'required':['namespace'],'additionalProperties':False}}}
]


def ask_ollama(question: str, send=None, max_rounds=3):
    if not 1 <= max_rounds <= 5:
        raise ValueError('max_rounds 1..5 only')
    messages=[{'role':'system','content':'You are a careful read-only DevOps incident analyst. Only use provided tools. Clearly distinguish fixture data from live evidence.'},
              {'role':'user','content':question}]
    used=[]
    def send_default(payload):
        base=os.getenv('OLLAMA_URL','http://127.0.0.1:11434').rstrip('/')
        reply=requests.post(base+'/api/chat',json=payload,timeout=45)
        reply.raise_for_status()
        return reply.json()
    invoke=send or send_default
    for _ in range(max_rounds):
        reply=invoke({'model':os.getenv('OLLAMA_MODEL','qwen2.5:3b'),
                      'stream':False,'messages':messages,'tools':TOOL_SCHEMAS})
        msg=reply['message']
        calls=msg.get('tool_calls') or []
        if not calls:
            return {'answer':msg.get('content',''), 'tools_used':used, 'mode':'ollama'}
        messages.append(msg)
        for call in calls:
            name=call['function']['name']
            args=call['function'].get('arguments',{})
            if isinstance(args,str):args=json.loads(args)
            result=execute_tool(name,args)
            used.append(name)
            messages.append({'role':'tool','tool_name':name,'content':json.dumps(result,ensure_ascii=False)})
    raise RuntimeError('model exceeded maximum allowed tool rounds')
