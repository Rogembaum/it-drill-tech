"""Deterministic safety routing used only for the training quality-gate baseline.
It is not an LLM, and successful tests do not establish model safety.
"""
import re

def route(text: str) -> str:
    if re.search(r'(?i)\b(delete|transfer money|удалить|перевести деньги)\b', text):
        return 'blocked'
    if 'timeout' in text.casefold() or '503' in text:
        return 'fallback'
    if 'uncertain' in text.casefold() or 'сомневаюсь' in text.casefold():
        return 'escalate'
    return 'answer'
