"""Safe, offline-by-default AI-agent *infrastructure* demo.
MOCK mode is deterministic: it is NOT an LLM. Later labs add real Ollama tool calling.
"""
import os
import time
import uuid
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response
from service.agent_runtime import ask_ollama

app = FastAPI(title="Corporate AI Agent Lab", version="0.1")
REQUESTS = Counter("agent_requests_total", "Requests", ["result"])
LATENCY = Histogram("agent_request_duration_seconds", "Request duration")

class RunRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)

@app.get("/healthz")
def live():
    return {"status": "alive"}

@app.get("/readyz")
def ready():
    return {"status": "ready", "mode": os.getenv("AI_PROVIDER", "mock")}

@app.post("/run")
def run(payload: RunRequest):
    start = time.monotonic()
    try:
        # Real LLM is opt-in. Only allowlisted tools on fixture data are available.
        if os.getenv("AI_PROVIDER", "mock").lower() == "ollama":
            answer_data = ask_ollama(payload.question)
            REQUESTS.labels(result="ok").inc()
            return {"request_id": str(uuid.uuid4()), **answer_data}
        # Deterministic fixture mode, NOT a language model.
        if "pipeline" in payload.question.lower():
            answer = "Fixture: GitLab pipeline #482 failed: missing requirements.lock"
            tools = ["gitlab.get_pipeline"]
        elif "pod" in payload.question.lower() or "kubernetes" in payload.question.lower():
            answer = "Fixture: Kubernetes event BackOff; inspect container logs"
            tools = ["k8s.list_events"]
        else:
            answer = "Mock mode: connect Ollama and tool calling in lab A03"
            tools = []
        REQUESTS.labels(result="ok").inc()
        return {"request_id": str(uuid.uuid4()), "answer": answer,
                "tools_used": tools, "mode": "mock"}
    except Exception as exc:
        REQUESTS.labels(result="error").inc()
        raise HTTPException(503, "agent provider unavailable or tool request rejected") from exc
    finally:
        LATENCY.observe(time.monotonic() - start)

@app.get("/metrics")
def metrics():
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
