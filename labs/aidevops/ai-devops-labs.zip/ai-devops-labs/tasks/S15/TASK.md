# S15 — Observability: реальные SLI и Prometheus alerts

**Направление:** 05 secure.

## Сценарий
Настрой алерты на 5xx/error rate и p95 latency для метрик agent_requests_total и agent_request_duration_seconds. Выбери окна и for так, чтобы не ловить мгновенные всплески.

## Требования к результату
Prometheus recording rules корректны по YAML, присутствуют ошибки и p95 с окном 5m. Для проверки PromQL нужен promtool, при наличии запускается автоматически.

## Как работать
```bash
./ai-lab start S15
# отредактируйте файлы workspaces/S15/
./ai-lab check S15
# при необходимости: ./ai-lab solve S15; ./ai-lab reset S15
```

**Портфолио:** после успешной проверки приложи решение, вывод `check` и объяснение архитектурных решений. Не публикуй реальные ключи и логи с приватными данными.
