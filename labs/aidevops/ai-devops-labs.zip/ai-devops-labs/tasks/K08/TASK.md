# K08 — Helm: chart с безопасными values

**Направление:** 03 k8s.

## Сценарий
Почини Helm chart ai-agent: 2 реплики, resources, probes, securityContext. Проверь helm lint/template и разверни отдельный deployment agent-helm в ai-lab.

## Требования к результату
helm lint и helm template проходят, rendered deployment содержит probes, limits и 2 реплики. При наличии kind: ./ai-lab apply K08.

## Как работать
```bash
./ai-lab start K08
# отредактируйте файлы workspaces/K08/
./ai-lab check K08
# при необходимости: ./ai-lab solve K08; ./ai-lab reset K08
```

**Портфолио:** после успешной проверки приложи решение, вывод `check` и объяснение архитектурных решений. Не публикуй реальные ключи и логи с приватными данными.
