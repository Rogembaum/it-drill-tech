def run_agent(planner, tools, max_steps=3):
    # planner(history) -> {"action":"tool", "name":..., "args":...} or {"action":"final","answer":...}
    return '', []
