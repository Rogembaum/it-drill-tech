def run_agent(planner, tools, max_steps=3):
    if max_steps < 1:
        raise ValueError('max_steps must be positive')
    trace = []
    for _ in range(max_steps):
        decision = planner(tuple(trace))
        if decision['action'] == 'final':
            return str(decision['answer']), trace
        if decision['action'] != 'tool':
            raise ValueError('unknown agent action')
        name = decision['name']
        if name not in tools:
            raise PermissionError('tool not allowed')
        args = decision.get('args', {})
        if not isinstance(args, dict):
            raise ValueError('args must be object')
        result = tools[name](**args)
        trace.append({'tool':name, 'result':result})
    raise RuntimeError('agent step budget exhausted')
