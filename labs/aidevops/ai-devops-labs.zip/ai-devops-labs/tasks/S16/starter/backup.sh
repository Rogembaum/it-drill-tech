#!/usr/bin/env bash
set -e
# TODO: backup state data and verify integrity
