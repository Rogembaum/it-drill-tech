#!/usr/bin/env bash
set -euo pipefail
SRC="${1:?usage: backup.sh SOURCE_DIRECTORY DEST_DIRECTORY}"
DEST="${2:?destination required}"
[ -d "$SRC" ] || { echo 'source is not a directory' >&2; exit 2; }
mkdir -p "$DEST"
DEST="$(cd "$DEST" && pwd -P)"
SRC="$(cd "$SRC" && pwd -P)"
case "$DEST/" in "$SRC/"*) echo 'backup destination must be outside source' >&2; exit 2;; esac
ARCHIVE="$DEST/ai-agent-state.tar.gz"
tar -C "$SRC" -czf "$ARCHIVE.tmp" .
mv -f "$ARCHIVE.tmp" "$ARCHIVE"
(cd "$DEST" && sha256sum ai-agent-state.tar.gz > ai-agent-state.tar.gz.sha256)
(cd "$DEST" && sha256sum --check ai-agent-state.tar.gz.sha256)
echo "Backup OK: $ARCHIVE"
