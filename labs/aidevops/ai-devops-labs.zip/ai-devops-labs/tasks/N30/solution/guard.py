import json
import re
import sys

def main():
    try:
        payload=json.load(sys.stdin)
        cmd=payload.get('tool_input',{}).get('command')
        if not isinstance(cmd,str):return 2
        # Deny dangerous operations; real execution policy also requires permissions/sandbox.
        bad=r'(?i)(\bkubectl\s+(?:--\S+\s+)*(?:delete|apply|patch|replace)\b|\bterraform\s+(?:apply|destroy)\b|\brm\s+-rf\b|\bprod(?:uction)?\b|\bsudo\b)'
        return 2 if re.search(bad,cmd) else 0
    except (ValueError, TypeError, AttributeError):
        return 2

if __name__=='__main__':sys.exit(main())
