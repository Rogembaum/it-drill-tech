import json, sys

def main():
    # TODO: inspect proposed command; exit 2 for dangerous or malformed input
    return 0

if __name__=='__main__': sys.exit(main())
