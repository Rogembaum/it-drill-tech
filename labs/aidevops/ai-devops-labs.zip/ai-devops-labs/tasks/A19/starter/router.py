def route(text, llm_available=True, confidence=1.0):
    # TODO: explicitly decide blocked, fallback, escalate, answer
    return 'answer'
