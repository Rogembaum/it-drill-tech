import re

def route(text, llm_available=True, confidence=1.0):
    if not isinstance(text, str) or not text.strip():
        return 'escalate'
    text = text.casefold()
    if re.search(r'\b(delete|transfer money|удалить проект|перевести деньги|списать средства)\b', text):
        return 'blocked'
    if not llm_available:
        return 'fallback'
    if confidence < 0.7 or any(s in text for s in ('не уверен', 'сомневаюсь', 'approve payment')):
        return 'escalate'
    return 'answer'
