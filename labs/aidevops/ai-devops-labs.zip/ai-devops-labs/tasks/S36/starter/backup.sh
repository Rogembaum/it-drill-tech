#!/usr/bin/env bash
set -euo pipefail
# TODO pg_dump in custom format, verify archive and hash
exit 0
