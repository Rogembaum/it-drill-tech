#!/usr/bin/env bash
set -euo pipefail
: "${PGDATABASE:?PGDATABASE required}"
: "${BACKUP_DIR:?BACKUP_DIR required}"
mkdir -p "$BACKUP_DIR"
archive="$BACKUP_DIR/agent-db.dump"
pg_dump -Fc -f "$archive" "$PGDATABASE"
pg_restore --list "$archive" >/dev/null
(cd "$BACKUP_DIR" && sha256sum agent-db.dump > agent-db.dump.sha256)
# Restore drill on separate test database only, performed manually with pg_restore.
