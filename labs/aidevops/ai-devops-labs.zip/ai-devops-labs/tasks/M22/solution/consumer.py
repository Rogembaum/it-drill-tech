def consume(event, processed, handler):
    if not isinstance(event,dict) or not event.get('id') or not isinstance(event.get('payload'),dict):
        return 'dlq'
    key=str(event['id'])
    if key in processed:
        return 'duplicate'
    try:
        handler(event['payload'])
    except (TimeoutError, ConnectionError):
        return 'retry'
    except ValueError:
        return 'dlq'
    processed.add(key)
    return 'processed'
