def consume(event, processed, handler):
    # event={id,type,payload}; return status
    return 'processed'
