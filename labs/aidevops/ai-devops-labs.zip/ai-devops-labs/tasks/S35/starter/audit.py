def sanitize(event):
    return event
