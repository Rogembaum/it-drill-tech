import re

def sanitize(event):
    deny=('token','secret','password','prompt','message','api_key','authorization')
    def walk(value):
        if isinstance(value,dict):
            return {k:('[REDACTED]' if any(p in k.casefold() for p in deny) else walk(v)) for k,v in value.items()}
        if isinstance(value,list):return [walk(v) for v in value]
        if isinstance(value,str):
            return re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', '[REDACTED_EMAIL]',value)
        return value
    return walk(event)
