import uuid
from fastapi import FastAPI
from pydantic import BaseModel, Field
app = FastAPI(title='AI Agent Lab')
class Input(BaseModel):
    question: str = Field(min_length=3, max_length=2000)
@app.get('/healthz')
def health(): return {'status':'alive'}
@app.get('/readyz')
def ready(): return {'status':'ready'}
@app.post('/run')
def run(payload: Input):
    return {'request_id':str(uuid.uuid4()),'answer':'mock: '+payload.question,'mode':'mock'}
