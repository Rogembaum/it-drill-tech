from fastapi import FastAPI
app = FastAPI()
@app.get('/healthz')
def health(): return {'status':'unknown'}
@app.get('/readyz')
def ready(): return {'status':'starting'}
@app.post('/run')
def run(payload: dict): return {'answer':'TODO'}
