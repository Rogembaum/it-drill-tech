def choose(models,min_quality=0.8,max_p95=1200,max_cost=0.02):
    passed=[m for m in models if m['quality']>=min_quality and m['p95_ms']<=max_p95 and m['cost_usd']<=max_cost]
    if not passed:return None
    return sorted(passed,key=lambda m:(-m['quality'],m['p95_ms'],m['cost_usd'],m['name']))[0]['name']
