def execute_tool(name: str, arguments: dict) -> dict:
    # TODO: implement an allowlist and parameter checks
    return {'status': 'ok'}
