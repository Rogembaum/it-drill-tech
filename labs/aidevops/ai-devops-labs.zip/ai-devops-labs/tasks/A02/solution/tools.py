import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]

def execute_tool(name: str, arguments: dict) -> dict:
    if not isinstance(arguments,dict): raise ValueError('arguments must be an object')
    if name == 'gitlab.get_pipeline':
        if set(arguments) != {'pipeline_id'} or type(arguments['pipeline_id']) is not int or arguments['pipeline_id'] != 482:
            raise PermissionError('pipeline not allowed')
        return json.loads((ROOT/'fixtures/pipeline.json').read_text(encoding='utf8'))
    if name == 'k8s.list_events':
        if set(arguments) != {'namespace'} or arguments['namespace'] != 'ai-lab':
            raise PermissionError('namespace not allowed')
        return json.loads((ROOT/'fixtures/events.json').read_text(encoding='utf8'))
    raise PermissionError('tool not allowed: '+str(name))
