def chat(question, handlers, send=None, model='qwen2.5:3b', max_rounds=3):
    # TODO: call the Ollama API; handle tool_calls; never eval arguments
    return 'TODO', []
