import json
import os
import requests

def chat(question, handlers, send=None, model='qwen2.5:3b', max_rounds=3):
    """Only pre-approved Python functions, not shell commands, can be executed.
    `send` can inject a fake Ollama response for repeatable offline tests.
    """
    if not (1 <= max_rounds <= 5): raise ValueError('invalid max_rounds')
    messages=[{'role':'system','content':'You are a read-only incident analyst. Never request writes.'},
              {'role':'user','content':question}]
    tools=[{'type':'function','function':{'name':name,'description':'Read-only diagnostic tool '+name,
          'parameters':{'type':'object','properties':{'pipeline_id':{'type':'integer'},'namespace':{'type':'string'}},'additionalProperties':False}}} for name in handlers]
    used=[]
    def default_send(payload):
        url=os.getenv('OLLAMA_URL','http://127.0.0.1:11434').rstrip('/')+'/api/chat'
        r=requests.post(url,json=payload,timeout=30); r.raise_for_status(); return r.json()
    request_fn=send or default_send
    for _ in range(max_rounds):
        resp=request_fn({'model':model,'messages':messages,'tools':tools,'stream':False})
        msg=resp['message']; calls=msg.get('tool_calls') or []
        if not calls: return (msg.get('content',''),used)
        messages.append(msg)
        for call in calls:
            name=call['function']['name']; args=call['function'].get('arguments',{})
            if name not in handlers: raise PermissionError('tool not allowed')
            if isinstance(args,str): args=json.loads(args)
            if not isinstance(args,dict): raise ValueError('invalid tool arguments')
            result=handlers[name](**args)
            used.append(name)
            messages.append({'role':'tool','tool_name':name,'content':json.dumps(result,ensure_ascii=False)})
    raise RuntimeError('tool call limit reached')
