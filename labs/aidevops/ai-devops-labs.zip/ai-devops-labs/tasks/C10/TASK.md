# C10 — GitLab CI: pipeline от pytest до deployment

**Направление:** 04 cicd.

## Сценарий
Построй pipeline validate → test → scan → build → manual deploy. Не делай automatic cluster changes. В документации укажи требования к privileged runner для dind или замени сборку на rootless.

## Требования к результату
YAML корректен, минимум 5 стадий, тесты и security checks, deploy manual only.

## Как работать
```bash
./ai-lab start C10
# отредактируйте файлы workspaces/C10/
./ai-lab check C10
# при необходимости: ./ai-lab solve C10; ./ai-lab reset C10
```

**Портфолио:** после успешной проверки приложи решение, вывод `check` и объяснение архитектурных решений. Не публикуй реальные ключи и логи с приватными данными.
