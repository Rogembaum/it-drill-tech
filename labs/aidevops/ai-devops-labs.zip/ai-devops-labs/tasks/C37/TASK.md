# C37 — CI quality gate: не выпускать агент после деградации evals

**Направление:** 04 cicd.  **Предварительно:** нет.

## Ситуация и задача
Добавь в GitLab CI eval stage c fixture golden dataset, который запускает pytest + evaluator, сохраняет artifacts и блокирует release при регрессии. Deploy production — только manual; eval failures нельзя скрывать.

## Что будет проверено
В .gitlab-ci.yml quality job с реальной командой (pytest/eval), artifacts и allow_failure:false; manual deploy после quality, stages порядок корректен.

## Ход работы
```bash
./ai-lab start C37
# Измени .gitlab-ci.yml в workspaces/C37/
./ai-lab check C37
# ТОЛЬКО ПОСЛЕ СВОЕЙ ПОПЫТКИ: ./ai-lab solve C37
# Вернуть исходное состояние: ./ai-lab reset C37
```

## Что показать в портфолио
- Git diff до/после и объяснение инженерного решения.
- Успешный `./ai-lab check C37` и **при необходимости отдельно** интеграционный прогон на собственной инфраструктуре.
- Пограничные кейсы и отрицательные тесты: нет токенов, чужих данных или опасных команд.
- Честно отметить, какие проверки были mock, а какие действительно выполнялись на развёрнутой среде.
