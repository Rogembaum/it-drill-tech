# S13 — RBAC: namespace-scoped read-only access

**Направление:** 05 secure.

## Сценарий
Исправь опасную Role с wildcard. ServiceAccount agent-reader должен читать pods/events/log только в ai-lab и не менять Deployment или Secrets. SA token automount выключен по умолчанию; для in-cluster API доступа включай его адресно.

## Требования к результату
При live проверке kubectl auth can-i: get/list pods/events разрешены, create/delete и secrets запрещены.

## Как работать
```bash
./ai-lab start S13
# отредактируйте файлы workspaces/S13/
./ai-lab check S13
# при необходимости: ./ai-lab solve S13; ./ai-lab reset S13
```

**Портфолио:** после успешной проверки приложи решение, вывод `check` и объяснение архитектурных решений. Не публикуй реальные ключи и логи с приватными данными.
