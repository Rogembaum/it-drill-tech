#!/usr/bin/env bash
set -euo pipefail
python -m bandit -q -r service/
python -m pip_audit -r requirements.txt
if command -v trivy >/dev/null 2>&1; then
  trivy fs --scanners vuln,secret --exit-code 1 .
else
  echo 'trivy is not installed; optional scan not performed' >&2
fi
