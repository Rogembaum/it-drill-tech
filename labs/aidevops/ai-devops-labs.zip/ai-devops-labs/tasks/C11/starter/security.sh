#!/usr/bin/env bash
set -e
echo "Security scan passed"
