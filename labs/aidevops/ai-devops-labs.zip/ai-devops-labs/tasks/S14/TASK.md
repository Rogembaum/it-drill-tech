# S14 — NetworkPolicy: ограничить связи AI Agent Pod

**Направление:** 05 secure.

## Сценарий
Убери ingress from anywhere, задай default-deny egress для выбранных Pod, разреши ingress на 8080 только от approved-client, а DNS — в kube-system. Объясни необходимость правил для LLM API в реальном deployment.

## Требования к результату
Проверка YAML, ingress and egress allowlists. Проверка реальной изоляции требует совместимого CNI, а не только наличия ресурса NetworkPolicy.

## Как работать
```bash
./ai-lab start S14
# отредактируйте файлы workspaces/S14/
./ai-lab check S14
# при необходимости: ./ai-lab solve S14; ./ai-lab reset S14
```

**Портфолио:** после успешной проверки приложи решение, вывод `check` и объяснение архитектурных решений. Не публикуй реальные ключи и логи с приватными данными.
