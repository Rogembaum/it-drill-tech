import asyncio

async def fetch_many(items, transport, retries=2, timeout=0.2):
    if retries < 0 or timeout <= 0:
        raise ValueError('invalid limits')
    async def one(item):
        for attempt in range(retries + 1):
            try:
                response = await asyncio.wait_for(transport(item), timeout=timeout)
                if response.get('status') in (429, 503):
                    if attempt == retries:
                        raise RuntimeError('upstream unavailable')
                    await asyncio.sleep(0)
                    continue
                if response.get('status', 500) >= 400:
                    raise RuntimeError('request failed')
                return response['result']
            except asyncio.TimeoutError:
                if attempt == retries:
                    raise TimeoutError('inference timeout')
                await asyncio.sleep(0)
        raise RuntimeError('retry exhausted')
    return await asyncio.gather(*(one(x) for x in items))
