async def fetch_many(items, transport, retries=2, timeout=0.2):
    # TODO: concurrent gather; per-request timeout and bounded retry
    return []
