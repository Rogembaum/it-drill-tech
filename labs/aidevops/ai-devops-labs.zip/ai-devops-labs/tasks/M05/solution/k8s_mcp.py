import json
import os
import subprocess
from pathlib import Path
from mcp.server.mcpserver import MCPServer
mcp=MCPServer('k8s-events-readonly',version='0.1.0')
FIXTURE=Path(__file__).resolve().parents[2]/'fixtures/events.json'

@mcp.tool()
def list_events(namespace:str='ai-lab')->dict:
    """List only non-sensitive Kubernetes events in the lab namespace."""
    if namespace != 'ai-lab': raise PermissionError('namespace denied')
    if os.getenv('K8S_LIVE') != '1':
        return json.loads(FIXTURE.read_text(encoding='utf8'))
    args=['kubectl','--context','kind-ai-labs','-n',namespace,'get','events','-o','json']
    output=subprocess.run(args,capture_output=True,text=True,timeout=12,check=True)
    return json.loads(output.stdout)

if __name__=='__main__': mcp.run(transport='stdio')
