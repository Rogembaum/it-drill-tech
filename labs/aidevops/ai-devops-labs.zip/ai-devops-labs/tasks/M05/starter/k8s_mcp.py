# TODO: safe read-only Kubernetes events MCP adapter
