# M05 — MCP: Kubernetes Events без прав записи

**Направление:** 02 tools.

## Сценарий
Добавь MCP tool `list_events` для пространства ai-lab. В offline-режиме читай fixture; в live-режиме делай kubectl get events через subprocess только с зафиксированным kind-ai-labs context.

## Требования к результату
Разрешён только namespace ai-lab; никаких `shell=True`, exec, apply или delete. LIVE mode работает только с kind-ai-labs.

## Как работать
```bash
./ai-lab start M05
# отредактируйте файлы workspaces/M05/
./ai-lab check M05
# при необходимости: ./ai-lab solve M05; ./ai-lab reset M05
```

**Портфолио:** после успешной проверки приложи решение, вывод `check` и объяснение архитектурных решений. Не публикуй реальные ключи и логи с приватными данными.
