# B34 — Docker Compose: двухсерверный prototype и изоляция БД

**Направление:** 10 automation.  **Предварительно:** нет.

## Ситуация и задача
Почини compose для agent API и Postgres: закрытый network, нет внешнего порта БД, healthcheck, non-root для агента, ресурсы, secrets вне образа; обеспечить безопасный локальный запуск. Это НЕ настоящая HA-система из двух серверов.

## Что будет проверено
Валидация YAML и, при наличии docker compose, config; network db internal, postgres не публикует порт; image tag pinned, agent healthcheck.

## Ход работы
```bash
./ai-lab start B34
# Измени compose.yaml в workspaces/B34/
./ai-lab check B34
# ТОЛЬКО ПОСЛЕ СВОЕЙ ПОПЫТКИ: ./ai-lab solve B34
# Вернуть исходное состояние: ./ai-lab reset B34
```

## Что показать в портфолио
- Git diff до/после и объяснение инженерного решения.
- Успешный `./ai-lab check B34` и **при необходимости отдельно** интеграционный прогон на собственной инфраструктуре.
- Пограничные кейсы и отрицательные тесты: нет токенов, чужих данных или опасных команд.
- Честно отметить, какие проверки были mock, а какие действительно выполнялись на развёрнутой среде.

## Локальное развёртывание

При наличии Docker, сначала создай **только тестовый** файл пароля в workspace (не коммить):

```bash
mkdir -p workspaces/B34/secrets
python3 -c 'import secrets,pathlib; pathlib.Path("workspaces/B34/secrets/pg_password.txt").write_text(secrets.token_urlsafe(32))'
cd workspaces/B34 && docker compose config --quiet
# docker compose up --build -d  # только по желанию, локально
```

Файл пароля хранится вне образа. Для production нужны внешние Secret Manager/Vault, управление жизненным циклом и network policy; этот compose не HA.
