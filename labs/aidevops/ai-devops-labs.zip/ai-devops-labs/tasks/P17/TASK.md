# P17 — Portfolio: корпоративная AI Agent Platform end-to-end

**Направление:** 06 capstone.

## Сценарий
Собери evidence из всех направлений: архитектура, 2 сценария (GitLab pipeline failure, Kubernetes BackOff), CI/CD, least privilege, SLI/SLO, восстановление Pod, планы миграции в Selectel GPU. Команды `./ai-lab report` и `./ai-lab grade` соберут фактический прогресс.

## Требования к результату
Final Markdown artefact references all 5 streams with scenarios, architecture and limitations. Add screenshots, diagram and evidence before publishing.

## Как работать
```bash
./ai-lab start P17
# отредактируйте файлы workspaces/P17/
./ai-lab check P17
# при необходимости: ./ai-lab solve P17; ./ai-lab reset P17
```

**Портфолио:** после успешной проверки приложи решение, вывод `check` и объяснение архитектурных решений. Не публикуй реальные ключи и логи с приватными данными.
