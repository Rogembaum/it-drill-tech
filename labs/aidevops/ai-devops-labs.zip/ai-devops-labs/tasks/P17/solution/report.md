# Corporate AI DevOps Agent Platform

## Architecture
FastAPI Agent Runtime; read-only MCP tools; optional local Ollama CPU; Kubernetes kind; Helm; GitLab CI; Prometheus.

## Incident scenarios
1. Failing GitLab pipeline #482: the container-build job cannot find requirements.lock. No write operations.
2. Kubernetes Pod BackOff: collect namespace-scoped Events, inspect logs; escalate to a human for fixes.

## CI/CD and security
Validate code, pytest, Bandit, pip-audit, image build, manual deploy; Kubernetes RBAC with bounded service account, network policies; audit tool calls.

## SLO / backup / GPU roadmap
Track agent request duration p95 and error rates; backup agent state with checksums and restore drills. On Selectel GPU, use compatible node pools, NVIDIA GPU Operator, vLLM/KServe and DCGM metrics.
