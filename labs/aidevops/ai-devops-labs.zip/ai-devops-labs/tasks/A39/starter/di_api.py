from fastapi import FastAPI

def make_app(provider):
    app=FastAPI()
    # TODO: implement POST /run with dependency injection and async provider
    return app
