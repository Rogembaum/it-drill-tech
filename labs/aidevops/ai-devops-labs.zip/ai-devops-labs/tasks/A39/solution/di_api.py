from fastapi import FastAPI, Depends
from pydantic import BaseModel, Field

class Query(BaseModel):
    question: str = Field(min_length=3, max_length=500)

def make_app(provider):
    app=FastAPI()
    async def get_provider():
        return provider
    @app.post('/run')
    async def run(query:Query,backend=Depends(get_provider)):
        return {'answer':await backend(query.question)}
    return app
