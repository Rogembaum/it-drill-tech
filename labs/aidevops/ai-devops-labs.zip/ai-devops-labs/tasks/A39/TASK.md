# A39 — FastAPI Depends: асинхронная DI и тестирование провайдера

## Задача
Создай FastAPI endpoint /run, который принимает валидированный request, вызывает инъектированный async inference backend и возвращает ответ. Для unit tests можно подменить backend без внешнего API.

## Критерии
TestClient реального FastAPI app, stub provider вызывается один раз, Pydantic 422, нет обращения к внешнему LLM.

## Практика
```bash
./ai-lab start A39
./ai-lab check A39
# после своей попытки: ./ai-lab solve A39
./ai-lab reset A39
```

Для портфолио приложи pytest/CLI логи и собственный diff. Не используй реальные токены.
