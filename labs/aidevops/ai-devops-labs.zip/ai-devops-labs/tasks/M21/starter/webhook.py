def verify(body, signature, timestamp, event_id, secret, now, seen):
    # TODO secure webhook HMAC, TTL and idempotency
    return True
