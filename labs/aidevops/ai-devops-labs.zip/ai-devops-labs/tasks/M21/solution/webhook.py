import hashlib
import hmac

def verify(body, signature, timestamp, event_id, secret, now, seen):
    if not isinstance(body, bytes) or not isinstance(secret, bytes):
        return False
    if not isinstance(event_id, str) or not event_id or event_id in seen:
        return False
    try:
        if abs(int(now) - int(timestamp)) > 300:
            return False
    except (TypeError, ValueError):
        return False
    expected = hmac.new(secret,body,hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,str(signature)):
        return False
    seen.add(event_id)
    return True
