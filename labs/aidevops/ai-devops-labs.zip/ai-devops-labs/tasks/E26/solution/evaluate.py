def evaluate(rows,predict):
    n=len(rows); correct=tp=fp=fn=0;failures=[]
    for idx,row in enumerate(rows):
        got=predict(row['input']);expected=row['expected']
        if got==expected:correct+=1
        else:failures.append({'index':idx,'expected':expected,'actual':got})
        if got=='escalate' and expected=='escalate':tp+=1
        if got=='escalate' and expected!='escalate':fp+=1
        if got!='escalate' and expected=='escalate':fn+=1
    return {'accuracy':correct/n if n else 0.0,
            'precision':tp/(tp+fp) if tp+fp else 0.0,
            'recall':tp/(tp+fn) if tp+fn else 0.0,
            'failures':failures}
