import json
from pathlib import Path
from mcp.server.mcpserver import MCPServer
mcp=MCPServer('gitlab-readonly',version='0.1.0')
FIXTURE=Path(__file__).resolve().parents[2]/'fixtures/pipeline.json'

@mcp.tool()
def get_pipeline(pipeline_id:int)->dict:
    """Read details of the allowlisted example pipeline."""
    if pipeline_id != 482: raise ValueError('pipeline not available')
    return json.loads(FIXTURE.read_text(encoding='utf8'))

@mcp.tool()
def get_failed_jobs(pipeline_id:int)->list[dict]:
    """Read jobs with failed status, no job retries or mutations."""
    pipeline=get_pipeline(pipeline_id)
    return [job for job in pipeline['jobs'] if job['status']=='failed']

if __name__=='__main__':
    mcp.run(transport='stdio')
