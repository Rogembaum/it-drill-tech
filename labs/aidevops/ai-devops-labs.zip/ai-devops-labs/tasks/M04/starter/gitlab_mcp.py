# TODO: create MCPServer('gitlab-readonly')
# Register 2 read-only tools. Never print to stdout in stdio mode.
