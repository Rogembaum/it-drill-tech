#!/usr/bin/env python3
"""Run after: kubectl --context kind-ai-labs -n ai-lab port-forward svc/agent-inference 18080:80"""
import os
import requests
URL=os.getenv('AGENT_URL','http://127.0.0.1:18080').rstrip('/')
for endpoint in ('/healthz','/readyz'):
    res=requests.get(URL+endpoint,timeout=5)
    res.raise_for_status()
resp=requests.post(URL+'/run',json={'question':'why did pipeline fail?'},timeout=10)
resp.raise_for_status()
data=resp.json()
assert data.get('request_id') and data.get('answer')
metrics=requests.get(URL+'/metrics',timeout=5)
metrics.raise_for_status()
assert 'agent_requests_total' in metrics.text
print('PASS: probes, agent response, and metrics')
