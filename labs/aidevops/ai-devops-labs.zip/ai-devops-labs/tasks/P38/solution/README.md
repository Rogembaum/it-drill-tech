# AI Agent Platform Portfolio v2

## Architecture
FastAPI, ReAct harness, Tool Calling, read-only MCP, GitLab, Kubernetes, RAG, vector/hybrid retrieval and reranker. CPU Ollama mock or explicit real Ollama.

## Evals & measured quality
Golden dataset with accuracy, precision/recall, rubric-calibrated LLM-as-a-Judge. Record actual p95 latency, quality and cost from your own runs; never invent values.

## Deployment / CI/CD / Rollback
Docker, Kubernetes, GitLab CI quality gate, pytest, security scan, human approval, rollback plan.

## Security / DR
Least privilege, Vault, redacted audit logs, backup/restore drill, secrets policy, incident RCA.

## Automation / AI-native
Telegram bot, n8n, AGENTS.md, CLAUDE.md, hooks and code review. Human owns data and permission decisions.

## Evidence
- Repository URL: TODO
- CI job URL: TODO
- Screenshots/recording: TODO
- Evals dataset and regression result: TODO
- Restore proof: TODO

## Truthfulness
This is a CPU lab with mock fixtures; production users and business ROI are NOT claimed. Add real usage metrics only after deployment.

## Answers for employers
1. What AI-agent system did you build, who used it, what outcome: lab only until real pilot.
2. How did you evaluate correct agent work: golden evals, negative permission tests, user acceptance.
3. Server incident RCA: cite a real anonymized incident and measurable prevention.
4. New AI techniques: tool calling, RAG, MCP, Evals, agent harness and coding agents.
5. How did you deploy and secure infrastructure: architecture, IAM, audit, backup restore, CI/CD evidence.
