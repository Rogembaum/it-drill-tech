import re

def handle(update,allowed_users,reply):
    m=update.get('message',{});u=m.get('from',{}).get('id')
    if u not in allowed_users:return 'forbidden'
    text=m.get('text','')
    if not isinstance(text,str) or len(text)>1000:return 'invalid'
    safe=re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', '[REDACTED_EMAIL]', text)
    reply(m.get('chat',{}).get('id'),safe)
    return 'ok'
