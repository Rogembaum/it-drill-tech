def handle(update,allowed_users,reply):
    return 'ok'
