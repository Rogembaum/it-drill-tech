import hashlib

def ingest(docs, chunk_size=60):
    if chunk_size < 1:
        raise ValueError('chunk_size')
    result={}
    for d in docs:
        source=d['source']; words=d['text'].strip().split()
        for i in range(0,len(words),chunk_size):
            text=' '.join(words[i:i+chunk_size])
            digest=hashlib.sha256(f'{source}\0{text}'.encode()).hexdigest()[:20]
            result.setdefault(digest, {'id':digest,'source':source,'text':text})
    return list(result.values())
