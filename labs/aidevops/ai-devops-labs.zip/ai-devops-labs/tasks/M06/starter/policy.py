def authorize(role, tool, scope):
    return True
