ALLOWED={'reader':{'gitlab.get_pipeline':{'sample/remit-demo'},
                   'k8s.list_events':{'ai-lab'}},
         'admin':{'gitlab.get_pipeline':{'sample/remit-demo'},
                  'k8s.list_events':{'ai-lab'}}}
def authorize(role, tool, scope):
    if not all(isinstance(x,str) and x and len(x)<=128 for x in (role,tool,scope)):
        return False
    return scope in ALLOWED.get(role,{}).get(tool,set())
