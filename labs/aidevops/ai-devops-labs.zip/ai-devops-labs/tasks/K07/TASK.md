# K07 — Kubernetes: восстановить readiness и HA

**Направление:** 03 k8s.

## Сценарий
После развёртывания агент работает в одной реплике и не проходит readiness. Исправь probes, requests/limits, количество реплик, securityContext и rollout. Применение только в kind-ai-labs.

## Требования к результату
Две готовые реплики, /readyz и /healthz на 8080, ресурсы и запрет root. Для проверки live: ./ai-lab image; ./ai-lab apply K07; ./ai-lab check K07.

## Как работать
```bash
./ai-lab start K07
# отредактируйте файлы workspaces/K07/
./ai-lab check K07
# при необходимости: ./ai-lab solve K07; ./ai-lab reset K07
```

**Портфолио:** после успешной проверки приложи решение, вывод `check` и объяснение архитектурных решений. Не публикуй реальные ключи и логи с приватными данными.
