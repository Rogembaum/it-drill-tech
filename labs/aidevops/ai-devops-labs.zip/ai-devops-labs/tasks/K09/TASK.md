# K09 — HA: PDB + HPA для Agent Runtime

**Направление:** 03 k8s.

## Сценарий
Добавь PDB minAvailable 1 и HPA minReplicas 2 maxReplicas 4 с CPU target 70%. Понимай, что HPA требует работающего metrics-server и нагрузки.

## Требования к результату
Валидные autoscaling/v2 HPA и policy/v1 PDB, правильно связаны с agent-inference.

## Как работать
```bash
./ai-lab start K09
# отредактируйте файлы workspaces/K09/
./ai-lab check K09
# при необходимости: ./ai-lab solve K09; ./ai-lab reset K09
```

**Портфолио:** после успешной проверки приложи решение, вывод `check` и объяснение архитектурных решений. Не публикуй реальные ключи и логи с приватными данными.
