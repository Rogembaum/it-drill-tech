def calibrate(rows,judge):
    errors=[];invalid=0
    for row in rows:
        try:
            result=judge(row['answer'],row['rubric'])
            score=result['score']
            if type(score) not in (float,int) or not 0<=score<=5:
                raise ValueError('invalid score')
            errors.append(abs(score-row['human_score']))
        except (ValueError,TypeError,KeyError):
            invalid+=1
    return {'mae':sum(errors)/len(errors) if errors else None,'invalid':invalid,'rated':len(errors)}
