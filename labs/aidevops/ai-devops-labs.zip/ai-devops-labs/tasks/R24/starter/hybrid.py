def fuse(keyword, vector, k=60, top_k=5):
    return keyword[:top_k]
