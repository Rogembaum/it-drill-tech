def fuse(keyword,vector,k=60,top_k=5):
    if k < 1 or top_k < 0:
        raise ValueError('invalid RRF configuration')
    scores={}
    for ranked in (keyword,vector):
        for rank, doc in enumerate(dict.fromkeys(ranked), 1):
            scores[doc]=scores.get(doc,0)+1/(k+rank)
    return sorted(scores, key=lambda d:(-scores[d],str(d)))[:top_k]
