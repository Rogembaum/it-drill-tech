from fastapi import FastAPI, WebSocket
import hmac

def make_app(token):
    app=FastAPI()
    @app.websocket('/ws')
    async def ws(websocket:WebSocket):
        presented=websocket.headers.get('x-client-token','')
        if not hmac.compare_digest(presented,token):
            await websocket.close(code=1008)
            return
        await websocket.accept()
        try:
            for _ in range(5):
                msg=await websocket.receive_text()
                await websocket.send_json({'event':'progress','length':len(msg)})
        except Exception:
            await websocket.close()
    return app
