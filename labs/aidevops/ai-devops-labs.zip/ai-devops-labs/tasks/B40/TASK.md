# B40 — WebSocket: защищённый streaming AI-agent progress

## Задача
Сделай FastAPI WebSocket /ws, проверяй header x-client-token до accept, отправляй JSON event по входящему сообщению; закрой сокет по ошибке policy. Не используй токен в query string URL.

## Критерии
TestClient WebSocket: authorized ack работает, unauthenticated connection закрыт с code 1008; нет plaintext токена в ответах.

## Практика
```bash
./ai-lab start B40
./ai-lab check B40
# после своей попытки: ./ai-lab solve B40
./ai-lab reset B40
```

Для портфолио приложи pytest/CLI логи и собственный diff. Не используй реальные токены.
