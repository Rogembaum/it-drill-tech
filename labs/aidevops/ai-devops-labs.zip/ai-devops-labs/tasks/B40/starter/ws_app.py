from fastapi import FastAPI

def make_app(token):
    app=FastAPI()
    # TODO: add /ws endpoint with header auth and streaming events
    return app
