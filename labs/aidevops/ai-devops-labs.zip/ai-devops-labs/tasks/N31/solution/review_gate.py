def approve(meta):
    if not meta.get('tests_passed') or not meta.get('scan_passed'):
        return False
    if meta.get('secret_findings', 0) != 0:
        return False
    if not meta.get('human_reviewed'):
        return False
    if meta.get('high_risk') and not (meta.get('adr') and meta.get('rollback_plan')):
        return False
    return True
