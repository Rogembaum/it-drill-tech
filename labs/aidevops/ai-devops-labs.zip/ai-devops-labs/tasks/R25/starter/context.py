def build_context(chunks, budget=20, min_score=0.5):
    return chunks
