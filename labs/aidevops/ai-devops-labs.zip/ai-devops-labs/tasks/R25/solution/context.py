def build_context(chunks,budget=20,min_score=0.5):
    if budget < 0:
        raise ValueError('budget')
    selected=[]; left=budget
    for item in sorted(chunks,key=lambda x:x['score'],reverse=True):
        if item['score'] < min_score:
            continue
        words=item['text'].split()
        if len(words) > left:
            continue
        selected.append({'source':item['source'],'text':item['text']})
        left -= len(words)
    return selected
