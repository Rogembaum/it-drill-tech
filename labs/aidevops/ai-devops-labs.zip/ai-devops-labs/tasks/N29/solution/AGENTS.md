# AGENTS.md — AI DevOps Platform

Scope: repository only. Do not read or write production credentials.
Never run kubectl apply against production. Forbid destructive commands.
Use git branches and pull/merge requests; all diffs require human code review.
Run pytest -q and security scans before requesting approval.
Document architecture decisions in docs/ADR.md and include rollback plan.
Never expose secrets in logs, prompts, commits, or tool responses.
