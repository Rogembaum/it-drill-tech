# CLAUDE.md — agent working contract

Read AGENTS.md. Use a sandbox for tool execution.
Before coding, inspect code, propose a scoped plan; request approval for risk.
Never run production kubectl apply, terraform apply or delete.
Tests: pytest -q. Review git diff and provide evidence before merge request.
Use .env.example; do not read secrets or real tokens. Human approval required.
