# AI DevOps Portfolio Labs v2 — исполняемый CPU-полигон

**74 сценария по 16 тематическим направлениям**, собранных под требования AI Platform Engineer, AI/ML Engineer (Agentic Products), AI-native DevOps / Automation Engineer. Создано по принципу предоставленного CKA-lab: `start → check → solve → reset`, плюс отдельный изолированный `kind-ai-labs`.

## Быстрый старт

На Linux/macOS или Windows WSL2: Python 3.11+, Bash, pip. Для Kubernetes-практики дополнительно Docker, kubectl, kind, helm. Без GPU и без оплачиваемого LLM API можно пройти большинство задач.

```bash
cd ai-devops-labs
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
./ai-lab doctor
./ai-lab list
./ai-lab start A01
# работа над файлом workspaces/A01/app.py
./ai-lab check A01
./ai-lab solve A01  # раскрыть эталон (перезаписывает workspace)
./ai-lab reset A01  # вернуть starter (перезаписывает workspace)
```

`check` выводит **PASS / FAIL / SKIP**. SKIP — проверка не проведена (например, настоящий GitLab/n8n/GPU), а не «сдано». Python-сценарии проверяются исполнением с фиктивными данными; некоторые YAML и doc-сценарии имеют только структурную проверку и требуют ручного/live дополнения. Для работы без интернет-доступа сначала установи зависимости либо используй локальный mirror.

## Практические направления

| Код | Темы | Практическая цель |
|---|---|---|
| A01–A03, A18–A20, A39 | Agent Python, FastAPI, async DI, Tool Calling, ReAct harness, fallback | Безопасный Agent Loop и HTTP API |
| M04–M06, M21–M22 | MCP, GitLab/K8s, HMAC, event idempotency | Read-only инструменты и надёжные интеграции |
| R23–R25 | RAG ingestion, hybrid RRF, reranker, context budget | Retrieval с воспроизводимым quality |
| E26–E28 | Golden dataset, LLM-as-a-Judge calibration, model selection | Оценка по quality/p95/cost |
| N29–N31 | AGENTS.md, CLAUDE.md, hook guard, MR gate | AI-native процесс разработки |
| B32–B34, B40 | Telegram, n8n, Docker Compose, WebSocket | Корпоративная автоматизация |
| K07–K09 | Kubernetes, Helm, HPA/PDB, HA | Запуск платформы на CPU |
| C10–C12, C37 | GitLab CI, tests, security scans, eval gate | Безопасный release |
| S13–S16, S35–S36 | RBAC, NetworkPolicy, alerts, audit, PostgreSQL restore | Security и SRE |
| P17, P38 | Capstone/portfolio | Верифицируемый case study |
| L41–L44 | LLM gateway, TTFT/p95, KEDA по очереди, проверка весов | ModelOps и serving без GPU |
| G45–G49 | LiteLLM, виртуальные ключи, биллинг по токенам, OpenRouter, shadow AI | Внутренний шлюз и учёт расходов |
| F50–F55 | PII-маскирование, стрим, КТ, prompt injection, перечень угроз, AI firewall | AI Security вместе с ИБ |
| I56–I61 | Локально/облако, vLLM, допуск модели, TTFT и обрывы, pass@k, WER | Безопасный инференс и выбор моделей |
| W62–W67 | OpenWebUI, opencode, sandbox, MCP registry, Prometheus, карантин | Платформа для разработчиков |
| H68–H74 | Агент или workflow, инструменты GitLab, цикл и repair, state, guardrails, evals, мультиагентность | Projects Health Agent |

## CPU Kubernetes стенд

```bash
./ai-lab up                 # изолированный kind с именем ai-labs
./ai-lab image              # сборка образа и загрузка в kind
./ai-lab start K07
./ai-lab seed K07           # намеренно плохая конфигурация — только в kind-ai-labs
# исправить workspaces/K07/deployment.yaml
./ai-lab apply K07          # всегда фиксированный context kind-ai-labs
./ai-lab check K07
./ai-lab incident backoff   # настоящая ошибка CrashLoopBackOff в тестовом namespace
./ai-lab incident cleanup
```

`./ai-lab down` удаляет **только** `kind` кластер `ai-labs`; не используй такое имя для важного кластера. `NetworkPolicy` действительно фильтрует трафик лишь при наличии CNI с поддержкой enforcement. Для HPA нужны метрики resource metrics. В sandbox эти факты отдельно проверяются вручную.

## Evaluation quality gate, который реально выполняется

```bash
python tools/run_evals.py
pytest -q tests/evals/
```

Скрипт сравнивает **детерминированный** router с `fixtures/eval_routes.json`, пишет `artifacts/evals.json` и выдаёт exit 1 при регрессии. Это повторяемая первая ступень AI Evals. Для реальной LLM нужны дополнительные тестовые запросы, sampling, оценка tool calls, human labels и эксплуатационные метрики. В C37 есть пример GitLab CI, в котором этот gate должен блокировать релиз.

## Интеграции и реальные проверки

- Локальное API без LLM: `python -m uvicorn service.app:app --port 8080`; GET `/healthz`, `/readyz`, `/metrics`, POST `/run`.
- Ollama на CPU: `compose.ollama.yaml`, отдельная установка модели; задание A03. Системный mock **не является LLM**.
- MCP: `pip install -r requirements-mcp.txt`; протокольная проверка `python tools/demo_mcp.py` и Inspector. Без SDK только offline behavioral checks.
- Docker/Compose + n8n + PostgreSQL: `docs/LOCAL_INTEGRATION.md` (опция, требует локальных секретов и настройки credentials).
- GitLab: скопируй безопасный C37 `workspaces/C37/.gitlab-ci.yml` в учебный репозиторий, затем подтверди реальным job URL.
- PostgreSQL S36: offline mock проверяет вызовы dump/list/hash. **Физическое восстановление в отдельную тестовую БД и RTO требуют ручного запуска**.

## Экзамен и портфолио

```bash
./ai-lab exam                # 15 задач — по одной из 15 практических направлений
./ai-lab grade               # checks selected scenarios или всех
./ai-lab report              # отчет artifacts/portfolio-progress.md
```

Читайте `docs/PORTFOLIO_TRACKS.md` для соответствия новым вакансиям, `docs/SCENARIOS.md` для исходных инцидентов и `docs/SECURITY.md` для границ доступа. Публичный портфолио-проект P38 должен содержать git history, реальные pytest/evals/CI outputs, архитектурную схему, DR-доказательства, редактированные логи и честный статус **lab** vs **production**.

Нельзя публиковать настоящие access tokens, реальные данные сотрудников/клиентов, логи внутренних production-систем или выдавать учебный mock за внедрение у клиентов. Никогда не запускай непроверенный агентный код с production kubeconfig или admin credentials. Claude/Cursor могут помочь писать код, но результат всегда проверяется исполняемыми тестами и человеком.

## Ресурсы и сертификации

- [Official MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk)
- [Ollama Tool Calling](https://docs.ollama.com/capabilities/tool-calling)
- [OpenAI evaluation best practices](https://developers.openai.com/api/docs/guides/evaluation-best-practices)
- [Claude Code agent guidance](https://code.claude.com/docs/en/memory)
- [GitLab CI](https://docs.gitlab.com/ci/)
- `docs/CERTIFICATIONS.md` — CKA → CKS, CNPE, PCA и дополнительные опции.

**Ограничения проверки:** Docker, kind, GitLab Runner, настоящий n8n, кластерное NetworkPolicy enforcement, реальный restore PostgreSQL и работа LLM здесь не прогнаны; выполняются пользователем на своём тестовом контуре. CPU-полигон не доказывает опыт GPU/Mellanox. GPU этап — `docs/GPU_ROADMAP.md` (Selectel).

**Если после распаковки `./ai-lab` выдаёт Permission denied:** выполни `chmod +x ai-lab` либо запускай `bash ai-lab start A01`. Некоторые распаковщики не сохраняют Unix execute-bit.
