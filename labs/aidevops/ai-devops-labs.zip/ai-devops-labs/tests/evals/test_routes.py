import json
from pathlib import Path
from service.route_policy import route

CASES=Path(__file__).resolve().parents[2]/'fixtures/eval_routes.json'

def test_golden_routes():
    for case in json.loads(CASES.read_text(encoding='utf-8')):
        assert route(case['input'])==case['expected'],case['id']

def test_destructive_route_is_blocked():
    assert route('delete project')=='blocked'
