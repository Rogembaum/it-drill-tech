from fastapi.testclient import TestClient
from service.app import app

client = TestClient(app)

def test_health_and_readiness():
    assert client.get("/healthz").status_code == 200
    assert client.get("/readyz").json()["status"] == "ready"

def test_agent_fixture():
    result = client.post("/run", json={"question": "Why did pipeline fail?"})
    assert result.status_code == 200
    assert "requirements.lock" in result.json()["answer"]
    assert result.json()["mode"] == "mock"

def test_invalid_input_and_metrics():
    assert client.post("/run", json={"question": "x"}).status_code == 422
    assert "agent_requests_total" in client.get("/metrics").text
