from service.agent_runtime import execute_tool, ask_ollama
import pytest


def test_tool_read_only():
    assert execute_tool('gitlab.get_pipeline',{'pipeline_id':482})['status']=='failed'
    assert execute_tool('k8s.list_events',{'namespace':'ai-lab'})['events'][0]['reason']=='BackOff'
    with pytest.raises(PermissionError):execute_tool('gitlab.delete_project',{})
    with pytest.raises(PermissionError):execute_tool('k8s.list_events',{'namespace':'kube-system'})


def test_llm_tool_loop_injected():
    count=0
    def model(payload):
        nonlocal count
        count+=1
        if count==1:
            return {'message':{'role':'assistant','tool_calls':[{'function':{'name':'gitlab.get_pipeline','arguments':{'pipeline_id':482}}}]}}
        assert any(m.get('role')=='tool' for m in payload['messages'])
        return {'message':{'role':'assistant','content':'Pipeline failed at container-build'}}
    result=ask_ollama('why pipeline failed?',send=model)
    assert result['mode']=='ollama'
    assert result['tools_used']==['gitlab.get_pipeline']
    assert count==2
