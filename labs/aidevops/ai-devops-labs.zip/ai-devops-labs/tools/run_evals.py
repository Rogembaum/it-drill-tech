#!/usr/bin/env python3
"""Offline deterministic guardrail quality gate. Not a substitute for LLM evaluations.
Override EVAL_DATASET_PATH for regression/failure demos without touching golden data.
"""
import json
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from service.route_policy import route

def main():
    path=Path(os.getenv('EVAL_DATASET_PATH',str(ROOT/'fixtures/eval_routes.json')))
    cases=json.loads(path.read_text(encoding='utf8'))
    if not cases:raise ValueError('empty eval dataset')
    results=[{'id':case['id'],'expected':case['expected'],'actual':route(case['input'])} for case in cases]
    score=sum(r['actual']==r['expected'] for r in results)/len(results)
    threshold=float(os.getenv('EVAL_MIN_ACCURACY','1.0'))
    report={'dataset':path.name,'count':len(cases),'accuracy':score,'threshold':threshold,
            'failures':[r for r in results if r['actual']!=r['expected']],
            'note':'Deterministic router eval, not a real LLM model quality measurement'}
    out=ROOT/'artifacts'/'evals.json';out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(f'EVAL accuracy={score:.3f} threshold={threshold:.3f} cases={len(cases)}')
    if score<threshold:return 1
    return 0

if __name__=='__main__':sys.exit(main())
