#!/usr/bin/env python3
"""True MCP client/server in-memory integration, using the learner's workspace.
Requires: pip install -r requirements-mcp.txt
Does not communicate with any corporate GitLab or Kubernetes cluster.
"""
import asyncio
import importlib.util
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]


def import_server(path):
    spec=importlib.util.spec_from_file_location('demo_server_'+path.stem,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.mcp


async def main():
    from mcp import Client
    calls=[('M04','gitlab_mcp.py','get_pipeline',{'pipeline_id':482}),
           ('M05','k8s_mcp.py','list_events',{'namespace':'ai-lab'})]
    for lab,source,name,args in calls:
        print(f'[{lab}] connecting to actual MCP server object...')
        mcp_server=import_server(ROOT/'workspaces'/lab/source)
        async with Client(mcp_server) as client:
            result=await client.call_tool(name,args)
            if result.is_error:
                raise RuntimeError(f'{name}: tool error {result}')
            print('Tool:',name)
            print('Result:',json.dumps(result.structured_content,indent=2,ensure_ascii=False,default=str))
    print('MCP client/server integration PASS')

if __name__=='__main__':
    try:asyncio.run(main())
    except ModuleNotFoundError as e:
        print('Missing SDK: pip install -r requirements-mcp.txt',file=sys.stderr)
        raise
