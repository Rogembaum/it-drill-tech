# Corporate DevOps AI Agent Platform — Portfolio

## Problem
Reduce time to diagnose failed pipelines and Kubernetes events without granting AI tools write access.

## Architecture
FastAPI agent endpoint → allowlisted Tool Calling → MCP read-only adapters → GitLab + Kubernetes. Observability via Prometheus metrics and audit trail.

## Environment
CPU-only kind with three nodes; Docker; Python; Helm; GitLab CI. Demo uses offline fixture by default. Real Ollama via separate optional exercise; no production credentials.

## Evidence checklist
- [ ] A01–A03 agent API and model tools (tests and screenshots)
- [ ] M04–M06 MCP adapters and authorization (negative tests)
- [ ] K07–K09 deployment, Helm, HPA and PDB (kubectl outputs)
- [ ] C10–C12 CI pipeline, scans and smoke tests (job logs)
- [ ] S13–S16 RBAC, NetworkPolicy, alerting, backup/restore (audit evidence)
- [ ] DR drill: delete a pod and show recovery + traffic behavior

## SLOs (define and measure on your own hardware)
- Availability target: ___
- p95 /run latency: ___ ms at ___ RPS
- MTTR of pod failure: ___ sec
- Tool calls denied by policy: ___

## Security decisions
Dedicated service accounts, namespace-scoped access; model output must not directly execute commands; no secrets in repo, artifact redaction, limited egress.

## Architecture Decisions (ADRs)
1. Why mock first, Ollama later?
2. Why read-only tools?
3. Why separate agent, MCP and inference runtime?
4. How would we migrate to GPU on Selectel?

## Further work
Add real CI smoke tests on a self-hosted GitLab runner; install Prometheus/Grafana; deploy a true MCP server; introduce GPU Operator and model serving on Selectel in a separate environment.
