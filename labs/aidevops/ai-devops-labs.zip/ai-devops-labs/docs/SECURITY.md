# Security model
- Use kind-ai-labs ONLY. No operations on other kubectl contexts.
- The project uses fictional GitLab records and Kubernetes events.
- Do not provide real GitLab tokens to the demonstration fixture.
- LLM answers are untrusted. Tools use exact allowlists and bounded parameters.
- Namespace isolation is not network isolation unless the CNI enforces NetworkPolicy.
- Helm or kubectl actions are explicitly user-triggered; a model cannot run them.
- Real corporate deployments require SSO, RBAC, audit retention, egress control, secret management, resource quotas, backup and DR testing.
