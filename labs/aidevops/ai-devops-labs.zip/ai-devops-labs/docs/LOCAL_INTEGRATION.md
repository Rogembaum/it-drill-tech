# Опциональная CPU-интеграция FastAPI + n8n + PostgreSQL

Основная лаборатория `./ai-lab start ...`, `./ai-lab check ...` выполняется без Docker (кроме K8s-сценариев). Для демонстрации внешних связей можно поднять дополнительный контейнерный стенд.

1. `cp .env.example .env` и замени placeholders на уникальные длинные случайные строки. Не добавляй `.env` в Git и не используй корпоративные credentials.
2. Проверь совместимость и выбери актуальный конкретный тег n8n образа, укажи `N8N_IMAGE` в `.env`. В примере указан обучающий тег, он не является гарантией последней версии.
3. Только FastAPI: `docker compose --env-file .env -f compose.integration.yaml up -d --build agent`; проверка `curl http://127.0.0.1:18080/healthz`.
4. С n8n и PostgreSQL: `docker compose --env-file .env -f compose.integration.yaml --profile n8n up -d --build`.
5. В отдельном **локальном** n8n открой `http://127.0.0.1:15678`, настрой учётную запись, header authentication credentials и error workflow. Импортируй решение B33 `workspaces/B33/workflow.json`; `AGENT_URL` должен ссылаться на `http://agent:8080/run` в Docker сети. Настрой webhook path и секреты в n8n вручную. Не оставляй webhook публичным.
6. Пошли тестовый HTTP POST с фиктивными данными. Проверь ответ, failure path, retry и события workflow. `B33` статически проверяет wiring JSON, но только этот живой тест подтверждает настоящий n8n flow.
7. Проверяй PostgreSQL backup/restore только в отдельной тестовой БД. Не удаляй volumes, пока не сделал backup и restore drill.

**Известное ограничение:** webhook B33 использует headerAuth n8n, а задача M21 HMAC реализует отдельно. Для production надо связать реальный HMAC verifier, authn/authz и защищённый ingress. Compose на одной машине не доказывает HA между двумя серверами.
