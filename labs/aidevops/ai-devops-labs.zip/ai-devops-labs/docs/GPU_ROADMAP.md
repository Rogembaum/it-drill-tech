# Этап 2: перенос CPU Lab в облако Selectel с NVIDIA GPU

Этот документ — план, не подтверждение существующих или доступных GPU-конфигураций у конкретного провайдера.

1. Определить доступный тип NVIDIA GPU, VRAM, CPU/RAM, способ подключения и бюджет.
2. Выбрать GPU VM с собственным Kubernetes или Managed Kubernetes с GPU node pool; проверить совместимость.
3. Проверить CUDA/driver, container runtime, NVIDIA GPU Operator и `nvidia.com/gpu`.
4. Развернуть vLLM или другую inference-платформу на GPU. Затем KServe при необходимости.
5. Настроить DCGM Exporter, Prometheus/Grafana, GPU utilization, VRAM, температурные и error метрики.
6. Повторить тесты p95, throughput, cost per request и failure recovery на CPU и GPU.
7. Добавить tenancy, budgets, quotas, secret management и изолированные среды.

**Отдельно:** InfiniBand/RDMA/Mellanox нельзя достоверно отработать на любой произвольной GPU VM; поддержка зависит от платформы и физической сети.
