# Портфолио под три типа AI-вакансий (версия 2)

## Трек A — AI/ML Engineer, Agentic Products
Сделай минимальный агентный сервис с ReAct/Tool Calling, router/fallback/escalate, read-only GitLab/Kubernetes MCP, RAG: ingestion → hybrid retrieval → reranker → prompt context. Для валидации: offline golden evals, ручная разметка для judge, model selection по quality/p95/cost, контроль регрессий через GitLab CI.

**Обязательные evidence:** A18–A20, M21–M22, R23–R25, E26–E28, C37. Плюс демонстрация Ollama A03 с реальными вызовами `/api/chat` если доступна RAM.

**Не считать завершённым:** если нет интеграционных тестов модели, проверок tool permissions и воспроизводимого набора test cases.

## Трек B — AI-native Infrastructure Engineer
Настрой AGENTS.md, CLAUDE.md, безопасный hook, дифф-ревью агента; связку n8n → FastAPI → Telegram (в тестовой среде); Docker Compose, бэкапы/Postgres restore, централизованный redacted audit.

**Обязательные evidence:** N29–N31, B32–B34, S35–S36, S13–S16, C10–C12.

**Безопасность:** webhook signature, actor allowlist, no secrets in prompt, least privilege, human approval. Исключи реальные корпоративные проекты/токены из демонстрации.

## Трек C — AI Platform / DevOps Engineer
Начни с CPU-only kind: K07, K08, K09; проверь доступность runtime, RPO/RTO и SLO. Добавь Prometheus alerts и GitLab CI. Следующий этап — Selectel GPU Operator, vLLM, DCGM, KServe.

**Обязательные evidence:** output `kubectl get`, `helm template`, `helm lint`, `pytest`, `promtool`, SLO screenshot, восстановление после simulated pod failure. CPU часть не доказывает GPU-опыт.

## Итоговый capstone
`P38`: собери открытый учебный Git репозиторий с архитектурой, диаграммой потоков, GitLab CI, API контрактами, тестовыми fixtures, eval results, runbooks, ADR и threat model.

### Метрики результата: что действительно полезно работодателю
- Agent task success rate и failure modes на golden dataset, dataset version.
- p50/p95/p99 inference latency, очередь, timeout и fallback rate.
- Security deny tests, leaked secret incidents = 0 в тестовом коде.
- CI failure on bad evals и реальный rollback/smoke.
- Время восстановления, проверенный backup restore, RPO/RTO.
- Для business automation: реальные часы до/после, подтверждённые пользователями; без реального пилота не заявлять экономию.

### Пять вопросов работодателю — собери доказательства заранее
1. Какой агентный сервис создал, кто использует, какой реальный эффект (если пока только учебный — честно так и напиши).
2. Чем проверял правильность (golden evals, human review, security negative tests, regression gate).
3. Пример production RCA из собственного DevOps опыта (без конфиденциальных данных).
4. Что применил нового (MCP, agent harness, hybrid RAG, model comparison, tools, hooks).
5. Как построил CI/CD, мониторинг, доступы, секреты, backup/restore; что сделал лично.

