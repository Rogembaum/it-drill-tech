"""Behavioural, offline-first checks for new hands-on labs.
These run student code in a local training environment, never in production.
Use workspaces made from templates, not arbitrary downloaded projects.
"""
import asyncio
import ast
import copy
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time

NEW_IDS = set('A18 A19 A20 M21 M22 R23 R24 R25 E26 E27 E28 N29 N30 N31 B32 B33 B34 S35 S36 C37 P38 A39 B40'.split())

def extra_checker(t, r, W, ROOT):
    from checks import load_module, run_cmd
    base=W/t
    def load(filename): return load_module(base/filename)
    def source(filename): return (base/filename).read_text(encoding='utf-8')
    def test(label, fn): r.check(label, fn)
    def skip(label, detail): r.skip(label,detail)
    if t == 'A18':
        m=load('async_client.py')
        async def concurrent():
            inflight=0; max_inflight=0
            async def transport(x):
                nonlocal inflight,max_inflight
                inflight+=1;max_inflight=max(max_inflight,inflight)
                await asyncio.sleep(.015);inflight-=1
                return {'status':200,'result':x*2}
            result=await m.fetch_many([1,2,3],transport,timeout=.2)
            return result==[2,4,6] and max_inflight>=2
        test('Реальная параллельность и порядок результатов',lambda:asyncio.run(concurrent()))
        async def retry():
            n=0
            async def fake(x):
                nonlocal n
                n+=1
                return {'status':503 if n==1 else 200,'result':'ok'}
            return await m.fetch_many(['x'],fake,retries=1,timeout=.2)==['ok'] and n==2
        test('Retry 503 с ограниченным числом попыток',lambda:asyncio.run(retry()))
        async def timeout():
            async def slow(x):await asyncio.sleep(.08);return {'status':200,'result':x}
            try:await m.fetch_many([1],slow,retries=0,timeout=.01);return False
            except TimeoutError:return True
        test('Timeout работает, нет бесконечного ожидания',lambda:asyncio.run(timeout()))
    elif t=='A19':
        m=load('router.py')
        test('Рискованное действие блокируется',lambda:m.route('please delete project now')=='blocked' and m.route('перевести деньги')=='blocked')
        test('LLM unavailable → fallback',lambda:m.route('summarize',llm_available=False)=='fallback')
        test('Низкая уверенность → человек',lambda:m.route('summarize',confidence=.2)=='escalate')
        test('Обычный запрос → answer',lambda:m.route('summarize log',confidence=.99)=='answer')
        test('Пустой ввод → не выполняется автоматически',lambda:m.route('')!='answer')
    elif t=='A20':
        m=load('harness.py')
        calls=[]
        def planner(history):
            return {'action':'tool','name':'read','args':{'id':482}} if not history else {'action':'final','answer':'checked'}
        def reader(id):calls.append(id);return {'id':id}
        def normal():
            ans,trace=m.run_agent(planner,{'read':reader},max_steps=3)
            return ans=='checked' and len(trace)==1 and trace[0]['result']['id']==482 and calls==[482]
        test('Agent loop, настоящий вызов tool и trace',normal)
        def forbidden():
            try:m.run_agent(lambda _: {'action':'tool','name':'kubectl.delete','args':{}},{'read':reader},max_steps=1);return False
            except PermissionError:return True
        test('Неизвестный tool не выполняется',forbidden)
        def budget():
            try:m.run_agent(lambda _: {'action':'tool','name':'read','args':{'id':1}},{'read':reader},max_steps=2);return False
            except RuntimeError:return True
        test('Budget шагов ограничивает циклы',budget)
    elif t=='M21':
        m=load('webhook.py'); body=b'{"event":"pipeline"}';key=b'training-only-key';sig=hmac.new(key,body,hashlib.sha256).hexdigest()
        test('Подписанный webhook принят только один раз',lambda:(lambda seen: m.verify(body,sig,1000,'e1',key,1100,seen) and not m.verify(body,sig,1000,'e1',key,1100,seen))(set()))
        test('Подделка подписи отклоняется',lambda: not m.verify(body,'0'*64,1000,'e2',key,1000,set()))
        test('Старый webhook отклоняется',lambda: not m.verify(body,sig,1000,'e3',key,1500,set()))
        test('Подмена body запрещена',lambda: not m.verify(b'hacked',sig,1000,'e4',key,1000,set()))
    elif t=='M22':
        m=load('consumer.py'); seen=set();executed=[]
        test('Обработка и отсутствие повторного side effect',lambda: m.consume({'id':'1','payload':{'x':1}},seen,lambda p:executed.append(p))=='processed' and m.consume({'id':'1','payload':{'x':1}},seen,lambda p:executed.append(p))=='duplicate' and len(executed)==1)
        test('Temporary failure: retry, id не зафиксирован',lambda:m.consume({'id':'2','payload':{}},seen,lambda p:(_ for _ in ()).throw(TimeoutError()))=='retry' and '2' not in seen)
        test('Bad data: DLQ, нет acknowledged',lambda:m.consume({'id':'3','payload':'wrong'},seen,lambda p:None)=='dlq' and '3' not in seen)
    elif t=='R23':
        m=load('ingest.py')
        def ingest():
            docs=[{'source':'wiki/a','text':'alpha beta gamma delta'},{'source':'wiki/a','text':'alpha beta gamma delta'},{'source':'wiki/b','text':'  '}]
            a=m.ingest(docs,chunk_size=2);b=m.ingest(docs,chunk_size=2)
            return len(a)==2 and len({p['id'] for p in a})==2 and a==b and all(len(p['text'].split())<=2 for p in a) and all(p['source']=='wiki/a' for p in a)
        test('Chunking, stable IDs, dedup, empty doc',ingest)
        test('Проверяется входной chunk_size',lambda:(lambda:None)() if False else safe_exception(lambda:m.ingest([],0),ValueError))
    elif t=='R24':
        m=load('hybrid.py')
        test('Пересечение rank-листов поднимается',lambda:m.fuse(['a','b'],['b','c'],top_k=3)[0]=='b')
        test('Нет повторов, есть vector-only документы',lambda:set(m.fuse(['a'],['c','a'],top_k=5))=={'a','c'} and len(m.fuse(['a','a'],['a'],top_k=5))==1)
        test('top_k и пустые входы',lambda:m.fuse([],[],top_k=3)==[] and len(m.fuse(['a','b'],['c','d'],top_k=2))==2)
    elif t=='R25':
        m=load('context.py')
        chunks=[{'score':.3,'text':'noise no', 'source':'n'}, {'score':.99,'text':'one two three', 'source':'s1'}, {'score':.8,'text':'four five', 'source':'s2'}]
        def cond():
            out=m.build_context(chunks,budget=4,min_score=.5)
            return [x['source'] for x in out]==['s1'] and 'score' not in out[0]
        test('Score, relevance и budget',cond)
        test('Пустой budget = пустой context',lambda:m.build_context(chunks,budget=0)==[])
    elif t=='E26':
        m=load('evaluate.py')
        rows=[{'input':'1','expected':'answer'},{'input':'2','expected':'escalate'},{'input':'3','expected':'blocked'},{'input':'4','expected':'escalate'}]
        pred={'1':'answer','2':'answer','3':'escalate','4':'escalate'}
        def metrics():
            a=m.evaluate(rows,lambda x:pred[x]);return a['accuracy']==.5 and abs(a['precision']-.5)<1e-9 and abs(a['recall']-.5)<1e-9 and len(a['failures'])==2
        test('Accuracy/precision/recall на золотой выборке',metrics)
        test('Пустая выборка без ошибки',lambda:m.evaluate([],lambda x:None)['accuracy']==0)
    elif t=='E27':
        m=load('judge.py');rows=[{'answer':'a','rubric':'accuracy','human_score':5},{'answer':'b','rubric':'accuracy','human_score':1},{'answer':'c','rubric':'accuracy','human_score':3}]
        def judge(a,r):return {'score':4 if a=='a' else 2 if a=='b' else 9}
        def res():
            x=m.calibrate(rows,judge)
            return x['invalid']==1 and x['rated']==2 and abs(x['mae']-1)<1e-9
        test('Калибровка judge против human ground truth',res)
        test('Неверные типы, отсутствие score отклоняются',lambda:m.calibrate([rows[0]],lambda a,r:{'score':'5'})['invalid']==1 and m.calibrate([rows[0]],lambda a,r:{})['invalid']==1)
    elif t=='E28':
        m=load('select.py');c=[{'name':'cheap','quality':.85,'p95_ms':800,'cost_usd':.01},{'name':'bad-slow','quality':.99,'p95_ms':4000,'cost_usd':.02},{'name':'best','quality':.92,'p95_ms':900,'cost_usd':.019}]
        test('Отбирает по quality + latency + cost',lambda:m.choose(c)=='best')
        test('Не допускает модель без SLO',lambda:m.choose(c,max_p95=100) is None)
        test('Tie break by p95, not first in list',lambda:m.choose([{'name':'z','quality':.9,'p95_ms':600,'cost_usd':.015},{'name':'a','quality':.9,'p95_ms':500,'cost_usd':.02}])=='a')
    elif t=='N29':
        a=source('AGENTS.md').lower();b=source('CLAUDE.md').lower();combined=a+'\n'+b
        test('Инструкции включают тесты и diff review',lambda:'pytest' in combined and ('review' in combined or 'ревью' in combined) and 'git' in combined)
        test('Определены ограничения на secrets/production',lambda:'secret' in combined and 'prod' in combined and ('kubectl' in combined or 'terraform' in combined))
        test('Есть документирование и rollback',lambda:'adr' in combined and 'rollback' in combined and 'human' in combined)
        skip('Реальная политика прав IDE / CLI','Инструкции сами по себе не ограничивают команды; проверь sandbox/permissions отдельно')
    elif t=='N30':
        src=base/'guard.py'
        def invoke(command=None,malformed=False):
            payload='malformed' if malformed else json.dumps({'tool_input':{'command':command}})
            return subprocess.run([sys.executable,str(src)],input=payload,text=True,capture_output=True,timeout=4).returncode
        test('pytest разрешён',lambda:invoke('pytest -q')==0)
        test('kubectl delete запрещён',lambda:invoke('kubectl delete pods --all -n ai-lab')==2)
        test('terraform apply и prod запрещены',lambda:invoke('terraform apply')==2 and invoke('kubectl get pods --context prod')==2)
        test('Повреждённый JSON запрещён',lambda:invoke(malformed=True)==2)
    elif t=='N31':
        m=load('review_gate.py');good={'tests_passed':True,'scan_passed':True,'secret_findings':0,'human_reviewed':True,'high_risk':True,'adr':True,'rollback_plan':True}
        test('Ревью + green CI + ADR при риске',lambda:m.approve(good) is True)
        def neg():
            for k,v in [('tests_passed',False),('scan_passed',False),('secret_findings',1),('human_reviewed',False),('adr',False),('rollback_plan',False)]:
                cand={**good,k:v}
                if m.approve(cand):return False
            return True
        test('Fail-closed: все критические причины отклонены',neg)
    elif t=='B32':
        m=load('telegram.py')
        def check():
            calls=[];baseupdate={'message':{'from':{'id':42},'chat':{'id':100},'text':'Contact me: user@example.com'}}
            a=m.handle(baseupdate,{42},lambda chat,text:calls.append((chat,text)))
            b=m.handle({'message':{'from':{'id':99},'chat':{'id':999},'text':'hello'}},{42},lambda chat,text:calls.append((chat,text)))
            return a=='ok' and b=='forbidden' and len(calls)==1 and 'user@example.com' not in calls[0][1] and calls[0][0]==100
        test('Telegram allowlist и PII redaction',check)
        test('Большой запрос не проходит',lambda:m.handle({'message':{'from':{'id':42},'text':'X'*2000}},{42},lambda *_:None)=='invalid')
    elif t=='B33':
        obj=json.loads(source('workflow.json'));nodes={x['name']:x for x in obj['nodes']};con=obj.get('connections',{})
        test('Webhook, HTTP Request, Respond: узлы существуют',lambda:{'Webhook','Call Agent','Respond'}<=set(nodes) and nodes['Call Agent']['type']=='n8n-nodes-base.httpRequest')
        def edges():
            def dst(name):return [e['node'] for group in con.get(name,{}).values() for branch in group for e in branch]
            return 'Call Agent' in dst('Webhook') and 'Respond' in dst('Call Agent')
        test('Связь Webhook → Agent → Respond',edges)
        test('Retry и error workflow настроены',lambda:nodes['Call Agent'].get('retryOnFail') and nodes['Call Agent'].get('maxTries',0)>1 and bool(obj['settings']['errorWorkflow']))
        test('Нет literal credentials и webhook auth указан',lambda:'hardcoded-secret' not in source('workflow.json') and '$env.AGENT_URL' in source('workflow.json') and nodes['Webhook']['parameters'].get('authentication') not in (None,'none'))
        skip('LIVE: workflow n8n webhook','Импортируй workflow в отдельный n8n, настрой credentials и error workflow, прогони HMAC и реальный HTTP call')
    elif t=='B34':
        import yaml
        data=yaml.safe_load(source('compose.yaml'));srv=data['services'];agent=srv['agent'];db=srv['db']
        test('База не публикует порт и internal network',lambda:not db.get('ports') and data['networks']['internal'].get('internal') is True and 'internal' in db.get('networks',[]))
        test('Healthchecks, pinned tags, agent non-root',lambda: bool(agent.get('healthcheck')) and bool(db.get('healthcheck')) and 'latest' not in agent['image'] and 'latest' not in db['image'] and agent.get('user') not in (None,'0','root'))
        test('Нет явного пароля в YAML и DB secret file',lambda:'hardcoded' not in source('compose.yaml').lower() and 'POSTGRES_PASSWORD_FILE' in db.get('environment',{}) and db['secrets'])
        if shutil.which('docker') and (base/'secrets/pg_password.txt').exists():
            def validate():
                p=run_cmd(['docker','compose','-f',str(base/'compose.yaml'),'config','--quiet']);return p.returncode==0
            test('Docker Compose CLI parses config (requires secret file)',validate)
        else:skip('LIVE: docker compose config','Нужен Docker compose и файл secrets/pg_password.txt; не публикуй его')
        skip('Live Postgres health / restore','docker compose config не подтверждает работающий DB или восстановление')
    elif t=='S35':
        m=load('audit.py');raw={'trace_id':'t1','event_type':'tool_called','status':'ok','user_email':'a@example.com','api_key':'SUPERSECRET','payload':{'prompt':'password is 123','message':'contact support@example.com'},'lines':['send b@example.com']}
        def masked():
            orig=copy.deepcopy(raw);out=m.sanitize(raw)
            data=json.dumps(out)
            return raw==orig and out['trace_id']=='t1' and out['event_type']=='tool_called' and 'SUPERSECRET' not in data and 'password is 123' not in data and 'example.com' not in data
        test('PII/secrets скрыты во вложенной структуре',masked)
        test('Не мутирует аргумент и сохраняет status',lambda:m.sanitize(raw)['status']=='ok')
    elif t=='S36':
        sh=base/'backup.sh';txt=source('backup.sh')
        test('bash -n и fail fast',lambda:run_cmd(['bash','-n',str(sh)]).returncode==0 and 'set -euo pipefail' in txt)
        def simulate():
            with tempfile.TemporaryDirectory() as td:
                p=Path(td);bin=p/'bin';bin.mkdir();out=p/'out';out.mkdir()
                pgdump=bin/'pg_dump';pgdump.write_text('#!/bin/sh\nwhile [ "$#" -gt 0 ]; do if [ "$1" = "-f" ]; then shift; echo fixture > "$1"; exit 0; fi; shift; done\nexit 1\n');pgdump.chmod(0o755)
                pgrestore=bin/'pg_restore';pgrestore.write_text('#!/bin/sh\n[ "$1" = "--list" ] && test -s "$2"\n');pgrestore.chmod(0o755)
                env={**os.environ,'PATH':str(bin)+os.pathsep+os.environ['PATH'],'PGDATABASE':'test_agents','BACKUP_DIR':str(out)}
                p1=subprocess.run(['bash',str(sh)],env=env,capture_output=True,text=True,timeout=5)
                return p1.returncode==0 and (out/'agent-db.dump').is_file() and (out/'agent-db.dump.sha256').is_file() and subprocess.run(['sha256sum','-c','agent-db.dump.sha256'],cwd=out,capture_output=True).returncode==0
        test('Fixture pg_dump + pg_restore --list + sha256',simulate)
        test('Без PGDATABASE команда запрещена',lambda:run_cmd(['bash',str(sh)],timeout=4,env={**os.environ,'PGDATABASE':'','BACKUP_DIR':'/tmp/not-used'}).returncode!=0)
        skip('LIVE: восстановление отдельной PostgreSQL БД','Требуется pg_restore в пустую test DB + проверка записей и RTO; не запускается автоматически')
    elif t=='C37':
        import yaml
        data=yaml.safe_load(source('.gitlab-ci.yml'));stages=data['stages']
        test('test → eval → deploy идут по порядку',lambda:stages.index('test')<stages.index('eval')<stages.index('deploy'))
        jobs={k:v for k,v in data.items() if isinstance(v,dict) and 'stage' in v}
        def guard():
            ev=[j for j in jobs.values() if j['stage']=='eval'];dep=[j for j in jobs.values() if j['stage']=='deploy']
            return ev and all(j.get('allow_failure') is False and j.get('artifacts',{}).get('paths') and any('pytest' in s or 'eval' in s for s in j.get('script',[])) for j in ev) and dep and all(j.get('when')=='manual' or any(x.get('when')=='manual' for x in j.get('rules',[])) for j in dep)
        test('Blocking eval gate + artifacts + ручной deploy',guard)
        skip('LIVE: pipeline + eval-gate red/green','Запусти на учебном GitLab, сломай golden dataset и приложи job URL с failed gate')
    elif t=='A39':
        from fastapi.testclient import TestClient
        m=load('di_api.py');calls=[]
        async def provider(q):calls.append(q);return 'result:'+q
        app=m.make_app(provider)
        cli=TestClient(app)
        test('FastAPI /run действительно вызывает async provider',lambda: cli.post('/run',json={'question':'hello'}).json()=={'answer':'result:hello'} and calls==['hello'])
        test('Request input validation: 422',lambda:cli.post('/run',json={'question':'x'}).status_code==422)
        test('Dependency injection использует Depends',lambda:'Depends' in source('di_api.py'))
    elif t=='B40':
        from fastapi.testclient import TestClient
        from starlette.websockets import WebSocketDisconnect
        from starlette.routing import WebSocketRoute
        m=load('ws_app.py');app=m.make_app('local-demo-token')
        if not any(isinstance(route, WebSocketRoute) and route.path=='/ws' for route in app.routes):
            test('WebSocket /ws определён',lambda:False)
            return r
        cli=TestClient(app)
        def valid():
            with cli.websocket_connect('/ws',headers={'x-client-token':'local-demo-token'}) as ws:
                ws.send_text('test'); response=ws.receive_json()
                return response=={'event':'progress','length':4} and 'token' not in response
        test('WebSocket streaming JSON event works',valid)
        def deny():
            try:
                with cli.websocket_connect('/ws') as ws:ws.receive_text()
                return False
            except WebSocketDisconnect as e:return e.code==1008
        test('WebSocket handshake без авторизации закрыт',deny)
    elif t=='P38':
        src=source('README.md').lower()
        test('Architecture: agent, rag, evals, mcp',lambda:all(x in src for x in ('architecture','rag','eval','mcp','agent')))
        test('Ops: backup, rollback, security, ci',lambda:all(x in src for x in ('backup','rollback','security','ci/cd')))
        test('Business / employer Q&A и ссылка на evidence',lambda:all(x in src for x in ('employer','evidence','review','production')))
        skip('Портфолио реально подтверждено','Заполни ссылками на код/CI/evals и фактическими измерениями; не выдавай mock за commercial production')
    return r

def safe_exception(callback,kind):
    try: callback();return False
    except kind:return True
