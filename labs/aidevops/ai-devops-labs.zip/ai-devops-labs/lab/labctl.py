#!/usr/bin/env python3
import json
from pathlib import Path
import os
import random
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from checks import ROOT, W, checker

TASKS={d['id']:d for d in json.loads((ROOT/'tasks.json').read_text(encoding='utf8'))}
STATE=ROOT/'.state';STATE.mkdir(exist_ok=True)
STATUS=STATE/'results.json'
DOMAINS={'01 agent':'AI Agent на Python', '02 tools':'MCP и корпоративные инструменты',
         '03 k8s':'Kubernetes и Helm','04 cicd':'GitLab CI/CD','05 secure':'Безопасность и наблюдаемость',
         '06 capstone':'Итоговый проект',
         '07 rag':'RAG и поиск по знаниям','08 evals':'Evals / LLM-as-a-Judge',
         '09 ainative':'AI-native / Coding Agents','10 automation':'Telegram / n8n / API',
         '11 models':'ModelOps и LLM serving',
         '12 gateway':'LLM-шлюзы и биллинг','13 aisec':'AI Security и AI firewall',
         '14 inference':'Безопасный инференс и модели','15 platform':'AI-платформа разработки',
         '16 agentarch':'Архитектура AI-агентов'}

def fail(message): print('✗',message,file=sys.stderr);sys.exit(2)
def need(command):
    if not shutil.which(command): fail('Требуется '+command+'; см. README')
def run(args,check=True,env=None):
    print('>', ' '.join(str(x) for x in args))
    return subprocess.run(args,cwd=ROOT,check=check,env=env)
def meta(t):
    t=t.upper()
    if t not in TASKS:fail('нет такой задачи '+t+', см. ./ai-lab list')
    return TASKS[t]
def copy_task(t,source):
    dest=W/t
    if dest.exists():shutil.rmtree(dest)
    shutil.copytree(ROOT/'tasks'/t/source,dest)

def status_load():
    try:return json.loads(STATUS.read_text())
    except (FileNotFoundError,ValueError):return {}
def status_save(s):STATUS.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf8')
def store(t,r):
    s=status_load();ok,total=r.score
    s[t]={'passed':ok,'total':total,'failed':sum(x[0]=='FAIL' for x in r.results),
          'skipped':sum(x[0]=='SKIP' for x in r.results),'updated_at':datetime.now(timezone.utc).isoformat()}
    status_save(s)

def show_check(t):
    m=meta(t);t=m['id'];r=checker(t)
    print('\n'+t+' — '+m['title'])
    for kind,label,detail in r.results:
        sym={'PASS':'✓','FAIL':'✗','SKIP':'○'}[kind]
        print(f'  {sym} [{kind}] {label}')
        if detail:print('      '+detail)
    p,n=r.score
    print(f'RESULT {t} {p}/{n} (failed {sum(x[0]=="FAIL" for x in r.results)}, skipped {sum(x[0]=="SKIP" for x in r.results)})\n')
    store(t,r)
    return not any(x[0]=='FAIL' for x in r.results) and not any(x[0]=='SKIP' for x in r.results)

def cmd_list(domain=None):
    for m in TASKS.values():
        if domain and domain not in (m['domain'],m['id']):continue
        s=status_load().get(m['id'],{});result=f" [{s.get('passed',0)}/{s.get('total',0)}]" if s else ''
        print(f"{m['id']:3}  {DOMAINS[m['domain']]:37} {m['title']}{result}")

def cmd_doctor():
    print('AI DevOps Labs — проверка окружения')
    for tool in ['python3','docker','kind','kubectl','helm','bash','sha256sum']:
        print((' ✓' if shutil.which(tool) else ' ✗'),tool)
    for pkg in ['fastapi','uvicorn','pytest','yaml','requests','mcp']:
        try: __import__(pkg);print(' ✓ python',pkg)
        except ImportError:print(' ○ python',pkg,'(установить при необходимости)')
    if shutil.which('kubectl'):
        p=subprocess.run(['kubectl','--context','kind-ai-labs','get','nodes'],capture_output=True,text=True,timeout=8)
        print(' kind-ai-labs:', 'доступен' if p.returncode==0 else 'пока не создан')

def cluster_guard():
    need('kubectl')
    p=subprocess.run(['kubectl','config','get-contexts','kind-ai-labs','-o','name'],capture_output=True,text=True)
    if p.returncode:fail('не найден контекст kind-ai-labs; ./ai-lab up')
    return ['kubectl','--context','kind-ai-labs']

def cmd_up():
    need('kind');need('docker');need('kubectl')
    out=subprocess.run(['kind','get','clusters'],capture_output=True,text=True)
    if 'ai-labs' in out.stdout.splitlines(): print('kind ai-labs уже существует')
    else:run(['kind','create','cluster','--name','ai-labs','--config','cluster/kind.yaml','--wait','120s'])
    run(cluster_guard()+['get','nodes'])
    print('Далее: ./ai-lab image; ./ai-lab start K07; исправьте манифест; ./ai-lab apply K07')

def cmd_image():
    need('docker');need('kind')
    run(['docker','build','-t','ai-agent-lab:0.1','-f','service/Dockerfile','.'])
    run(['kind','load','docker-image','ai-agent-lab:0.1','--name','ai-labs'])

def cmd_apply(t):
    t=meta(t)['id'];k=cluster_guard()
    if t=='K08':
        need('helm')
        run(['helm','upgrade','--install','agent-helm',str(W/t),'--namespace','ai-lab','--create-namespace','--kube-context','kind-ai-labs','--wait','--timeout','180s'])
    elif t in ['K07','K09','S13','S14']:
        file={'K07':'deployment.yaml','K09':'ha.yaml','S13':'rbac.yaml','S14':'networkpolicy.yaml'}[t]
        # Network policy and RBAC tasks require a namespace from K07; no production operations.
        run(k+['apply','-f',str(W/t/file)])
    else:fail('apply поддерживает K07, K08, K09, S13, S14')

def cmd_seed(t):
    """Explicit opt-in: create the broken scenario in the isolated lab cluster."""
    t=meta(t)['id'];k=cluster_guard()
    if t=='K07':
        run(k+['apply','-f',str(ROOT/'tasks/K07/starter/deployment.yaml')])
        print('Сломанный readinessProbe установлен. Исправь workspaces/K07/deployment.yaml, затем ./ai-lab apply K07')
    elif t=='K09':
        run(k+['apply','-f',str(ROOT/'tasks/K09/starter/ha.yaml')])
        print('Плохие PDB/HPA установлены, исправь HA манифест и снова примени.')
    else: fail('seed предназначен для K07 и K09; в остальных задачах стартовый файл уже сломан')

def cmd_incident(action):
    k=cluster_guard()
    if action=='backoff':
        run(k+['apply','-f',str(ROOT/'cluster/crashloop.yaml')])
        print('Сценарий CrashLoopBackOff создан; смотри kubectl --context kind-ai-labs -n ai-lab get events')
    elif action in ('cleanup','clear'):
        run(k+['-n','ai-lab','delete','pod','agent-incident-backoff','--ignore-not-found=true'])
    else:fail('incident поддерживает backoff | cleanup')

def cmd_report():
    s=status_load(); path=ROOT/'artifacts'/'portfolio-progress.md'
    lines=['# AI DevOps Labs — прогресс и доказательства','',f'Сгенерировано: {datetime.now(timezone.utc).isoformat()}','',
           '> Автопроверки подтверждают только перечисленные критерии; не заменяют полноценные security review, code review и production тесты.','',
           '| Задание | Раздел | Пройдено | Ошибки | Не проверено |','|---|---|---:|---:|---:|']
    for t,m in TASKS.items():
        o=s.get(t,{});lines.append(f"| {t}: {m['title']} | {DOMAINS[m['domain']]} | {o.get('passed',0)}/{o.get('total',0)} | {o.get('failed','—')} | {o.get('skipped','—')} |")
    lines.extend(['','## Ссылки на реальные доказательства','',
                  '- Репозиторий GitLab/GitHub:','- Pipeline run URL:','- Helm/kubectl manifests and outputs:','- Grafana screenshots / p95 / errors:',
                  '- DR drill and backup-restore evidence:','- Threat model and ADRs:','',
                  '## Перед публикацией','',
                  'Не публикуй API keys, конфиденциальные логи или внутренние адреса. Подставь свои скриншоты и реальные результаты нагрузочных тестов.'])
    path.write_text('\n'.join(lines)+'\n',encoding='utf8')
    print('Сформирован отчёт:',path)

def cmd_exam():
    picks=[]
    for dom in [d for d in DOMAINS if d != '06 capstone']:
        subset=[t for t,m in TASKS.items() if m['domain']==dom]
        picks.append(random.choice(subset))
    (STATE/'exam.json').write_text(json.dumps(picks))
    print(f'Практический экзамен — {len(picks)} сценариев по направлениям:',' '.join(picks))
    print('Выполняй: ./ai-lab start <ID> → check. Экзамен не применяет эталонные решения.')

def cmd_grade():
    file=STATE/'exam.json'
    tasks=json.loads(file.read_text()) if file.exists() else list(TASKS)
    print('Проверка',len(tasks),'сценариев')
    for t in tasks:show_check(t)
    print('Итоговый отчёт: ./ai-lab report')

HELP='''AI DevOps Labs — тренажёр практических задач (CPU/ kind)

  ./ai-lab doctor              проверить зависимости
  ./ai-lab up                  создать изолированный 3-node kind (ai-labs)
  ./ai-lab image               собрать и загрузить CPU контейнер
  ./ai-lab list [domain]       вывести задачи (01 agent … 16 agentarch, см. README)
  ./ai-lab start A01           открыть задание и starter workspace
  ./ai-lab show A01            показать условие
  ./ai-lab check A01           автоматическая проверка сценария
  ./ai-lab solve A01           раскрыть эталонные файлы (перезаписывает workspace!)
  ./ai-lab reset A01           сбросить только сценарий A01
  ./ai-lab seed K07            создать в kind сломанный Deployment (явно)
  ./ai-lab apply K07           применить задание ТОЛЬКО в kind-ai-labs
  ./ai-lab incident backoff    создать настоящий CrashLoopBackOff в kind
  ./ai-lab incident cleanup    удалить аварийный Pod
  ./ai-lab exam                по одной случайной задаче из каждого направления
  ./ai-lab grade               проверить экзамен или все задачи
  ./ai-lab report              отчёт-подтверждение для портфолио
  ./ai-lab down                удалить ТОЛЬКО kind-кластер ai-labs

Тестовый HTTP сервис: python3 -m uvicorn service.app:app --port 8080
Содержимое файлов: workspaces/<ID>/; инструкции: tasks/<ID>/TASK.md
'''

def main(argv):
    if len(argv)<2:print(HELP);return
    cmd=argv[1];arg=argv[2] if len(argv)>2 else ''
    if cmd in ['help','-h','--help']:print(HELP)
    elif cmd=='list':cmd_list(arg or None)
    elif cmd=='doctor':cmd_doctor()
    elif cmd=='up':cmd_up()
    elif cmd=='image':cmd_image()
    elif cmd=='down':need('kind');run(['kind','delete','cluster','--name','ai-labs'])
    elif cmd=='show':
        m=meta(arg);print((ROOT/'tasks'/m['id']/'TASK.md').read_text(encoding='utf8'))
    elif cmd in ['start','reset','solve']:
        m=meta(arg);tid=m['id']
        if cmd=='start':
            if not (W/tid).exists():copy_task(tid,'starter')
        else:
            copy_task(tid,'solution' if cmd=='solve' else 'starter')
            s=status_load();s.pop(tid,None);status_save(s)
        print((ROOT/'tasks'/tid/'TASK.md').read_text(encoding='utf8'))
        print('Файлы:',W/tid)
        if cmd=='solve':print('Внимание: эталонное решение раскрыто и скопировано в workspace.')
    elif cmd=='check':
        ok=show_check(arg.upper())
        if not ok:sys.exit(1)
    elif cmd=='apply':cmd_apply(arg)
    elif cmd=='seed':cmd_seed(arg)
    elif cmd=='incident':cmd_incident(arg)
    elif cmd=='exam':cmd_exam()
    elif cmd=='grade':cmd_grade()
    elif cmd=='report':cmd_report()
    else:fail('неизвестная команда '+cmd+'\n'+HELP)
if __name__=='__main__':main(sys.argv)
