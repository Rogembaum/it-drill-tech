"""Scenario-specific graders. Never change Kubernetes state here.
Checks are intentionally behavioural where possible; static checks are labelled.
"""
import ast
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from contextlib import contextmanager

ROOT=Path(__file__).resolve().parents[1]
W=ROOT/'workspaces'

class Recorder:
    def __init__(self): self.results=[]
    def check(self, label, test):
        try:
            if not test(): raise AssertionError('requirement not met')
            self.results.append(('PASS',label,''))
        except Exception as e:
            self.results.append(('FAIL',label, str(e)[:240]))
    def skip(self,label,reason): self.results.append(('SKIP',label,reason))
    @property
    def score(self):
        return sum(s=='PASS' for s,_,_ in self.results), len(self.results)

def load_module(path):
    spec=importlib.util.spec_from_file_location('lab_'+uuid.uuid4().hex, str(path))
    obj=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

def read(t,p): return (W/t/p).read_text(encoding='utf8')
def data(t,p):
    import yaml
    return list(yaml.safe_load_all(read(t,p)))
def obj(docs,kind): return next(o for o in docs if isinstance(o,dict) and o.get('kind')==kind)
def run_cmd(args, **kwargs):
    return subprocess.run(args, text=True, stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=kwargs.get('timeout',12))
def has_cluster():
    if not shutil.which('kubectl'): return False
    p=run_cmd(['kubectl','--context','kind-ai-labs','get','ns','kube-system','-o','name'])
    return p.returncode==0

def live_check(r, desc, test):
    if has_cluster(): r.check(desc,test)
    else: r.skip(desc,'kind-ai-labs недоступен. ./ai-lab up; ./ai-lab image; ./ai-lab apply <TASK>')

@contextmanager
def stub_mcp():
    # Grading tool behaviour offline; NOT a substitute for genuine MCP protocol validation.
    from types import ModuleType
    saved={k:v for k,v in sys.modules.items() if k in ('mcp','mcp.server','mcp.server.mcpserver')}
    class MCPServer:
        def __init__(self,*a,**kw): self.tools=[]
        def tool(self):
            def decorator(fn): self.tools.append(fn.__name__); return fn
            return decorator
        def run(self,*a,**kw): pass
    ms=ModuleType('mcp.server.mcpserver'); ms.MCPServer=MCPServer
    for name in ('mcp','mcp.server'):
        sys.modules[name]=ModuleType(name)
    sys.modules['mcp.server.mcpserver']=ms
    try: yield MCPServer
    finally:
        for k in ('mcp','mcp.server','mcp.server.mcpserver'):
            sys.modules.pop(k,None)
        sys.modules.update(saved)

def checker(tid):
    r=Recorder()
    try:
        if tid=='A01':
            withfile=W/tid/'app.py'
            r.check('Python файл компилируется',lambda: bool(ast.parse(withfile.read_text())))
            mod=load_module(withfile)
            from fastapi.testclient import TestClient
            cli=TestClient(mod.app)
            r.check('liveness: 200 + alive',lambda: cli.get('/healthz').status_code==200 and cli.get('/healthz').json().get('status')=='alive')
            r.check('readiness: 200 + ready',lambda: cli.get('/readyz').status_code==200 and cli.get('/readyz').json().get('status')=='ready')
            r.check('422 для пустого/короткого вопроса',lambda: cli.post('/run',json={'question':'x'}).status_code==422)
            def valid():
                x=cli.post('/run',json={'question':'inspect pipeline'}); y=cli.post('/run',json={'question':'inspect pipeline'})
                a=x.json(); b=y.json(); uuid.UUID(a['request_id'])
                return x.status_code==200 and a['answer'] and a['request_id']!=b['request_id']
            r.check('POST /run выдаёт индивидуальный request_id',valid)
        elif tid=='A02':
            mod=load_module(W/tid/'tools.py')
            r.check('Pipeline fixture возвращён корректно',lambda: mod.execute_tool('gitlab.get_pipeline',{'pipeline_id':482})['status']=='failed')
            r.check('Events читаются только из ai-lab',lambda:mod.execute_tool('k8s.list_events',{'namespace':'ai-lab'})['events'][0]['reason']=='BackOff')
            def denies(name,args):
                try: mod.execute_tool(name,args); return False
                except (ValueError,PermissionError,KeyError,TypeError): return True
            r.check('read-only: write tools запрещены',lambda:denies('gitlab.delete_project',{'pipeline_id':482}))
            r.check('другой pipeline запрещён',lambda:denies('gitlab.get_pipeline',{'pipeline_id':99}))
            r.check('другой namespace запрещён',lambda:denies('k8s.list_events',{'namespace':'default'}))
            r.check('запрещены лишние аргументы',lambda:denies('k8s.list_events',{'namespace':'ai-lab','command':'exec'}))
        elif tid=='A03':
            mod=load_module(W/tid/'ollama_client.py')
            delivered=[]
            seq=[{'message':{'role':'assistant','content':'','tool_calls':[{'function':{'name':'gitlab.get_pipeline','arguments':{'pipeline_id':482}}}]}},
                 {'message':{'role':'assistant','content':'Fixture found'}}]
            def fake(payload): delivered.append(payload); return seq[len(delivered)-1]
            out=mod.chat('pipeline 482',{'gitlab.get_pipeline': lambda pipeline_id: {'id':pipeline_id}},send=fake)
            r.check('два раунда, tool call, финальный ответ',lambda:out==('Fixture found',['gitlab.get_pipeline']) and len(delivered)==2)
            r.check('role=tool отправлен обратно модели',lambda: any(m.get('role')=='tool' for m in delivered[-1]['messages']))
            def deny():
                try:mod.chat('danger',{},send=lambda x:{'message':{'tool_calls':[{'function':{'name':'delete_everything','arguments':{}}}]}});return False
                except PermissionError:return True
            r.check('запрещённый tool отвергнут',deny)
            def limits():
                try:mod.chat('repeat',{'gitlab.get_pipeline':lambda **x:{}},send=lambda x:{'message':{'tool_calls':[{'function':{'name':'gitlab.get_pipeline','arguments':{}}}] }},max_rounds=1);return False
                except RuntimeError:return True
            r.check('агент соблюдает лимит вызовов',limits)
            r.check('в реальном режиме есть Ollama /api/chat и timeout',lambda:'api/chat' in read(tid,'ollama_client.py') and 'timeout' in read(tid,'ollama_client.py'))
        elif tid=='M04':
            r.check('объявлен официальный MCPServer (SDK v2)',lambda:'mcp.server.mcpserver' in read(tid,'gitlab_mcp.py'))
            with stub_mcp():
                m=load_module(W/tid/'gitlab_mcp.py')
                r.check('объявлены два MCP tools',lambda:set(m.mcp.tools)=={'get_pipeline','get_failed_jobs'})
                r.check('get_pipeline читает fixture',lambda:m.get_pipeline(482)['id']==482)
                r.check('get_failed_jobs возвращает только failed',lambda:all(j['status']=='failed' for j in m.get_failed_jobs(482)))
                def deny():
                    try: m.get_pipeline(123);return False
                    except (ValueError,PermissionError):return True
                r.check('запрещён другой pipeline',deny)
            if shutil.which('python'):
                try:
                    import importlib.util
                    if importlib.util.find_spec('mcp') is None:r.skip('полноценный MCP protocol handshake','pip install -r requirements-mcp.txt; запустить Inspector')
                except (ValueError,ModuleNotFoundError):r.skip('полноценный MCP protocol handshake','нужна установка SDK mcp v2')
        elif tid=='M05':
            with stub_mcp():
                m=load_module(W/tid/'k8s_mcp.py')
                r.check('MCP list_events зарегистрирован',lambda:'list_events' in m.mcp.tools)
                os.environ.pop('K8S_LIVE',None)
                r.check('offline fixture: BackOff',lambda:m.list_events('ai-lab')['events'][0]['reason']=='BackOff')
                def deny():
                    try:m.list_events('default');return False
                    except (ValueError,PermissionError):return True
                r.check('namespace default заблокирован',deny)
                src=read(tid,'k8s_mcp.py')
                r.check('kubectl контекст зафиксирован, без shell=True',lambda:'kind-ai-labs' in src and 'shell=True' not in src and 'subprocess.run' in src)
        elif tid=='M06':
            m=load_module(W/tid/'policy.py')
            r.check('reader может читать pipeline demo',lambda:m.authorize('reader','gitlab.get_pipeline','sample/remit-demo') is True)
            r.check('reader может читать namespace ai-lab',lambda:m.authorize('reader','k8s.list_events','ai-lab') is True)
            r.check('delete запрещён, даже admin',lambda:m.authorize('admin','k8s.delete_pod','ai-lab') is False)
            r.check('unknown actor запрещён',lambda:m.authorize('anonymous','k8s.list_events','ai-lab') is False)
            r.check('default и wildcard запрещены',lambda:not m.authorize('reader','k8s.list_events','default') and not m.authorize('reader','*','*'))
        elif tid=='K07':
            ds=data(tid,'deployment.yaml'); dep=obj(ds,'Deployment');svc=obj(ds,'Service'); spec=dep['spec']; c=spec['template']['spec']['containers'][0]
            r.check('2 реплики + rollingUpdate без downtime',lambda:spec['replicas']>=2 and spec['strategy']['rollingUpdate']['maxUnavailable']==0)
            r.check('Service соответствует labels и targetPort',lambda:svc['spec']['selector']['app']=='agent-inference' and svc['spec']['ports'][0]['targetPort']==8080)
            r.check('liveness /healthz и readiness /readyz',lambda:c['livenessProbe']['httpGet']['path']=='/healthz' and c['livenessProbe']['httpGet']['port']==8080 and c['readinessProbe']['httpGet']['path']=='/readyz' and c['readinessProbe']['httpGet']['port']==8080)
            r.check('CPU/memory requests и limits определены',lambda: all(k in c['resources'][z] for z in ('requests','limits') for k in ('cpu','memory')))
            r.check('non-root + readOnlyRootFilesystem',lambda:spec['template']['spec']['securityContext']['runAsNonRoot'] and c['securityContext']['readOnlyRootFilesystem'])
            def deployed():
                out=run_cmd(['kubectl','--context','kind-ai-labs','-n','ai-lab','get','deployment','agent-inference','-o','json'])
                if out.returncode: return False
                d=json.loads(out.stdout);return d['status'].get('readyReplicas',0)>=2
            live_check(r,'LIVE: 2 Ready Pod в Kubernetes',deployed)
        elif tid=='K08':
            values=data(tid,'values.yaml')[0]
            r.check('values.yaml: 2 реплики',lambda:values['replicaCount']>=2)
            r.check('values.yaml: requests/limits',lambda:all(v in values['resources'][kind] for kind in ('requests','limits') for v in ('cpu','memory')))
            r.check('Chart.yaml: apiVersion v2',lambda:data(tid,'Chart.yaml')[0]['apiVersion']=='v2')
            if shutil.which('helm'):
                chart=str(W/tid)
                p=run_cmd(['helm','lint',chart]);r.check('helm lint проходит',lambda:p.returncode==0)
                out=run_cmd(['helm','template','agent-helm',chart,'--namespace','ai-lab'])
                def rendered():
                    import yaml
                    docs=list(yaml.safe_load_all(out.stdout)); d=obj(docs,'Deployment'); c=d['spec']['template']['spec']['containers'][0]
                    return out.returncode==0 and d['spec']['replicas']>=2 and c['readinessProbe']['httpGet']['path']=='/readyz' and c['livenessProbe']['httpGet']['path']=='/healthz' and bool(c['resources']['limits'])
                r.check('рендер содержит probes и лимиты',rendered)
            else:r.skip('helm lint + template','установи helm')
            def deployed():
                p=run_cmd(['kubectl','--context','kind-ai-labs','-n','ai-lab','get','deploy','agent-helm','-o','json']);return p.returncode==0 and json.loads(p.stdout)['status'].get('readyReplicas',0)>=2
            live_check(r,'LIVE: Helm release имеет 2 Ready Pod',deployed)
        elif tid=='K09':
            ds=data(tid,'ha.yaml'); pdb=obj(ds,'PodDisruptionBudget'); hpa=obj(ds,'HorizontalPodAutoscaler'); spec=hpa['spec']
            r.check('PDB minAvailable=1',lambda:pdb['spec']['minAvailable']==1)
            r.check('HPA min>=2 и max>=4',lambda:spec['minReplicas']>=2 and spec['maxReplicas']>=4)
            r.check('HPA масштабирует agent-inference',lambda:spec['scaleTargetRef']['name']=='agent-inference')
            r.check('HPA cpu utilization threshold',lambda:any(m.get('resource',{}).get('name')=='cpu' and m.get('resource',{}).get('target',{}).get('averageUtilization')==70 for m in spec['metrics']))
            live_check(r,'LIVE: HPA и PDB применены',lambda: run_cmd(['kubectl','--context','kind-ai-labs','-n','ai-lab','get','hpa,pdb']).returncode==0 and 'agent-inference' in run_cmd(['kubectl','--context','kind-ai-labs','-n','ai-lab','get','hpa,pdb']).stdout)
        elif tid=='C10':
            f=data(tid,'.gitlab-ci.yml')[0]; stages=f.get('stages',[])
            r.check('5 обязательных stages',lambda:set(['validate','test','scan','build','deploy']).issubset(set(stages)))
            jobs={k:v for k,v in f.items() if isinstance(v,dict) and v.get('stage')}
            r.check('jobs для каждого stage',lambda: set(stages).issubset({x['stage'] for x in jobs.values()}))
            r.check('pytest запускается в test stage',lambda:any('pytest' in ' '.join(j.get('script',[])) for j in jobs.values() if j['stage']=='test'))
            r.check('security scan настоящий, не echo',lambda:any('bandit' in ' '.join(j.get('script',[])) and 'pip-audit' in ' '.join(j.get('script',[])) for j in jobs.values() if j['stage']=='scan'))
            r.check('deploy требует ручного одобрения',lambda:all(any(rul.get('when')=='manual' for rul in j.get('rules',[])) or j.get('when')=='manual' for j in jobs.values() if j['stage']=='deploy'))
            r.check('build создаёт Docker image',lambda:any('docker build' in ' '.join(j.get('script',[])) for j in jobs.values() if j['stage']=='build'))
            r.skip('LIVE: GitLab pipeline success','Запусти проект на учебном GitLab Runner; приложи Job URL или скриншот, локально не проверяется')
        elif tid=='C11':
            src=read(tid,'security.sh')
            r.check('bash -n валиден',lambda:run_cmd(['bash','-n',str(W/tid/'security.sh')]).returncode==0)
            r.check('strict fail-fast',lambda:'set -euo pipefail' in src)
            r.check('bandit recursive',lambda:'bandit' in src and '-r service/' in src)
            r.check('pip-audit packages',lambda:'pip_audit' in src and 'requirements.txt' in src)
            r.check('не прячет ошибки',lambda:'|| true' not in src and 'scan passed' not in src.lower())
            r.skip('LIVE: security tool results','Нужно отдельно установить bandit и pip-audit; фиксируй отчёты при запуске CI')
        elif tid=='C12':
            src=read(tid,'smoke.py')
            r.check('скрипт Python синтаксически валиден',lambda:bool(ast.parse(src)))
            r.check('проверяет health/ready/run/metrics',lambda:all(x in src for x in ('/healthz','/readyz','/run','/metrics')))
            r.check('запросы с ограничением времени',lambda:'timeout=' in src)
            # Runs test script against real local uvicorn (no kubectl required)
            def real_smoke():
                sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
                env={**os.environ,'PYTHONPATH':str(ROOT)}
                proc=subprocess.Popen([sys.executable,'-m','uvicorn','service.app:app','--host','127.0.0.1','--port',str(port)],cwd=ROOT,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                try:
                    import requests
                    for _ in range(30):
                        if proc.poll() is not None: raise RuntimeError('uvicorn exited early')
                        try:
                            requests.get(f'http://127.0.0.1:{port}/healthz',timeout=.15).raise_for_status()
                            break
                        except requests.RequestException:time.sleep(.1)
                    p=subprocess.run([sys.executable,str(W/tid/'smoke.py')],cwd=ROOT,env={**env,'AGENT_URL':f'http://127.0.0.1:{port}'},capture_output=True,text=True,timeout=12)
                    if p.returncode:raise RuntimeError((p.stderr+p.stdout)[-200:])
                    return True
                finally:
                    proc.terminate()
                    try: proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:proc.kill()
            r.check('LIVE: smoke проходит на локальном FastAPI',real_smoke)
        elif tid=='S13':
            ds=data(tid,'rbac.yaml'); role=obj(ds,'Role'); sa=obj(ds,'ServiceAccount'); rules=role['rules']
            r.check('ServiceAccount agent-reader в ai-lab',lambda:sa['metadata']=={'name':'agent-reader','namespace':'ai-lab'})
            r.check('Role only namespaced',lambda:role['metadata']['namespace']=='ai-lab' and obj(ds,'RoleBinding')['metadata']['namespace']=='ai-lab')
            r.check('нет wildcard, secrets, write verbs',lambda: all('*' not in rule.get('resources',[]) and '*' not in rule.get('verbs',[]) and 'secrets' not in rule.get('resources',[]) and set(rule['verbs'])<=set(['get','list']) for rule in rules))
            r.check('events, pods, pods/log доступны',lambda: set(['pods','events','pods/log'])<=set(x for y in rules for x in y['resources']))
            r.check('не монтирует SA token по умолчанию',lambda:sa.get('automountServiceAccountToken') is False)
            def live_rbac():
                base=['kubectl','--context','kind-ai-labs','auth','can-i','--as','system:serviceaccount:ai-lab:agent-reader']
                q=lambda verb,res,ns:run_cmd(base+[verb,res,'-n',ns]).stdout.strip()=='yes'
                return q('get','pods','ai-lab') and not q('delete','pods','ai-lab') and not q('get','secrets','ai-lab') and not q('get','pods','default')
            live_check(r,'LIVE: kubectl auth can-i read/deny',live_rbac)
        elif tid=='S14':
            n=obj(data(tid,'networkpolicy.yaml'),'NetworkPolicy'); spec=n['spec']
            r.check('Ingress + Egress изоляция',lambda:set(spec['policyTypes'])=={'Ingress','Egress'})
            r.check('Ingress только approved-client:8080',lambda:all(rule.get('from') and all(x.get('podSelector',{}).get('matchLabels',{}).get('role')=='approved-client' for x in rule['from']) and rule['ports'][0]['port']==8080 for rule in spec['ingress']))
            r.check('DNS egress ограничен kube-system:53',lambda:any(any(p['port']==53 for p in rule.get('ports',[])) and any(t.get('namespaceSelector',{}).get('matchLabels',{}).get('kubernetes.io/metadata.name')=='kube-system' for t in rule.get('to',[])) for rule in spec['egress']))
            r.skip('LIVE: сетевое поведение проверено','Нужен CNI с реальным enforcement, отдельные client/denied Pod и network tests')
        elif tid=='S15':
            y=data(tid,'alerts.yaml')[0]; rules=y['groups'][0]['rules']; alerts={x['alert']:x for x in rules}
            r.check('Есть alerts по errors и latency',lambda:{'AgentHighErrorRate','AgentHighLatency'}<=set(alerts))
            r.check('Error rate использует rate и окно 5m',lambda:'rate(' in alerts['AgentHighErrorRate']['expr'] and '[5m]' in alerts['AgentHighErrorRate']['expr'])
            r.check('p95 через histogram_quantile(0.95)',lambda:'histogram_quantile(0.95' in alerts['AgentHighLatency']['expr'] and 'agent_request_duration_seconds_bucket' in alerts['AgentHighLatency']['expr'])
            r.check('for >= 5m для обеих метрик',lambda:all(int(x['for'].removesuffix('m'))>=5 for x in rules))
            if shutil.which('promtool'):
                p=run_cmd(['promtool','check','rules',str(W/tid/'alerts.yaml')]);r.check('promtool validate',lambda:p.returncode==0)
            else:r.skip('PromQL: promtool','установи promtool для настоящей проверки выражений')
        elif tid=='S16':
            src=W/tid/'backup.sh'
            r.check('bash -n синтаксис',lambda:run_cmd(['bash','-n',str(src)]).returncode==0)
            def backup():
                with tempfile.TemporaryDirectory() as td:
                    d=Path(td); state=d/'state';state.mkdir();(state/'runbooks.md').write_text('Read only runbook v1',encoding='utf8')
                    back=d/'backup'
                    p=run_cmd(['bash',str(src),str(state),str(back)],timeout=12)
                    if p.returncode: raise RuntimeError(p.stderr or p.stdout)
                    a=back/'ai-agent-state.tar.gz'; hashpath=back/'ai-agent-state.tar.gz.sha256'
                    if not a.is_file() or not hashpath.is_file():return False
                    check=subprocess.run(['sha256sum','--check',hashpath.name],cwd=back,capture_output=True,text=True)
                    if check.returncode:return False
                    restore=d/'restore';restore.mkdir()
                    subprocess.run(['tar','-C',str(restore),'-xzf',str(a)],check=True,capture_output=True)
                    return (restore/'runbooks.md').read_text()=='Read only runbook v1'
            r.check('реальный backup, integrity и restore',backup)
            def reject():
                with tempfile.TemporaryDirectory() as tmp:
                    d=Path(tmp);dest=d/'sub';dest.mkdir();return run_cmd(['bash',str(src),str(d),str(dest)]).returncode!=0
            r.check('запрет destination внутри source',reject)
        elif tid=='P17':
            src=read(tid,'report.md').lower()
            r.check('архитектура и MCP',lambda:all(x in src for x in ('architecture','mcp','fastapi')))
            r.check('разбор GitLab и Kubernetes incidents',lambda:all(x in src for x in ('gitlab','pipeline','kubernetes','backoff')))
            r.check('CI/CD, security, access control',lambda:all(x in src for x in ('ci/cd','rbac','security')))
            r.check('SLO, backup, GPU roadmap',lambda:all(x in src for x in ('slo','backup','selectel')))
            r.skip('Портфолио реально опубликовано','Добавь репозиторий, публичные диаграммы, скриншоты, ссылки на jobs и замеры')
        elif tid in __import__('modelops_checks').NEW_IDS:
            from modelops_checks import modelops_checker
            return modelops_checker(tid,r,W,ROOT)
        elif tid in __import__('gateway_checks').NEW_IDS:
            from gateway_checks import gateway_checker
            return gateway_checker(tid,r,W,ROOT)
        elif tid in __import__('aisec_checks').NEW_IDS:
            from aisec_checks import aisec_checker
            return aisec_checker(tid,r,W,ROOT)
        elif tid in __import__('inference_checks').NEW_IDS:
            from inference_checks import inference_checker
            return inference_checker(tid,r,W,ROOT)
        elif tid in __import__('platform_checks').NEW_IDS:
            from platform_checks import platform_checker
            return platform_checker(tid,r,W,ROOT)
        elif tid in __import__('agentarch_checks').NEW_IDS:
            from agentarch_checks import agentarch_checker
            return agentarch_checker(tid,r,W,ROOT)
        elif tid in __import__('extra_checks').NEW_IDS:
            from extra_checks import extra_checker
            return extra_checker(tid,r,W,ROOT)
        else:r.check('известный сценарий',lambda:False)
    except Exception as exc:
        r.results.append(('FAIL','Сценарий прервался: '+exc.__class__.__name__,str(exc)[:270]))
    return r
