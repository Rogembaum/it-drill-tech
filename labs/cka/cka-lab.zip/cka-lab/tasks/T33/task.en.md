In namespace `web` create an Ingress `shop` that uses the IngressClass `traefik` and routes:
- host `shop.cka.local`, path `/api` (type `Prefix`) → Service `api`, port `80`,
- host `shop.cka.local`, path `/` (type `Prefix`) → Service `ui`, port `80`.

Requests to `http://shop.cka.local/api` must be answered by `api`.
