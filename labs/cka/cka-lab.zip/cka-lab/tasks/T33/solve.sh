# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n web create ingress shop --class=traefik \
  --rule="shop.cka.local/api*=api:80" --rule="shop.cka.local/*=ui:80"
