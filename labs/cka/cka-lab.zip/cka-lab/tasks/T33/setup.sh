# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh web
for a in api ui; do
  kubectl -n web create deployment $a --image=busybox:1.36 -- sh -c "mkdir -p /www && echo $a-ok > /www/index.html && echo $a-ok > /www/api && httpd -f -p 80 -h /www" >/dev/null
  kubectl -n web expose deployment $a --port=80 >/dev/null
done
rollout_wait web deploy/api; rollout_wait web deploy/ui
