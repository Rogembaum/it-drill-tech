# сгенерировано src/build.py — правьте src/tasks/*.yaml
G=http://traefik.traefik.svc.cluster.local
chk "Ingress web/shop, класс traefik" '[ "$(jp -n web ingress shop "{.spec.ingressClassName}")" = traefik ]'
chk "правило /api → api:80 (Prefix)" '[ "$(jp -n web ingress shop "{.spec.rules[0].http.paths[?(@.path==\"/api\")].backend.service.name}:{.spec.rules[0].http.paths[?(@.path==\"/api\")].backend.service.port.number}:{.spec.rules[0].http.paths[?(@.path==\"/api\")].pathType}")" = api:80:Prefix ]'
chk "хост shop.cka.local" '[ "$(jp -n web ingress shop "{.spec.rules[0].host}")" = shop.cka.local ]'
chk "запрос /api уходит в api" 'sleep 2; probe default "" "wget -qO- -T3 --header \"Host: shop.cka.local\" $G/api" | grep -q api-ok'
chk "запрос / уходит в ui" 'probe default "" "wget -qO- -T3 --header \"Host: shop.cka.local\" $G/" | grep -q ui-ok'
probes_clean
