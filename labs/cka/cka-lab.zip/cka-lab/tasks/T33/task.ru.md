В `web` создайте Ingress `shop` (IngressClass `traefik`):
- хост `shop.cka.local`, путь `/api` (`Prefix`) → Service `api`, порт `80`,
- хост `shop.cka.local`, путь `/` (`Prefix`) → Service `ui`, порт `80`.

Запросы на `http://shop.cka.local/api` должен обрабатывать `api`.
