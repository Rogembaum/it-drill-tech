Pods in the cluster cannot resolve any names (for example `kubernetes.default`), although the CoreDNS Pods are running.

Find and fix the problem.
