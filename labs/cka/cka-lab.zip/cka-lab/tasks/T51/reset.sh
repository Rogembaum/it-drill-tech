# сгенерировано src/build.py — правьте src/tasks/*.yaml
s=$(cat "$LAB/.state/kube-dns-selector" 2>/dev/null); s=${s:-kube-dns}
kubectl -n kube-system patch svc kube-dns -p "{\"spec\":{\"selector\":{\"k8s-app\":\"$s\"}}}" >/dev/null
rm -f "$LAB/.state/kube-dns-selector"
