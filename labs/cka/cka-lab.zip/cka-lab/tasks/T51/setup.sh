# сгенерировано src/build.py — правьте src/tasks/*.yaml
mkdir -p "$LAB/.state"
[ -f "$LAB/.state/kube-dns-selector" ] || jp -n kube-system svc kube-dns '{.spec.selector.k8s-app}' > "$LAB/.state/kube-dns-selector"
kubectl -n kube-system patch svc kube-dns -p '{"spec":{"selector":{"k8s-app":"kube-dns-v2"}}}' >/dev/null
