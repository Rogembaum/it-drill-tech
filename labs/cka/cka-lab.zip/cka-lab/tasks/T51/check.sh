# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "у Service kube-dns есть endpoints" '[ -n "$(kubectl -n kube-system get endpointslices -l kubernetes.io/service-name=kube-dns -o jsonpath="{.items[*].endpoints[*].addresses[0]}")" ]'
chk "nslookup kubernetes.default из пода работает" 'for i in 1 2 3 4 5; do probe default "" "nslookup kubernetes.default.svc.cluster.local" | grep -q Address && exit 0; sleep 3; done; exit 1'
probes_clean
