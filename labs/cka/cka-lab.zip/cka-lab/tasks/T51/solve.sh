# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n kube-system patch svc kube-dns -p '{"spec":{"selector":{"k8s-app":"kube-dns"}}}'
