# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh inventory
kubectl -n inventory create deployment inventory-db --image=nginx:1.27-alpine --port=80 >/dev/null
kubectl -n inventory expose deployment inventory-db --port=80 >/dev/null
kubectl -n inventory create deployment inventory-api --image=busybox:1.36 -- sleep 36000 >/dev/null
kubectl -n inventory apply -f - >/dev/null <<'EOF'
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: default-deny-ingress}
spec: {podSelector: {}, policyTypes: [Ingress]}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: db-access}
spec:
  podSelector:
    matchLabels: {app: inventory-db}
  policyTypes: [Ingress]
  ingress:
  - from:
    - podSelector:
        matchLabels: {app: inventory-backend}
    ports:
    - {protocol: TCP, port: 3306}
EOF
rollout_wait inventory deploy/inventory-db; rollout_wait inventory deploy/inventory-api
