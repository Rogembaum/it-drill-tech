Pods of `inventory-api` in namespace `inventory` cannot connect to the database Service `inventory-db` (port `80`). A NetworkPolicy is responsible.

Fix the **existing** NetworkPolicy `db-access` (do not create new policies and do not delete any) so that **only** `inventory-api` Pods can reach the database on port `80`.
