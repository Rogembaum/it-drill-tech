# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n inventory patch netpol db-access --type=json -p '[{"op":"replace","path":"/spec/ingress/0/from/0/podSelector/matchLabels","value":{"app":"inventory-api"}},{"op":"replace","path":"/spec/ingress/0/ports/0/port","value":80}]'
