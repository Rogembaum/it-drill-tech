# сгенерировано src/build.py — правьте src/tasks/*.yaml
U=http://inventory-db.inventory.svc.cluster.local
chk "политик по-прежнему две (default-deny и db-access)" '[ "$(jp -n inventory netpol db-access "{.spec.ingress[*].ports[*].port}")" = 80 ] && [ "$(kubectl -n inventory get netpol -o name | sort | tr "\n" " ")" = "networkpolicy.networking.k8s.io/db-access networkpolicy.networking.k8s.io/default-deny-ingress " ]'
chk "под inventory-api → db: доступ есть" 'pod=$(kubectl -n inventory get pod -l app=inventory-api -o jsonpath="{.items[0].metadata.name}"); kubectl -n inventory exec "$pod" -- wget -qO- -T3 $U | grep -q nginx'
chk "под с другой меткой → db: заблокировано" '[ "$(jp -n inventory netpol db-access "{.spec.ingress[0].from[0].podSelector.matchLabels.app}")" = inventory-api ] && ! http_ok inventory "app=reporting" $U'
chk "разрешён только порт 80" '[ "$(jp -n inventory netpol db-access "{.spec.ingress[*].ports[*].port}")" = 80 ]'
probes_clean
