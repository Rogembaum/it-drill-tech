In namespace `infra` create a DaemonSet `node-agent` (image `busybox:1.36`, command `sleep 3600`) that runs one Pod on **every** node of the cluster, **including** control plane nodes.

Set resource requests `cpu: 10m`, `memory: 16Mi`.
