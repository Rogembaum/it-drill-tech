# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh infra
