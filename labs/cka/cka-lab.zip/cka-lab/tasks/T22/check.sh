# сгенерировано src/build.py — правьте src/tasks/*.yaml
n=$(kubectl get nodes --no-headers | wc -l | tr -d ' ')
chk "DaemonSet infra/node-agent существует" 'kubectl -n infra get ds node-agent'
chk "toleration для control plane" 'jp -n infra ds node-agent "{range .spec.template.spec.tolerations[*]}{.key}|{.operator}{\"\\n\"}{end}" | grep -Eq "^(node-role\.kubernetes\.io/control-plane\|.*|\|Exists)$"'
chk "desiredNumberScheduled равно числу узлов" '[ "$(jp -n infra ds node-agent "{.status.desiredNumberScheduled}")" = "$n" ]'
chk "requests cpu 10m, memory 16Mi" '[ "$(jp -n infra ds node-agent "{.spec.template.spec.containers[0].resources.requests.cpu}/{.spec.template.spec.containers[0].resources.requests.memory}")" = 10m/16Mi ]'
