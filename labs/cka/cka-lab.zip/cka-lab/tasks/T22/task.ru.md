В `infra` создайте DaemonSet `node-agent` (образ `busybox:1.36`, команда `sleep 3600`), который запускает по поду на **каждом** узле, **включая** control plane.

Requests: `cpu: 10m`, `memory: 16Mi`.
