# сгенерировано src/build.py — правьте src/tasks/*.yaml
cat <<'EOF' | kubectl apply -f -
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: node-agent
  namespace: infra
spec:
  selector:
    matchLabels: {app: node-agent}
  template:
    metadata:
      labels: {app: node-agent}
    spec:
      tolerations:
      - operator: Exists
      containers:
      - name: agent
        image: busybox:1.36
        command: ["sleep", "3600"]
        resources:
          requests: {cpu: 10m, memory: 16Mi}
EOF
sleep 5
