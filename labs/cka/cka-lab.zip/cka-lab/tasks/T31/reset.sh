# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_drop app-fe app-be
