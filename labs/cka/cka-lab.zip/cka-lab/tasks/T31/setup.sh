# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh app-fe app-be
kubectl -n app-be create deployment backend --image=nginx:1.27-alpine --port=80 >/dev/null
kubectl -n app-be expose deployment backend --port=80 >/dev/null
kubectl -n app-be apply -f - >/dev/null <<'EOF'
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: default-deny-ingress}
spec: {podSelector: {}, policyTypes: [Ingress]}
EOF
rm -rf "$TD"; mkdir -p "$TD"
cat > "$TD/netpol-1.yaml" <<'EOF'
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-all-namespaces
  namespace: app-be
spec:
  podSelector: {}
  policyTypes: [Ingress]
  ingress:
  - from:
    - namespaceSelector: {}
EOF
cat > "$TD/netpol-2.yaml" <<'EOF'
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-fe-namespace
  namespace: app-be
spec:
  podSelector:
    matchLabels: {app: backend}
  policyTypes: [Ingress]
  ingress:
  - from:
    - namespaceSelector:
        matchLabels: {kubernetes.io/metadata.name: app-fe}
EOF
cat > "$TD/netpol-3.yaml" <<'EOF'
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-fe-pods-80
  namespace: app-be
spec:
  podSelector:
    matchLabels: {app: backend}
  policyTypes: [Ingress]
  ingress:
  - from:
    - namespaceSelector:
        matchLabels: {kubernetes.io/metadata.name: app-fe}
      podSelector:
        matchLabels: {role: frontend}
    ports:
    - {protocol: TCP, port: 80}
EOF
cat > "$TD/netpol-4.yaml" <<'EOF'
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-frontend-label
  namespace: app-be
spec:
  podSelector:
    matchLabels: {app: backend}
  policyTypes: [Ingress]
  ingress:
  - from:
    - podSelector:
        matchLabels: {role: frontend}
    ports:
    - {protocol: TCP, port: 80}
EOF
rollout_wait app-be deploy/backend
