Frontend Pods (`role=frontend`) in namespace `app-fe` cannot reach the Service `backend` in namespace `app-be` (port `80`) because of a default-deny ingress policy.

Review the NetworkPolicy manifests in `~/cka/t31/`. Apply **the one** policy that allows the frontend Pods to reach the backend **and is the least permissive**.

Do not edit the files and do not delete or modify the default-deny policy.
