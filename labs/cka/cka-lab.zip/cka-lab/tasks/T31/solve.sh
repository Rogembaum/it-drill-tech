# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl apply -f "$TD/netpol-3.yaml"
