# сгенерировано src/build.py — правьте src/tasks/*.yaml
U=http://backend.app-be.svc.cluster.local
chk "применена allow-fe-pods-80" 'kubectl -n app-be get netpol allow-fe-pods-80'
chk "других разрешающих политик нет" '[ "$(kubectl -n app-be get netpol -o name | sort | tr "\n" " ")" = "networkpolicy.networking.k8s.io/allow-fe-pods-80 networkpolicy.networking.k8s.io/default-deny-ingress " ]'
chk "app-fe, role=frontend → backend: доступ есть" 'http_ok app-fe "role=frontend" $U'
chk "app-fe, role=batch → backend: заблокировано" 'kubectl -n app-be get netpol allow-fe-pods-80 && ! http_ok app-fe "role=batch" $U'
probes_clean
