# сгенерировано src/build.py — правьте src/tasks/*.yaml
for r in billing legacy; do helm -n $r uninstall $r >/dev/null 2>&1 || true; done
ns_fresh billing legacy
mkdir -p "$TD" "$LAB/charts"; rm -f "$TD/releases.txt"
rm -rf "$LAB/charts/webapp"; cp -r "$KIT/assets/charts/webapp" "$LAB/charts/"
C="$LAB/charts/webapp"
helm install billing "$C" -n billing --set crds.install=false --set replicaCount=2 --wait --timeout 3m >/dev/null
helm upgrade billing "$C" -n billing --set crds.install=false --set replicaCount=2 --set image.tag=1.28-alpine --wait --timeout 3m >/dev/null
helm upgrade billing "$C" -n billing --set crds.install=false --set replicaCount=2 --set image.tag=9.9-does-not-exist >/dev/null
helm install legacy "$C" -n legacy --set crds.install=false >/dev/null
