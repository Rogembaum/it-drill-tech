Release `billing` in namespace `billing` was upgraded several times and its Pods no longer start.

1. Roll the release back to the **most recent revision whose Pods were running**.
2. Uninstall the release `legacy` from namespace `legacy`.
3. Write the names of all Helm releases in all namespaces to `~/cka/t04/releases.txt` (only names, one per line).
