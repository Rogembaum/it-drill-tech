# сгенерировано src/build.py — правьте src/tasks/*.yaml
for r in billing legacy; do helm -n $r uninstall $r >/dev/null 2>&1 || true; done
ns_drop billing legacy
