# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "billing: последняя ревизия — откат на ревизию 2" 'helm -n billing history billing --max 1 | tail -1 | grep -q "Rollback to 2"'
chk "billing: образ nginx:1.28-alpine" '[ "$(jp -n billing deploy billing-webapp "{.spec.template.spec.containers[0].image}")" = nginx:1.28-alpine ]'
chk "billing: все реплики готовы" 'rollout_wait billing deploy/billing-webapp 90s'
chk "релиз legacy удалён" '! helm -n legacy status legacy'
chk "releases.txt: есть billing, нет legacy" 'grep -qx billing "$TD/releases.txt" && ! grep -qx legacy "$TD/releases.txt"'
chk "releases.txt: только имена" '[ -s "$TD/releases.txt" ] && ! grep -q -E "NAMESPACE|deployed|\s" "$TD/releases.txt"'
