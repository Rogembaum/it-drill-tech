# сгенерировано src/build.py — правьте src/tasks/*.yaml
helm -n billing rollback billing 2 --wait --timeout 3m
helm -n legacy uninstall legacy
helm list -A -q > "$TD/releases.txt"
