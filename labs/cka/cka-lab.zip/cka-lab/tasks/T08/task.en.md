On node `cka-worker` determine:
1. the container runtime endpoint the kubelet uses,
2. the file name of the CNI configuration in use,
3. the CSI drivers registered in the cluster.

Write the answers to `/root/interfaces.txt` **on the node**, in this format (one per line):
```
cri=<endpoint>
cni=<file name>
csi=<comma separated driver names, or none>
```
