# сгенерировано src/build.py — правьте src/tasks/*.yaml
cni=$(node $W1 'ls /etc/cni/net.d/ | grep -E "\.conf(list)?$" | sort | head -1')
csi=$(kubectl get csidrivers -o jsonpath='{.items[*].metadata.name}' | tr ' ' ',')
node $W1 "printf 'cri=unix:///run/containerd/containerd.sock\ncni=%s\ncsi=%s\n' '$cni' '${csi:-none}' > /root/interfaces.txt"
