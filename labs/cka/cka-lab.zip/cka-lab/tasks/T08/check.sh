# сгенерировано src/build.py — правьте src/tasks/*.yaml
cni=$(node $W1 'ls /etc/cni/net.d/ | grep -E "\.conf(list)?$" | sort | head -1')
csi=$(kubectl get csidrivers -o jsonpath='{.items[*].metadata.name}' | tr ' ' ',')
f() { node $W1 'cat /root/interfaces.txt' 2>/dev/null; }
chk "файл /root/interfaces.txt на $W1 существует" '[ -n "$(f)" ]'
chk "cri указывает на сокет containerd" 'f | grep -Eq "^cri=(unix://)?/run/containerd/containerd\.sock$"'
chk "cni = имя файла конфигурации из /etc/cni/net.d" 'f | grep -qx "cni=$cni"'
chk "csi = список CSIDriver кластера (или none)" 'f | grep -qx "csi=${csi:-none}"'
