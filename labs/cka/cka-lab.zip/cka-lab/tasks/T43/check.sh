# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "у $W1 метка tier=batch" '[ "$(jp node $W1 "{.metadata.labels.tier}")" = batch ]'
chk "nodeSelector tier=batch на месте" '[ "$(jp node $W1 "{.metadata.labels.tier}")" = batch ] && [ "$(jp -n reports deploy reports "{.spec.template.spec.nodeSelector.tier}")" = batch ]'
chk "CPU request = 100m" '[ "$(jp -n reports deploy reports "{.spec.template.spec.containers[0].resources.requests.cpu}")" = 100m ]'
chk "2 реплики Ready" 'rollout_wait reports deploy/reports 90s && [ "$(jp -n reports deploy reports "{.status.readyReplicas}")" = 2 ]'
