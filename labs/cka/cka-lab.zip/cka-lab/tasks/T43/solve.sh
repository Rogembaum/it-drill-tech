# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl label node $W1 tier=batch --overwrite
kubectl -n reports set resources deploy reports -c=reports --requests=cpu=100m,memory=32Mi
kubectl -n reports rollout status deploy/reports --timeout=90s
