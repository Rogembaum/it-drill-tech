Поды Deployment `reports` в `reports` висят в `Pending`.

Запустите их, **не убирая nodeSelector**: поставьте нужную метку узлу `cka-worker` и установите CPU request контейнера `100m`.
