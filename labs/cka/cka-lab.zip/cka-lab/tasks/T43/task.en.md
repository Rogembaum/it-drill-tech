Pods of the Deployment `reports` in namespace `reports` are stuck in `Pending`.

Make them run **without removing the nodeSelector** of the Deployment: label the node `cka-worker` accordingly and set the CPU request of the container to `100m`.
