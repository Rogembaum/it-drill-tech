# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh reports
kubectl label nodes --all tier- >/dev/null 2>&1 || true
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: reports
  namespace: reports
spec:
  replicas: 2
  selector:
    matchLabels: {app: reports}
  template:
    metadata:
      labels: {app: reports}
    spec:
      nodeSelector:
        tier: batch
      containers:
      - name: reports
        image: busybox:1.36
        command: ["sleep", "3600"]
        resources:
          requests: {cpu: "64", memory: 32Mi}
EOF
