# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl label nodes --all tier- >/dev/null 2>&1 || true
ns_drop reports
