# сгенерировано src/build.py — правьте src/tasks/*.yaml
ip=$(kubectl get nodes -o jsonpath='{range .items[*]}{.status.addresses[?(@.type=="InternalIP")].address}{"\n"}{end}' | grep -m1 .)
chk "containerPort 80 с именем http" '[ "$(jp -n expose deploy frontend "{.spec.template.spec.containers[0].ports[?(@.name==\"http\")].containerPort}")" = 80 ]'
chk "Service NodePort, port 80, nodePort 30180" '[ "$(jp -n expose svc frontend-svc "{.spec.type}/{.spec.ports[0].port}/{.spec.ports[0].nodePort}")" = NodePort/80/30180 ]'
chk "targetPort = http" '[ "$(jp -n expose svc frontend-svc "{.spec.ports[0].targetPort}")" = http ]'
chk "у Service 2 endpoint-а" 'rollout_wait expose deploy/frontend 90s && [ "$(kubectl -n expose get endpointslices -l kubernetes.io/service-name=frontend-svc -o jsonpath="{range .items[*].endpoints[?(@.conditions.ready==true)]}{.addresses[0]} {end}" | wc -w | tr -d " ")" = 2 ]'
chk "приложение отвечает на IP узла, порт 30180" 'http_ok default "" "http://$ip:30180" "nginx"'
probes_clean
