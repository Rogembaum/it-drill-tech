1. В Deployment `frontend` (`expose`) добавьте контейнеру порт `80/TCP` с именем `http`.
2. Создайте Service `frontend-svc` типа `NodePort`: порт `80`, targetPort — именованный порт `http`, nodePort `30180`.
3. Проверьте, что приложение доступно по IP любого узла на порту `30180`.
