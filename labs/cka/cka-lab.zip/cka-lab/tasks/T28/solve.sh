# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n expose patch deploy frontend --type=json -p '[{"op":"add","path":"/spec/template/spec/containers/0/ports","value":[{"name":"http","containerPort":80,"protocol":"TCP"}]}]'
cat <<'EOF' | kubectl apply -f -
apiVersion: v1
kind: Service
metadata:
  name: frontend-svc
  namespace: expose
spec:
  type: NodePort
  selector: {app: frontend}
  ports:
  - port: 80
    targetPort: http
    nodePort: 30180
EOF
kubectl -n expose rollout status deploy/frontend --timeout=90s
