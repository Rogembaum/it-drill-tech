# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh expose
kubectl -n expose create deployment frontend --image=nginx:1.27-alpine --replicas=2 >/dev/null
