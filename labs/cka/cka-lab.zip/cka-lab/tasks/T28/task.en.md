1. Update the Deployment `frontend` in namespace `expose`: add the container port `80/TCP` with the name `http`.
2. Create a Service `frontend-svc` of type `NodePort` that exposes the Pods on port `80`, targets the named port `http` and uses node port `30180`.
3. Verify that the application is reachable on any node's IP address on port `30180`.
