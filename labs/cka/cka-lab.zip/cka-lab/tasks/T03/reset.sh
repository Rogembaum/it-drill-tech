# сгенерировано src/build.py — правьте src/tasks/*.yaml
helm -n shop uninstall shop >/dev/null 2>&1 || true
kubectl delete crd widgets.webapp.cka.io --ignore-not-found >/dev/null
ns_drop shop
