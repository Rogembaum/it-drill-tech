Helm-чарт лежит в `~/cka/charts/webapp`.

1. Установите его как релиз `shop` в пространство имён `shop` (создайте его) с `replicaCount=3` и `service.type=NodePort`.
2. Отрендерите манифесты чарта для релиза `shop` **без** CRD, которые чарт умеет создавать (значение `crds.install`), и сохраните в `~/cka/t03/shop-rendered.yaml`. Больше ничего не устанавливайте.
