A Helm chart is located in `~/cka/charts/webapp`.

1. Install it as release `shop` in namespace `shop` (create the namespace) with `replicaCount=3` and `service.type=NodePort`.
2. Render the manifests of this chart for release `shop` **without** the CRDs the chart can create (the chart value is `crds.install`) and save the output to `~/cka/t03/shop-rendered.yaml`. Do not install anything else.
