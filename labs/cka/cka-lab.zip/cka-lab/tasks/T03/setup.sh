# сгенерировано src/build.py — правьте src/tasks/*.yaml
helm -n shop uninstall shop >/dev/null 2>&1 || true
kubectl delete crd widgets.webapp.cka.io --ignore-not-found >/dev/null
ns_drop shop
mkdir -p "$TD" "$LAB/charts"; rm -f "$TD/shop-rendered.yaml"
rm -rf "$LAB/charts/webapp"; cp -r "$KIT/assets/charts/webapp" "$LAB/charts/"
