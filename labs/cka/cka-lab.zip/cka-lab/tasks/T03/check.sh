# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "релиз shop в статусе deployed" 'helm -n shop status shop | grep -q "STATUS: deployed"'
chk "Deployment shop-webapp: 3 готовые реплики" '[ "$(jp -n shop deploy shop-webapp "{.status.readyReplicas}")" = 3 ]'
chk "Service shop-webapp типа NodePort" '[ "$(jp -n shop svc shop-webapp "{.spec.type}")" = NodePort ]'
chk "файл shop-rendered.yaml содержит Deployment shop-webapp" 'grep -q "kind: Deployment" "$TD/shop-rendered.yaml" && grep -q "name: shop-webapp" "$TD/shop-rendered.yaml"'
chk "в файле нет CustomResourceDefinition" '[ -s "$TD/shop-rendered.yaml" ] && ! grep -q CustomResourceDefinition "$TD/shop-rendered.yaml"'
chk "лишних релизов в shop нет" '[ "$(helm -n shop list -q | wc -l | tr -d " ")" = 1 ]'
