# сгенерировано src/build.py — правьте src/tasks/*.yaml
helm install shop "$LAB/charts/webapp" -n shop --create-namespace \
  --set replicaCount=3 --set service.type=NodePort --wait
helm template shop "$LAB/charts/webapp" -n shop --set crds.install=false > "$TD/shop-rendered.yaml"
