The Deployment `web` in namespace `rollout` has a failing rollout.

1. Roll the Deployment back to the revision that used the image `nginx:1.27-alpine`.
2. Change its update strategy to `maxSurge: 2` and `maxUnavailable: 0`.
3. Scale it to `4` replicas and make sure all of them are available.
