# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh rollout
kubectl -n rollout create deployment web --image=nginx:1.27-alpine --replicas=3 >/dev/null
kubectl -n rollout annotate deploy web kubernetes.io/change-cause="initial release 1.27" >/dev/null
rollout_wait rollout deploy/web
kubectl -n rollout set image deploy/web nginx=nginx:1.28-alpine >/dev/null
kubectl -n rollout annotate deploy web kubernetes.io/change-cause="upgrade to 1.28" --overwrite >/dev/null
rollout_wait rollout deploy/web
kubectl -n rollout set image deploy/web nginx=nginx:9.9-does-not-exist >/dev/null
kubectl -n rollout annotate deploy web kubernetes.io/change-cause="upgrade to 9.9" --overwrite >/dev/null
