# сгенерировано src/build.py — правьте src/tasks/*.yaml
rev=$(kubectl -n rollout get rs -o jsonpath='{range .items[*]}{.metadata.annotations.deployment\.kubernetes\.io/revision}{" "}{.spec.template.spec.containers[0].image}{"\n"}{end}' | awk '$2=="nginx:1.27-alpine"{print $1}')
kubectl -n rollout rollout undo deploy/web --to-revision="$rev"
kubectl -n rollout patch deploy web -p '{"spec":{"strategy":{"type":"RollingUpdate","rollingUpdate":{"maxSurge":2,"maxUnavailable":0}}}}'
kubectl -n rollout scale deploy web --replicas=4
kubectl -n rollout rollout status deploy/web --timeout=120s
