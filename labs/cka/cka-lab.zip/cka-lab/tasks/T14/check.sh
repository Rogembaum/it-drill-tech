# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "образ nginx:1.27-alpine" '[ "$(jp -n rollout deploy web "{.spec.template.spec.containers[0].image}")" = nginx:1.27-alpine ]'
chk "maxSurge=2, maxUnavailable=0" '[ "$(jp -n rollout deploy web "{.spec.strategy.rollingUpdate.maxSurge}/{.spec.strategy.rollingUpdate.maxUnavailable}")" = 2/0 ]'
chk "4 реплики, все доступны" 'rollout_wait rollout deploy/web 90s && [ "$(jp -n rollout deploy web "{.status.availableReplicas}")" = 4 ]'
chk "нет подов с несуществующим образом" '! kubectl -n rollout get pods -o jsonpath="{.items[*].spec.containers[*].image}" | grep -q 9.9'
