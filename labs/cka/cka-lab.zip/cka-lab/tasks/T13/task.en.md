The cluster consists of the control plane node `controlplane` and the worker `node01` and runs Kubernetes `v1.N`. Upgrade **both** nodes to the latest patch release of `v1.N+1` using kubeadm.

- Drain each node before upgrading kubelet and kubectl, and uncordon it afterwards.
- Do not upgrade etcd separately: let kubeadm handle it.
- Do not upgrade the CNI or any add-ons.
