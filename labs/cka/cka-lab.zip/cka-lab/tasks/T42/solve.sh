# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n payments patch svc payment-api --type=json -p '[{"op":"replace","path":"/spec/selector","value":{"app":"payment-api","tier":"backend"}},{"op":"replace","path":"/spec/ports/0/targetPort","value":80}]'
