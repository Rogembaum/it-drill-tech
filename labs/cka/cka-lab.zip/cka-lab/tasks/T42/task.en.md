The Service `payment-api` in namespace `payments` does not route traffic to the Pods of the Deployment `payment-api`.

Fix the **Service** (do not modify the Deployment) so that `http://payment-api.payments` returns the application page.
