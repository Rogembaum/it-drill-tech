# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "селектор Service совпадает с метками подов" '[ "$(jp -n payments svc payment-api "{.spec.selector.app}")" = payment-api ]'
chk "у Service есть endpoints" '[ -n "$(kubectl -n payments get endpointslices -l kubernetes.io/service-name=payment-api -o jsonpath="{.items[*].endpoints[*].addresses[0]}")" ]'
chk "Deployment не менялся" '[ "$(jp -n payments svc payment-api "{.spec.selector.app}")" = payment-api ] && [ "$(jp -n payments deploy payment-api "{.metadata.generation}")" = "$(cat "$LAB/.state/payments.gen")" ]'
chk "http://payment-api.payments отвечает" 'http_ok default "" http://payment-api.payments nginx'
probes_clean
