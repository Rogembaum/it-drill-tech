# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh payments
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: payment-api
  namespace: payments
spec:
  replicas: 2
  selector:
    matchLabels: {app: payment-api, tier: backend}
  template:
    metadata:
      labels: {app: payment-api, tier: backend}
    spec:
      containers:
      - name: api
        image: nginx:1.27-alpine
        ports:
        - {name: web, containerPort: 80}
---
apiVersion: v1
kind: Service
metadata:
  name: payment-api
  namespace: payments
spec:
  selector: {app: payment, tier: backend}
  ports:
  - port: 80
    targetPort: 8080
EOF
rollout_wait payments deploy/payment-api
mkdir -p "$LAB/.state"; jp -n payments deploy payment-api '{.metadata.generation}' > "$LAB/.state/payments.gen"
