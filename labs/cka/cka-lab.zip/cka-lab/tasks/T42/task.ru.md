Service `payment-api` в `payments` не отправляет трафик на поды Deployment `payment-api`.

Исправьте **Service** (Deployment не трогайте), чтобы `http://payment-api.payments` отдавал страницу приложения.
