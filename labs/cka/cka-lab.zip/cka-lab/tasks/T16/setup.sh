# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh autoscale
kubectl -n autoscale create deployment php --image=nginx:1.27-alpine >/dev/null
kubectl -n autoscale set resources deploy php --requests=cpu=100m,memory=32Mi --limits=cpu=200m,memory=64Mi >/dev/null
