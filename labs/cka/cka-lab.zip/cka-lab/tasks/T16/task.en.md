In namespace `autoscale` create a HorizontalPodAutoscaler `php` for the Deployment `php` that:
- targets an average CPU utilization of **50%**,
- scales between **2** and **8** replicas,
- uses a scale-down **stabilization window of 30 seconds**.

Use the API `autoscaling/v2`.
