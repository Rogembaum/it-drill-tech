# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "HPA autoscale/php существует" 'kubectl -n autoscale get hpa php'
chk "цель — Deployment php" '[ "$(jp -n autoscale hpa php "{.spec.scaleTargetRef.kind}/{.spec.scaleTargetRef.name}")" = Deployment/php ]'
chk "min 2, max 8" '[ "$(jp -n autoscale hpa php "{.spec.minReplicas}/{.spec.maxReplicas}")" = 2/8 ]'
chk "CPU averageUtilization = 50" '[ "$(jp -n autoscale hpa php "{.spec.metrics[?(@.resource.name==\"cpu\")].resource.target.averageUtilization}")" = 50 ]'
chk "scaleDown.stabilizationWindowSeconds = 30" '[ "$(jp -n autoscale hpa php "{.spec.behavior.scaleDown.stabilizationWindowSeconds}")" = 30 ]'
