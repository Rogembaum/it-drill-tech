В `autoscale` создайте HorizontalPodAutoscaler `php` для Deployment `php`:
- средняя загрузка CPU — **50%**,
- от **2** до **8** реплик,
- окно стабилизации при уменьшении — **30 секунд**.

Используйте API `autoscaling/v2`.
