# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh cicd
kubectl delete clusterrole deployment-manager --ignore-not-found >/dev/null
