# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl delete clusterrole deployment-manager --ignore-not-found >/dev/null
ns_drop cicd
