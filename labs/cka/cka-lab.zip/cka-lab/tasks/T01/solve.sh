# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n cicd create serviceaccount deploy-bot
kubectl create clusterrole deployment-manager --verb=get,list,create,update,delete \
  --resource=deployments,statefulsets,daemonsets
kubectl -n cicd create rolebinding deploy-bot-deployment-manager \
  --clusterrole=deployment-manager --serviceaccount=cicd:deploy-bot
