Создайте ServiceAccount `deploy-bot` в пространстве имён `cicd`.

Создайте ClusterRole `deployment-manager`, разрешающую **только** глаголы `get`, `list`, `create`, `update`, `delete` для `deployments`, `statefulsets` и `daemonsets`.

Выдайте эти права сервисному аккаунту **только в пределах `cicd`**.
