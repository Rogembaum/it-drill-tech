Create a ServiceAccount `deploy-bot` in namespace `cicd`.

Create a ClusterRole `deployment-manager` that allows **only** the verbs `get`, `list`, `create`, `update` and `delete` on `deployments`, `statefulsets` and `daemonsets`.

Grant these permissions to the ServiceAccount **only within namespace `cicd`**.
