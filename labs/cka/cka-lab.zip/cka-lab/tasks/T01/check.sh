# сгенерировано src/build.py — правьте src/tasks/*.yaml
SA=system:serviceaccount:cicd:deploy-bot
can() { [ "$(kubectl auth can-i "$@" --as=$SA 2>/dev/null)" = yes ]; }
chk "ServiceAccount cicd/deploy-bot существует" kubectl -n cicd get sa deploy-bot
chk "ClusterRole deployment-manager существует" kubectl get clusterrole deployment-manager
chk "может create deployments в cicd" can create deployments.apps -n cicd
chk "может delete daemonsets в cicd" can delete daemonsets.apps -n cicd
chk "может update statefulsets в cicd" can update statefulsets.apps -n cicd
chk "не может create deployments в default (привязка только к cicd)" 'can create deployments.apps -n cicd && ! can create deployments.apps -n default'
chk "не может patch/watch deployments (лишних глаголов нет)" 'can get deployments.apps -n cicd && ! can patch deployments.apps -n cicd && ! can watch deployments.apps -n cicd'
chk "не может delete pods" 'can delete deployments.apps -n cicd && ! can delete pods -n cicd'
