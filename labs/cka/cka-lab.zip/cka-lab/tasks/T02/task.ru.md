В `~/cka/t02/` лежат закрытый ключ и запрос на сертификат пользователя `john` (`john.key`, `john.csr`).

1. Создайте CertificateSigningRequest `john` из `john.csr`: signer `kubernetes.io/kube-apiserver-client`, usage `client auth`, срок действия **1 день**. Одобрите его.
2. Сохраните выданный сертификат в `~/cka/t02/john.crt`.
3. В `development` создайте Role `developer` (`create`, `get`, `list`, `update`, `delete` на `pods`) и привяжите её к пользователю `john`.
4. Добавьте в kubeconfig контекст `john@cka`: текущий кластер, пользователь `john` (ключ и сертификат встроены).
