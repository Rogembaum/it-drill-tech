# сгенерировано src/build.py — правьте src/tasks/*.yaml
cat <<EOF | kubectl apply -f -
apiVersion: certificates.k8s.io/v1
kind: CertificateSigningRequest
metadata:
  name: john
spec:
  request: $(base64 < "$TD/john.csr" | tr -d '\n')
  signerName: kubernetes.io/kube-apiserver-client
  expirationSeconds: 86400
  usages: ["client auth"]
EOF
kubectl certificate approve john
for i in $(seq 20); do c=$(kubectl get csr john -o jsonpath='{.status.certificate}'); [ -n "$c" ] && break; sleep 1; done
printf '%s' "$c" | base64 -d > "$TD/john.crt"
kubectl -n development create role developer --verb=create,get,list,update,delete --resource=pods
kubectl -n development create rolebinding developer-john --role=developer --user=john
kubectl config set-credentials john --client-key="$TD/john.key" --client-certificate="$TD/john.crt" --embed-certs=true
kubectl config set-context john@cka --cluster="$(kubectl config view --minify -o jsonpath='{.clusters[0].name}')" --user=john
