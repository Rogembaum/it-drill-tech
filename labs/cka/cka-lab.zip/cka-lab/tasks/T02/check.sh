# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "CSR john одобрен" '[ "$(jp csr john "{.status.conditions[?(@.type==\"Approved\")].status}")" = True ]'
chk "signerName = kubernetes.io/kube-apiserver-client" '[ "$(jp csr john "{.spec.signerName}")" = kubernetes.io/kube-apiserver-client ]'
chk "expirationSeconds = 86400 (1 день)" '[ "$(jp csr john "{.spec.expirationSeconds}")" = 86400 ]'
chk "john.crt — сертификат с CN=john" 'openssl x509 -in "$TD/john.crt" -noout -subject | grep -Eq "CN ?= ?john"'
chk "john может create pods в development" '[ "$(kubectl auth can-i create pods -n development --as john)" = yes ]'
chk "john не может читать secrets" 'kubectl -n development get role developer && [ "$(kubectl auth can-i list secrets -n development --as john 2>/dev/null)" = no ]'
chk "контекст john@cka работает" 'kubectl --context john@cka -n development get pods'
