A private key and a certificate signing request for the user `john` are in `~/cka/t02/` (`john.key`, `john.csr`).

1. Create a CertificateSigningRequest named `john` from `john.csr` with signer `kubernetes.io/kube-apiserver-client`, usage `client auth` and an expiration of **1 day**. Approve it.
2. Save the issued certificate to `~/cka/t02/john.crt`.
3. In namespace `development` create a Role `developer` that allows `create`, `get`, `list`, `update` and `delete` on `pods`, and bind it to the user `john`.
4. Add a kubeconfig context `john@cka` that uses the current cluster and the user `john` (key and certificate embedded).
