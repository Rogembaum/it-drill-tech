# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh development
mkdir -p "$TD"; rm -f "$TD"/john.*
kubectl delete csr john --ignore-not-found >/dev/null
kubectl config delete-context john@cka >/dev/null 2>&1 || true
kubectl config delete-user john >/dev/null 2>&1 || true
openssl genrsa -out "$TD/john.key" 2048 2>/dev/null
openssl req -new -key "$TD/john.key" -subj "/CN=john/O=dev-team" -out "$TD/john.csr" 2>/dev/null
