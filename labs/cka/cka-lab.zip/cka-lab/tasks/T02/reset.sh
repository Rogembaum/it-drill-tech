# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl delete csr john --ignore-not-found >/dev/null
kubectl config delete-context john@cka >/dev/null 2>&1 || true
kubectl config delete-user john >/dev/null 2>&1 || true
ns_drop development
