# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_drop storage
kubectl delete sc fast-local --ignore-not-found >/dev/null
if [ -f "$LAB/.state/default-sc" ]; then
  for s in $(cat "$LAB/.state/default-sc"); do kubectl annotate sc "$s" storageclass.kubernetes.io/is-default-class=true --overwrite >/dev/null; done
  rm -f "$LAB/.state/default-sc"
fi
for pv in $(kubectl get pv -o jsonpath='{range .items[?(@.spec.storageClassName=="fast-local")]}{.metadata.name}{" "}{end}'); do kubectl delete pv "$pv" --wait=false >/dev/null; done
