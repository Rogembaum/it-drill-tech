# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh storage
mkdir -p "$LAB/.state"
if [ ! -f "$LAB/.state/default-sc" ]; then
  kubectl get sc -o jsonpath='{range .items[?(@.metadata.annotations.storageclass\.kubernetes\.io/is-default-class=="true")]}{.metadata.name}{"\n"}{end}' | grep -v '^fast-local$' > "$LAB/.state/default-sc"
fi
kubectl delete sc fast-local --ignore-not-found >/dev/null
for s in $(cat "$LAB/.state/default-sc"); do kubectl annotate sc "$s" storageclass.kubernetes.io/is-default-class=true --overwrite >/dev/null; done
