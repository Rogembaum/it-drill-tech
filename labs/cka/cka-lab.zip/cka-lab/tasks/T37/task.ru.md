1. Создайте StorageClass `fast-local`: provisioner `rancher.io/local-path`, reclaimPolicy `Retain`, volumeBindingMode `WaitForFirstConsumer`, расширение томов разрешено.
2. Сделайте `fast-local` **единственным** классом по умолчанию в кластере.
3. В `storage` создайте PVC `fast-pvc` (`100Mi`, `ReadWriteOnce`) **без** указания класса и убедитесь, что он получил `fast-local`.
