1. Create a StorageClass `fast-local` with provisioner `rancher.io/local-path`, reclaim policy `Retain`, volume binding mode `WaitForFirstConsumer` and volume expansion allowed.
2. Make `fast-local` the **only** default StorageClass of the cluster.
3. In namespace `storage` create a PVC `fast-pvc` (`100Mi`, `ReadWriteOnce`) **without** specifying a storage class and verify that it uses `fast-local`.
