# сгенерировано src/build.py — правьте src/tasks/*.yaml
defs() { kubectl get sc -o jsonpath='{range .items[?(@.metadata.annotations.storageclass\.kubernetes\.io/is-default-class=="true")]}{.metadata.name}{"\n"}{end}'; }
chk "fast-local: rancher.io/local-path, Retain, WaitForFirstConsumer" '[ "$(jp sc fast-local "{.provisioner}/{.reclaimPolicy}/{.volumeBindingMode}")" = rancher.io/local-path/Retain/WaitForFirstConsumer ]'
chk "allowVolumeExpansion: true" '[ "$(jp sc fast-local "{.allowVolumeExpansion}")" = true ]'
chk "fast-local — класс по умолчанию" 'defs | grep -qx fast-local'
chk "других классов по умолчанию нет" 'defs | grep -qx fast-local && [ "$(defs | wc -l | tr -d " ")" = 1 ]'
chk "PVC fast-pvc получил класс fast-local" '[ "$(jp -n storage pvc fast-pvc "{.spec.storageClassName}")" = fast-local ]'
chk "PVC 100Mi, ReadWriteOnce" '[ "$(jp -n storage pvc fast-pvc "{.spec.resources.requests.storage}/{.spec.accessModes[0]}")" = 100Mi/ReadWriteOnce ]'
