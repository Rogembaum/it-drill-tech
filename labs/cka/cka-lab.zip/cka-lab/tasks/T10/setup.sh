# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $W2 'rm -f /etc/sysctl.d/k8s.conf /etc/modules-load.d/k8s.conf; sysctl -qw net.ipv4.ip_forward=0'
