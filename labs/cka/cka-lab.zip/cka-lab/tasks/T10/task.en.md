Node `cka-worker2` must be prepared for running Kubernetes.

Configure the following kernel parameters so that they are applied **immediately and persist across reboots** (use the file `/etc/sysctl.d/k8s.conf`):
```
net.ipv4.ip_forward = 1
net.bridge.bridge-nf-call-iptables = 1
net.bridge.bridge-nf-call-ip6tables = 1
```
Also make sure the kernel modules `overlay` and `br_netfilter` are loaded at boot (file `/etc/modules-load.d/k8s.conf`).
