Подготовьте узел `cka-worker2` к работе Kubernetes.

Задайте параметры ядра так, чтобы они применились **сразу и сохранились после перезагрузки** (файл `/etc/sysctl.d/k8s.conf`): `net.ipv4.ip_forward = 1`, `net.bridge.bridge-nf-call-iptables = 1`, `net.bridge.bridge-nf-call-ip6tables = 1`.

Также настройте загрузку модулей `overlay` и `br_netfilter` при старте (файл `/etc/modules-load.d/k8s.conf`).
