# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $W2 'sysctl -qw net.ipv4.ip_forward=1'
