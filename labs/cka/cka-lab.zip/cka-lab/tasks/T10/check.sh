# сгенерировано src/build.py — правьте src/tasks/*.yaml
sc() { node $W2 'cat /etc/sysctl.d/k8s.conf' 2>/dev/null; }
ml() { node $W2 'cat /etc/modules-load.d/k8s.conf' 2>/dev/null; }
chk "k8s.conf: net.ipv4.ip_forward = 1" 'sc | grep -Eq "^net\.ipv4\.ip_forward *= *1"'
chk "k8s.conf: bridge-nf-call-iptables и -ip6tables = 1" 'sc | grep -Eq "^net\.bridge\.bridge-nf-call-iptables *= *1" && sc | grep -Eq "^net\.bridge\.bridge-nf-call-ip6tables *= *1"'
chk "ip_forward применён сейчас" '[ "$(node $W2 "sysctl -n net.ipv4.ip_forward")" = 1 ]'
chk "modules-load.d/k8s.conf: overlay и br_netfilter" 'ml | grep -qx overlay && ml | grep -qx br_netfilter'
