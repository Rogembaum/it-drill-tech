# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "kube-scheduler использует /etc/kubernetes/scheduler.conf" 'node $CP "grep -q -- --kubeconfig=/etc/kubernetes/scheduler.conf\$ /etc/kubernetes/manifests/kube-scheduler.yaml"'
chk "под kube-scheduler Ready" 'kubectl -n kube-system wait --for=condition=Ready pod -l component=kube-scheduler --timeout=60s'
chk "sched-test: 2 реплики Ready" 'rollout_wait sched-lab deploy/sched-test 90s'
