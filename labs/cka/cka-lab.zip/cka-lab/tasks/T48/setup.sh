# сгенерировано src/build.py — правьте src/tasks/*.yaml
manifest_backup kube-scheduler
node $CP "sed -i 's#--kubeconfig=/etc/kubernetes/scheduler.conf#--kubeconfig=/etc/kubernetes/scheduler.conff#' /etc/kubernetes/manifests/kube-scheduler.yaml"
sleep 20
ns_fresh sched-lab
kubectl -n sched-lab create deployment sched-test --image=nginx:1.27-alpine --replicas=2 >/dev/null
