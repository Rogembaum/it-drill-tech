New Pods in the cluster stay in `Pending` state and have no scheduling events.

Find and fix the problem on node `cka-control-plane`. The Deployment `sched-test` in namespace `sched-lab` must be running afterwards.
