# сгенерировано src/build.py — правьте src/tasks/*.yaml
manifest_restore kube-scheduler
ns_drop sched-lab
