# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $CP "sed -i 's#scheduler.conff#scheduler.conf#' /etc/kubernetes/manifests/kube-scheduler.yaml"
sleep 15
kubectl -n sched-lab rollout status deploy/sched-test --timeout=120s
