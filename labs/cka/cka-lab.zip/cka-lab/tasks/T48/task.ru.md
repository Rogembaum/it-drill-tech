Новые поды висят в `Pending`, событий планировщика у них нет.

Найдите и исправьте проблему на `cka-control-plane`. После этого Deployment `sched-test` в `sched-lab` должен работать.
