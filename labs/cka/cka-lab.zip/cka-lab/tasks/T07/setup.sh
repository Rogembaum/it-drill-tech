# сгенерировано src/build.py — правьте src/tasks/*.yaml
kind delete cluster --name cka-cni >/dev/null 2>&1 || true
cat > "$LAB/.kind-cka-cni.yaml" <<'EOF'
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
networking:
  disableDefaultCNI: true
  podSubnet: 192.168.0.0/16
nodes:
- role: control-plane
- role: worker
EOF
kind create cluster --name cka-cni --config "$LAB/.kind-cka-cni.yaml" ${KIND_IMAGE:+--image "$KIND_IMAGE"} --wait 0s
kubectl config use-context kind-cka >/dev/null
v=$(curl -fsSL https://api.github.com/repos/projectcalico/calico/releases/latest 2>/dev/null | sed -n 's/.*"tag_name": *"\([^"]*\)".*/\1/p' | head -1)
echo
echo "  Calico: актуальная версия ${v:-<см. github.com/projectcalico/calico/releases>}"
[ -n "$v" ] && echo "  https://raw.githubusercontent.com/projectcalico/calico/$v/manifests/tigera-operator.yaml"
[ -n "$v" ] && echo "  https://raw.githubusercontent.com/projectcalico/calico/$v/manifests/custom-resources.yaml"
