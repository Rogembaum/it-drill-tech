# сгенерировано src/build.py — правьте src/tasks/*.yaml
v=$(curl -fsSL https://api.github.com/repos/projectcalico/calico/releases/latest | sed -n 's/.*"tag_name": *"\([^"]*\)".*/\1/p' | head -1)
C="--context kind-cka-cni"
kubectl $C create -f "https://raw.githubusercontent.com/projectcalico/calico/$v/manifests/tigera-operator.yaml"
kubectl $C wait --for=condition=Established crd/installations.operator.tigera.io --timeout=120s
kubectl $C create -f "https://raw.githubusercontent.com/projectcalico/calico/$v/manifests/custom-resources.yaml"
for i in $(seq 60); do kubectl $C get ds -A --no-headers 2>/dev/null | grep -q calico-node && break; sleep 5; done
kubectl $C wait --for=condition=Ready nodes --all --timeout=600s
kubectl $C -n kube-system rollout status deploy/coredns --timeout=300s
kubectl config use-context kind-cka
