Переключитесь на контекст `kind-cka-cni`.

Узлы этого кластера `NotReady`: CNI-плагин не установлен. Установите CNI с **поддержкой NetworkPolicy**. На выбор:
- Flannel: `https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml`
- Calico (оператор): `tigera-operator.yaml` и `custom-resources.yaml` из `https://raw.githubusercontent.com/projectcalico/calico/<версия>/manifests/` (версию печатает setup). Pod CIDR кластера — `192.168.0.0/16`.

Все узлы должны стать `Ready`, поды CoreDNS — работать. В конце вернитесь в контекст `kind-cka`.
