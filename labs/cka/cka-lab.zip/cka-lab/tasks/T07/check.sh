# сгенерировано src/build.py — правьте src/tasks/*.yaml
C="--context kind-cka-cni"
chk "все узлы kind-cka-cni в состоянии Ready" '[ -z "$(kubectl $C get nodes --no-headers | grep -v " Ready ")" ]'
chk "выбран CNI с NetworkPolicy (Calico: DaemonSet calico-node)" 'kubectl $C get ds -A --no-headers | grep -q calico-node'
chk "calico-node готов на всех узлах" 'kubectl $C get ds -A --no-headers | awk "/calico-node/{exit !(\$3==\$5 && \$3>0)}"'
chk "CoreDNS запущен" 'kubectl $C -n kube-system rollout status deploy/coredns --timeout=30s'
chk "текущий контекст снова kind-cka" '[ "$(kubectl config current-context)" = kind-cka ]'
