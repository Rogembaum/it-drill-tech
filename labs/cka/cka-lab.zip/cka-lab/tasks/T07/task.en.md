Use context `kind-cka-cni`: `kubectl config use-context kind-cka-cni`.

The nodes of this cluster are `NotReady` because no CNI plugin is installed. Install a CNI plugin that **supports NetworkPolicy enforcement**. You may choose one of:
- Flannel: `https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml`
- Calico (operator): `https://raw.githubusercontent.com/projectcalico/calico/<version>/manifests/tigera-operator.yaml` plus `custom-resources.yaml` from the same directory (the setup prints the current version). The Pod CIDR of the cluster is `192.168.0.0/16`.

All nodes must become `Ready` and the CoreDNS Pods must be running. Switch back to context `kind-cka` when you are done.
