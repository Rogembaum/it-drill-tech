# сгенерировано src/build.py — правьте src/tasks/*.yaml
kind delete cluster --name cka-cni >/dev/null 2>&1 || true
kubectl config use-context kind-cka >/dev/null 2>&1 || true
