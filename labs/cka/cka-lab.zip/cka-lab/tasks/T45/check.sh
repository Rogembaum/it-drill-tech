# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "error-pods.txt: api-1 и worker-1" 'grep -qx api-1 "$TD/error-pods.txt" && grep -qx worker-1 "$TD/error-pods.txt"'
chk "error-pods.txt: ничего лишнего" '[ "$(grep -cv "^$" "$TD/error-pods.txt")" = 2 ]'
chk "sidecar.log — логи контейнера sidecar" 'grep -q "sidecar heartbeat" "$TD/sidecar.log" && ! grep -q "worker up" "$TD/sidecar.log"'
chk "crash.log — логи предыдущего запуска (panic)" 'grep -q "panic: out of memory" "$TD/crash.log"'
