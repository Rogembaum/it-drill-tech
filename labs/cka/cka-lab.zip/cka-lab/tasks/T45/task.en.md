In namespace `logs`:
1. Write the names of all Pods whose **current** logs (of any container) contain the string `ERROR` to `~/cka/t45/error-pods.txt`, one per line.
2. Save the logs of the container `sidecar` of Pod `worker-1` to `~/cka/t45/sidecar.log`.
3. The Pod `old-crash` has restarted once. Save the logs of its **previous** container instance to `~/cka/t45/crash.log`.
