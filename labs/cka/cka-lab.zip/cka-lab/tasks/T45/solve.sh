# сгенерировано src/build.py — правьте src/tasks/*.yaml
for p in $(kubectl -n logs get pods -o name); do
  kubectl -n logs logs "$p" --all-containers 2>/dev/null | grep -q ERROR && echo "${p#pod/}"
done > "$TD/error-pods.txt"
kubectl -n logs logs worker-1 -c sidecar > "$TD/sidecar.log"
kubectl -n logs logs old-crash --previous > "$TD/crash.log"
