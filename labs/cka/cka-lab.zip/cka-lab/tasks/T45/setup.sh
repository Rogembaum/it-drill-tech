# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh logs
rm -rf "$TD"; mkdir -p "$TD"
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: v1
kind: Pod
metadata: {name: api-1, namespace: logs}
spec:
  containers:
  - name: api
    image: busybox:1.36
    command: ["sh", "-c", "echo 'INFO started'; echo 'ERROR db timeout after 30s'; sleep 36000"]
---
apiVersion: v1
kind: Pod
metadata: {name: api-2, namespace: logs}
spec:
  containers:
  - name: api
    image: busybox:1.36
    command: ["sh", "-c", "echo 'INFO started'; echo 'INFO healthy'; sleep 36000"]
---
apiVersion: v1
kind: Pod
metadata: {name: worker-1, namespace: logs}
spec:
  containers:
  - name: main
    image: busybox:1.36
    command: ["sh", "-c", "echo 'INFO worker up'; echo 'ERROR queue full'; sleep 36000"]
  - name: sidecar
    image: busybox:1.36
    command: ["sh", "-c", "while true; do echo \"$(date) sidecar heartbeat\"; sleep 5; done"]
---
apiVersion: v1
kind: Pod
metadata: {name: old-crash, namespace: logs}
spec:
  restartPolicy: Always
  containers:
  - name: app
    image: busybox:1.36
    command: ["sh", "-c", "if [ ! -f /state/crashed ]; then touch /state/crashed; echo 'panic: out of memory'; exit 1; fi; echo 'recovered after restart'; sleep 36000"]
    volumeMounts: [{name: state, mountPath: /state}]
  volumes:
  - {name: state, emptyDir: {}}
EOF
kubectl -n logs wait --for=condition=Ready pod/api-1 pod/api-2 pod/worker-1 --timeout=90s >/dev/null
for i in $(seq 40); do [ "$(jp -n logs pod old-crash '{.status.containerStatuses[0].restartCount}')" -ge 1 ] 2>/dev/null && break; sleep 2; done
