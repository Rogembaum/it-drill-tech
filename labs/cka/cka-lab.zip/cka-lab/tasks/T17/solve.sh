# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n wp scale deploy wordpress --replicas=0
R='{"requests":{"cpu":"100m","memory":"128Mi"},"limits":{"cpu":"200m","memory":"256Mi"}}'
kubectl -n wp patch deploy wordpress --type=json -p "[{\"op\":\"add\",\"path\":\"/spec/template/spec/initContainers/0/resources\",\"value\":$R},{\"op\":\"add\",\"path\":\"/spec/template/spec/containers/0/resources\",\"value\":$R}]"
kubectl -n wp scale deploy wordpress --replicas=3
kubectl -n wp rollout status deploy/wordpress --timeout=120s
