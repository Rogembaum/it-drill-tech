# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh wp
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: wordpress
  namespace: wp
spec:
  replicas: 3
  selector:
    matchLabels: {app: wordpress}
  template:
    metadata:
      labels: {app: wordpress}
    spec:
      initContainers:
      - name: init-db
        image: busybox:1.36
        command: ["sh", "-c", "echo waiting for db; sleep 2"]
      containers:
      - name: wordpress
        image: nginx:1.27-alpine
EOF
