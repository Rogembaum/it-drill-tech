# сгенерировано src/build.py — правьте src/tasks/*.yaml
r() { jp -n wp deploy wordpress "$1"; }
chk "init-контейнер: requests 100m/128Mi" '[ "$(r "{.spec.template.spec.initContainers[0].resources.requests.cpu}/{.spec.template.spec.initContainers[0].resources.requests.memory}")" = 100m/128Mi ]'
chk "init-контейнер: limits 200m/256Mi" '[ "$(r "{.spec.template.spec.initContainers[0].resources.limits.cpu}/{.spec.template.spec.initContainers[0].resources.limits.memory}")" = 200m/256Mi ]'
chk "основной контейнер: requests 100m/128Mi" '[ "$(r "{.spec.template.spec.containers[0].resources.requests.cpu}/{.spec.template.spec.containers[0].resources.requests.memory}")" = 100m/128Mi ]'
chk "основной контейнер: limits 200m/256Mi" '[ "$(r "{.spec.template.spec.containers[0].resources.limits.cpu}/{.spec.template.spec.containers[0].resources.limits.memory}")" = 200m/256Mi ]'
chk "3 реплики готовы с новыми ресурсами" '[ -n "$(r "{.spec.template.spec.containers[0].resources.requests.cpu}")" ] && rollout_wait wp deploy/wordpress 90s && [ "$(r "{.status.readyReplicas}")" = 3 ] && [ "$(r "{.status.updatedReplicas}")" = 3 ]'
