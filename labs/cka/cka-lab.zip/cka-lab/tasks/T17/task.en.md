The Deployment `wordpress` in namespace `wp` runs 3 replicas.

1. Scale it down to `0` replicas.
2. Set the following resources for **both** the init container and the main container: requests `cpu: 100m`, `memory: 128Mi`; limits `cpu: 200m`, `memory: 256Mi`.
3. Scale it back to `3` replicas and make sure all Pods are running.
