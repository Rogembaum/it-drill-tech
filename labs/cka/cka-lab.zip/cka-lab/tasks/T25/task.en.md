In namespace `team-a`:
1. Create a ResourceQuota `team-quota` that allows at most `5` Pods, total `requests.cpu` of `1` and total `limits.memory` of `2Gi`.
2. Create a LimitRange `defaults` so that containers created without resources get requests `cpu: 100m`, `memory: 64Mi` and limits `cpu: 200m`, `memory: 128Mi`.
3. Create a Pod `web` (image `nginx:1.27-alpine`) **without** specifying any resources and make sure it is running with the default values.
