# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n team-a create quota team-quota --hard=pods=5,requests.cpu=1,limits.memory=2Gi
cat <<'EOF' | kubectl apply -f -
apiVersion: v1
kind: LimitRange
metadata:
  name: defaults
  namespace: team-a
spec:
  limits:
  - type: Container
    defaultRequest: {cpu: 100m, memory: 64Mi}
    default: {cpu: 200m, memory: 128Mi}
EOF
kubectl -n team-a run web --image=nginx:1.27-alpine
kubectl -n team-a wait --for=condition=Ready pod/web --timeout=60s
