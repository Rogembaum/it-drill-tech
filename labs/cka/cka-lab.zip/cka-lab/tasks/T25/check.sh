# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "квота: pods=5, requests.cpu=1, limits.memory=2Gi" '[ "$(jp -n team-a resourcequota team-quota "{.spec.hard.pods}/{.spec.hard.requests\.cpu}/{.spec.hard.limits\.memory}")" = 5/1/2Gi ]'
chk "LimitRange: defaultRequest 100m/64Mi" '[ "$(jp -n team-a limitrange defaults "{.spec.limits[?(@.type==\"Container\")].defaultRequest.cpu}/{.spec.limits[?(@.type==\"Container\")].defaultRequest.memory}")" = 100m/64Mi ]'
chk "LimitRange: default (limits) 200m/128Mi" '[ "$(jp -n team-a limitrange defaults "{.spec.limits[?(@.type==\"Container\")].default.cpu}/{.spec.limits[?(@.type==\"Container\")].default.memory}")" = 200m/128Mi ]'
chk "под web работает" 'kubectl -n team-a wait --for=condition=Ready pod/web --timeout=60s'
chk "под web получил requests 100m и limits 128Mi" '[ "$(jp -n team-a pod web "{.spec.containers[0].resources.requests.cpu}/{.spec.containers[0].resources.limits.memory}")" = 100m/128Mi ]'
