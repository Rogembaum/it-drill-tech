В `team-a`:
1. Создайте ResourceQuota `team-quota`: не более `5` подов, суммарно `requests.cpu` = `1`, `limits.memory` = `2Gi`.
2. Создайте LimitRange `defaults`: контейнеры без ресурсов получают requests `cpu: 100m`, `memory: 64Mi` и limits `cpu: 200m`, `memory: 128Mi`.
3. Создайте Pod `web` (образ `nginx:1.27-alpine`) **без** ресурсов и убедитесь, что он работает со значениями по умолчанию.
