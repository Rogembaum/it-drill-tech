Pods of the Deployment `consumer` in namespace `queue` are in `CrashLoopBackOff`.

Find out the reason from the container logs and fix the problem **without changing the Deployment's Pod template** (restarting the rollout is allowed). The configuration file the application expects must contain the line `queue=orders`.
