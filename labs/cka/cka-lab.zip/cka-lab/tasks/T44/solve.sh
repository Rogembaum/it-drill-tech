# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n queue create configmap consumer-config --from-literal=queue.conf=queue=orders
kubectl -n queue rollout restart deploy/consumer
kubectl -n queue rollout status deploy/consumer --timeout=120s
