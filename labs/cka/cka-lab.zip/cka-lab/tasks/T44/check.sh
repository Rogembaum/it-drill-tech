# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "ConfigMap consumer-config: queue.conf содержит queue=orders" 'jp -n queue cm consumer-config "{.data.queue\.conf}" | grep -qx "queue=orders"'
chk "шаблон пода не изменён (та же команда и том)" 'kubectl -n queue get cm consumer-config && jp -n queue deploy consumer "{.spec.template.spec.containers[0].command}" | grep -q queue.conf && [ "$(jp -n queue deploy consumer "{.spec.template.spec.volumes[0].configMap.name}")" = consumer-config ]'
ok_pod() { local i p; for i in $(seq 40); do
  p=$(kubectl -n queue get pods -l app=consumer -o jsonpath='{range .items[*]}{.metadata.name} {.status.containerStatuses[0].ready}{"\n"}{end}' | awk '$2=="true"{print $1}' | head -1)
  [ -n "$p" ] && kubectl -n queue logs "$p" 2>/dev/null | grep -q "started with queue=orders" && return 0; sleep 3; done; return 1; }
chk "под Ready и приложение стартовало с queue=orders" ok_pod
