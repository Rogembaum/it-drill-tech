# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh queue
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: consumer
  namespace: queue
spec:
  replicas: 1
  selector:
    matchLabels: {app: consumer}
  template:
    metadata:
      labels: {app: consumer}
    spec:
      containers:
      - name: consumer
        image: busybox:1.36
        command: ["sh", "-c", "if [ ! -f /etc/consumer/queue.conf ]; then echo 'FATAL: /etc/consumer/queue.conf not found (expected from ConfigMap consumer-config)'; exit 1; fi; echo started with $(cat /etc/consumer/queue.conf); sleep 3600"]
        volumeMounts:
        - {name: cfg, mountPath: /etc/consumer}
      volumes:
      - name: cfg
        configMap:
          name: consumer-config
          optional: true
EOF
