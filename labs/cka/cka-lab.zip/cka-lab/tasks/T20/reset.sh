# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl delete priorityclass low-priority medium-priority batch-critical high-priority --ignore-not-found >/dev/null
ns_drop priority
