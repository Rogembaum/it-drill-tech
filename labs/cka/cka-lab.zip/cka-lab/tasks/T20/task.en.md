Create a PriorityClass `high-priority` for user workloads with a value that is **exactly one less** than the highest existing **user-defined** PriorityClass.

Patch the Deployment `busybox-logger` in namespace `priority` to use this PriorityClass and make sure its Pods are running.
