# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "PriorityClass high-priority = 99999" '[ "$(jp priorityclass high-priority "{.value}")" = 99999 ]'
chk "high-priority не globalDefault" 'kubectl get priorityclass high-priority && [ "$(jp priorityclass high-priority "{.globalDefault}")" != true ]'
chk "Deployment использует high-priority" '[ "$(jp -n priority deploy busybox-logger "{.spec.template.spec.priorityClassName}")" = high-priority ]'
chk "поды работают с priority 99999" 'rollout_wait priority deploy/busybox-logger 90s && [ "$(kubectl -n priority get pods -l app=busybox-logger --field-selector=status.phase=Running -o jsonpath="{.items[0].spec.priority}")" = 99999 ]'
