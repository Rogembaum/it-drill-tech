# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl create priorityclass high-priority --value=99999 --description="user workloads"
kubectl -n priority patch deploy busybox-logger -p '{"spec":{"template":{"spec":{"priorityClassName":"high-priority"}}}}'
kubectl -n priority rollout status deploy/busybox-logger --timeout=90s
