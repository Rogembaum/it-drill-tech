# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh priority
kubectl delete priorityclass low-priority medium-priority batch-critical high-priority --ignore-not-found >/dev/null
kubectl create priorityclass low-priority --value=1000 >/dev/null
kubectl create priorityclass medium-priority --value=50000 >/dev/null
kubectl create priorityclass batch-critical --value=100000 --description="highest user-defined class" >/dev/null
kubectl -n priority create deployment busybox-logger --image=busybox:1.36 -- sh -c 'while true; do echo logging; sleep 10; done' >/dev/null
