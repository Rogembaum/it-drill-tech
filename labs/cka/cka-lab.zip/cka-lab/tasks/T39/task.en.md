In namespace `pv-lab`:
1. Create a PVC `data-pvc` (`200Mi`, `ReadWriteOnce`) that uses the cluster's default StorageClass.
2. Create a Pod `writer` (image `busybox:1.36`) that mounts the PVC at `/data` and runs `sh -c "echo cka-ok > /data/check.txt && sleep 3600"`.
3. Write the reclaim policy of the PersistentVolume that was provisioned for `data-pvc` to `~/cka/t39/reclaim.txt`.
