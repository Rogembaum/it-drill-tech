В `pv-lab`:
1. Создайте PVC `data-pvc` (`200Mi`, `ReadWriteOnce`) с классом по умолчанию.
2. Создайте Pod `writer` (образ `busybox:1.36`), который монтирует PVC в `/data` и выполняет `sh -c "echo cka-ok > /data/check.txt && sleep 3600"`.
3. Запишите reclaim policy созданного для `data-pvc` PersistentVolume в `~/cka/t39/reclaim.txt`.
