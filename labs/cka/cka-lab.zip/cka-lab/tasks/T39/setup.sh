# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh pv-lab
mkdir -p "$TD"; rm -f "$TD/reclaim.txt"
