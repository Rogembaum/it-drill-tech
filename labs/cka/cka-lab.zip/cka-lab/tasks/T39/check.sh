# сгенерировано src/build.py — правьте src/tasks/*.yaml
pv=$(jp -n pv-lab pvc data-pvc '{.spec.volumeName}')
chk "PVC data-pvc Bound" '[ "$(jp -n pv-lab pvc data-pvc "{.status.phase}")" = Bound ]'
chk "под writer работает" 'kubectl -n pv-lab wait --for=condition=Ready pod/writer --timeout=60s'
chk "в томе /data/check.txt = cka-ok" '[ "$(kubectl -n pv-lab exec writer -- cat /data/check.txt)" = cka-ok ]'
chk "reclaim.txt совпадает с reclaimPolicy созданного PV" '[ -n "$pv" ] && [ "$(tr -d " \n" < "$TD/reclaim.txt")" = "$(jp pv "$pv" "{.spec.persistentVolumeReclaimPolicy}")" ]'
