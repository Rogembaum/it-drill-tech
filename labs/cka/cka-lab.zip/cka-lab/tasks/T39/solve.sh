# сгенерировано src/build.py — правьте src/tasks/*.yaml
cat <<'EOF' | kubectl apply -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: data-pvc
  namespace: pv-lab
spec:
  accessModes: [ReadWriteOnce]
  resources:
    requests:
      storage: 200Mi
---
apiVersion: v1
kind: Pod
metadata:
  name: writer
  namespace: pv-lab
spec:
  containers:
  - name: writer
    image: busybox:1.36
    command: ["sh", "-c", "echo cka-ok > /data/check.txt && sleep 3600"]
    volumeMounts:
    - {name: data, mountPath: /data}
  volumes:
  - name: data
    persistentVolumeClaim: {claimName: data-pvc}
EOF
kubectl -n pv-lab wait --for=condition=Ready pod/writer --timeout=90s
kubectl get pv "$(kubectl -n pv-lab get pvc data-pvc -o jsonpath='{.spec.volumeName}')" -o jsonpath='{.spec.persistentVolumeReclaimPolicy}' > "$TD/reclaim.txt"
