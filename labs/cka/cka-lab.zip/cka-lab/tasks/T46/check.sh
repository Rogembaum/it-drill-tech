# сгенерировано src/build.py — правьте src/tasks/*.yaml
topn=$(kubectl top nodes --no-headers --sort-by=memory 2>/dev/null | awk 'NR==1{print $1}')
chk "top-pod.txt = burner-b" '[ "$(tr -d " \n" < "$TD/top-pod.txt")" = burner-b ]'
chk "top-node.txt = узел с наибольшим потреблением памяти" '[ -n "$topn" ] && [ "$(tr -d " \n" < "$TD/top-node.txt")" = "$topn" ]'
