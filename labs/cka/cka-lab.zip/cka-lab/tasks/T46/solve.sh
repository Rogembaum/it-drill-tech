# сгенерировано src/build.py — правьте src/tasks/*.yaml
for i in $(seq 36); do kubectl -n load top pods -l app=burner --no-headers 2>/dev/null | grep -q burner-b && break; sleep 5; done
kubectl -n load top pods -l app=burner --sort-by=cpu --no-headers | awk 'NR==1{print $1}' > "$TD/top-pod.txt"
kubectl top nodes --sort-by=memory --no-headers | awk 'NR==1{print $1}' > "$TD/top-node.txt"
