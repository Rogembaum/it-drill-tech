1. Find the Pod with label `app=burner` in namespace `load` that consumes the most CPU and write its name to `~/cka/t46/top-pod.txt`.
2. Find the node with the highest memory usage and write its name to `~/cka/t46/top-node.txt`.

Use the metrics available in the cluster.
