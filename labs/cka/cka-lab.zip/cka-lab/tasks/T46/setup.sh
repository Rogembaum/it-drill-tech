# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh load
mkdir -p "$TD"; rm -f "$TD"/top-*.txt
for p in burner-a burner-b burner-c; do
  if [ $p = burner-b ]; then c='while true; do :; done'; else c='sleep 36000'; fi
  cat <<EOF | kubectl apply -f - >/dev/null
apiVersion: v1
kind: Pod
metadata: {name: $p, namespace: load, labels: {app: burner}}
spec:
  terminationGracePeriodSeconds: 0
  containers:
  - name: burner
    image: busybox:1.36
    command: ["sh", "-c", "$c"]
    resources:
      requests: {cpu: 50m, memory: 16Mi}
      limits: {cpu: 300m, memory: 32Mi}
EOF
done
kubectl -n load wait --for=condition=Ready pod -l app=burner --timeout=90s >/dev/null
echo "  metrics-server собирает данные ~1 минуту, прежде чем kubectl top что-то покажет"
