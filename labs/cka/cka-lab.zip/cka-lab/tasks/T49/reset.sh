# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $W2 '[ -f /root/.cka-kubelet-config.yaml.orig ] && cp /root/.cka-kubelet-config.yaml.orig /var/lib/kubelet/config.yaml && rm -f /root/.cka-kubelet-config.yaml.orig
systemctl enable kubelet >/dev/null 2>&1; systemctl restart kubelet' || true
