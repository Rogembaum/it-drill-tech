# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $W2 'sed -i "s#clientCAFile: /etc/kubernetes/pki/ca.cert#clientCAFile: /etc/kubernetes/pki/ca.crt#" /var/lib/kubelet/config.yaml
systemctl enable kubelet >/dev/null 2>&1; systemctl restart kubelet'
kubectl wait --for=condition=Ready node/$W2 --timeout=120s
