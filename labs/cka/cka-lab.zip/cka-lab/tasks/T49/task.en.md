The node `cka-worker2` is `NotReady`.

Find the cause and fix it. The fix must survive a reboot of the node.
