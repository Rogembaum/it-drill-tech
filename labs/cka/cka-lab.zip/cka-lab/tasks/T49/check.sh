# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "clientCAFile указывает на существующий /etc/kubernetes/pki/ca.crt" 'node $W2 "grep -q \"clientCAFile: /etc/kubernetes/pki/ca.crt\$\" /var/lib/kubelet/config.yaml"'
chk "kubelet запущен" 'node $W2 "systemctl is-active kubelet"'
chk "kubelet включён в автозагрузку" 'node $W2 "systemctl is-enabled kubelet"'
chk "узел $W2 Ready" 'kubectl wait --for=condition=Ready node/$W2 --timeout=60s'
