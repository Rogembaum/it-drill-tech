# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $W2 'cp -n /var/lib/kubelet/config.yaml /root/.cka-kubelet-config.yaml.orig
sed -i "s#clientCAFile: /etc/kubernetes/pki/ca.crt#clientCAFile: /etc/kubernetes/pki/ca.cert#" /var/lib/kubelet/config.yaml
systemctl disable kubelet >/dev/null 2>&1; systemctl stop kubelet'
echo "  ждём, пока узел станет NotReady (~40 с)…"
sleep 45
