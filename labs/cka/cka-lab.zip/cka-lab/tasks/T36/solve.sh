# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n kube-system get cm coredns -o yaml > "$TD/coredns-orig.yaml"
kubectl -n kube-system get cm coredns -o jsonpath='{.data.Corefile}' > /tmp/Corefile.$$
awk '!d && /^\.:53 *\{/ {print; print "    rewrite name db.cka.internal db.data.svc.cluster.local"; d=1; next} {print}' /tmp/Corefile.$$ > /tmp/Corefile.new.$$
kubectl -n kube-system create cm coredns --from-file=Corefile=/tmp/Corefile.new.$$ --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null
rm -f /tmp/Corefile.$$ /tmp/Corefile.new.$$
kubectl -n kube-system rollout restart deploy/coredns
kubectl -n kube-system rollout status deploy/coredns --timeout=90s
