# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh data
mkdir -p "$TD" "$LAB/.state"; rm -f "$TD/coredns-orig.yaml"
[ -f "$LAB/.state/Corefile" ] || kubectl -n kube-system get cm coredns -o jsonpath='{.data.Corefile}' > "$LAB/.state/Corefile"
kubectl -n data create deployment db --image=nginx:1.27-alpine --port=80 >/dev/null
kubectl -n data expose deployment db --port=80 >/dev/null
