Приложения должны обращаться к Service `db` из `data` по имени `db.cka.internal`.

1. Сохраните текущий ConfigMap CoreDNS (`coredns` в `kube-system`) в `~/cka/t36/coredns-orig.yaml`.
2. Настройте CoreDNS так, чтобы запросы `db.cka.internal` переписывались в `db.data.svc.cluster.local`.
3. Убедитесь, что изменение применилось и имя разрешается из пода.
