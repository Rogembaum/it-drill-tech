# сгенерировано src/build.py — правьте src/tasks/*.yaml
if [ -s "$LAB/.state/Corefile" ]; then
  kubectl -n kube-system create cm coredns --from-file=Corefile="$LAB/.state/Corefile" --dry-run=client -o yaml | kubectl apply -f - >/dev/null 2>&1
  rm -f "$LAB/.state/Corefile"
  kubectl -n kube-system rollout restart deploy/coredns >/dev/null
fi
ns_drop data
