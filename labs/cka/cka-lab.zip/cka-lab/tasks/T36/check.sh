# сгенерировано src/build.py — правьте src/tasks/*.yaml
sip=$(jp -n data svc db '{.spec.clusterIP}')
chk "резервная копия — ConfigMap coredns с Corefile" 'grep -q "Corefile" "$TD/coredns-orig.yaml" && grep -q "name: coredns" "$TD/coredns-orig.yaml"'
chk "в копии нет правила rewrite (это оригинал)" '[ -s "$TD/coredns-orig.yaml" ] && ! grep -q "db.cka.internal" "$TD/coredns-orig.yaml"'
chk "в Corefile есть rewrite для db.cka.internal" 'jp -n kube-system cm coredns "{.data.Corefile}" | grep -Eq "rewrite.*db\.cka\.internal\.?.*db\.data\.svc\.cluster\.local"'
chk "CoreDNS работает с новой конфигурацией" 'jp -n kube-system cm coredns "{.data.Corefile}" | grep -q db.cka.internal && rollout_wait kube-system deploy/coredns 90s'
chk "db.cka.internal разрешается в ClusterIP сервиса data/db" 'for i in $(seq 12); do probe default "" "nslookup db.cka.internal" | grep -q "$sip" && exit 0; sleep 5; done; exit 1'
probes_clean
