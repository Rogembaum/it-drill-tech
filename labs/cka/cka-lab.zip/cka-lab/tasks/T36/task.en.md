Applications must be able to reach the Service `db` in namespace `data` using the name `db.cka.internal`.

1. Back up the current CoreDNS ConfigMap (`coredns` in `kube-system`) to `~/cka/t36/coredns-orig.yaml`.
2. Configure CoreDNS to rewrite queries for `db.cka.internal` to `db.data.svc.cluster.local`.
3. Make sure the change is active and resolution works from a Pod.
