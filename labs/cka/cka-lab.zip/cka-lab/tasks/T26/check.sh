# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "метка enforce=baseline" '[ "$(jp ns secure "{.metadata.labels.pod-security\.kubernetes\.io/enforce}")" = baseline ]'
chk "метка warn=restricted" '[ "$(jp ns secure "{.metadata.labels.pod-security\.kubernetes\.io/warn}")" = restricted ]'
chk "под app работает" 'kubectl -n secure wait --for=condition=Ready pod/app --timeout=60s'
chk "hostPID и privileged убраны" 'kubectl -n secure get pod app && [ "$(jp -n secure pod app "{.spec.hostPID}")" != true ] && [ "$(jp -n secure pod app "{.spec.containers[0].securityContext.privileged}")" != true ]'
chk "в манифесте app.yaml тоже исправлено" '! grep -Eq "hostPID: *true|privileged: *true" "$TD/app.yaml"'
