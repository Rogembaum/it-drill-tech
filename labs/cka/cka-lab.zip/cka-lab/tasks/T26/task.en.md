1. Configure namespace `secure` so that Pod Security Admission **enforces** the `baseline` level and **warns** about violations of the `restricted` level.
2. The manifest `~/cka/t26/app.yaml` describes a Pod `app` that is rejected in this namespace. Fix the manifest by removing only what violates the `baseline` level, and create the Pod.
