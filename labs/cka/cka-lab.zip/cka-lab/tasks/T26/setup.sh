# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh secure
mkdir -p "$TD"
cat > "$TD/app.yaml" <<'EOF'
apiVersion: v1
kind: Pod
metadata:
  name: app
  namespace: secure
spec:
  hostPID: true
  containers:
  - name: app
    image: busybox:1.36
    command: ["sleep", "3600"]
    securityContext:
      privileged: true
    resources:
      requests: {cpu: 10m, memory: 16Mi}
EOF
