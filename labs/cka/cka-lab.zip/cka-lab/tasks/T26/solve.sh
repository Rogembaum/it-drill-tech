# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl label ns secure pod-security.kubernetes.io/enforce=baseline pod-security.kubernetes.io/warn=restricted --overwrite
sed -i.bak -e '/hostPID: true/d' -e '/securityContext:/d' -e '/privileged: true/d' "$TD/app.yaml"
kubectl apply -f "$TD/app.yaml"
kubectl -n secure wait --for=condition=Ready pod/app --timeout=60s
