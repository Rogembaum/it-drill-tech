# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh ops
mkdir -p "$TD"; rm -f "$TD"/crds.txt "$TD"/retention.txt
crd() { cat <<EOF
apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  name: $1.$2
spec:
  group: $2
  scope: Namespaced
  names: {plural: $1, singular: $3, kind: $4}
  versions:
  - name: v1
    served: true
    storage: true
    schema:
      openAPIV3Schema:
        type: object
        properties:
          spec:
            type: object
            required: [schedule]
            properties:
              schedule:
                type: string
                description: Cron expression for the backup schedule.
              retentionDays:
                type: integer
                minimum: 1
                maximum: 30
                description: How many days backups are kept before they are deleted.
              target:
                type: string
                enum: [etcd, volumes, all]
                description: What to back up.
---
EOF
}
{ crd backups ops.cka.io backup Backup; crd restores ops.cka.io restore Restore; crd snapshots storage.cka.io snapshot Snapshot; } | kubectl apply -f - >/dev/null
kubectl wait --for=condition=Established crd/backups.ops.cka.io --timeout=60s >/dev/null
