# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl get crd -o custom-columns=NAME:.metadata.name --no-headers | grep '\.ops\.cka\.io$' > "$TD/crds.txt"
kubectl explain backup.spec.retentionDays > "$TD/retention.txt"
cat <<'EOF' | kubectl apply -f -
apiVersion: ops.cka.io/v1
kind: Backup
metadata:
  name: nightly
  namespace: ops
spec:
  schedule: "0 2 * * *"
  retentionDays: 7
  target: etcd
EOF
