В кластере установлено несколько операторов.

1. Запишите имена всех CRD группы `ops.cka.io` в `~/cka/t06/crds.txt` (только имена, по одному на строку).
2. С помощью `kubectl` получите документацию поля `spec.retentionDays` ресурса `Backup` и сохраните в `~/cka/t06/retention.txt`.
3. Создайте `Backup` с именем `nightly` в `ops`: расписание `0 2 * * *`, `retentionDays` = `7`, target `etcd`.
