Several operators are installed in the cluster.

1. Write the names of all CRDs that belong to the API group `ops.cka.io` to `~/cka/t06/crds.txt` (one per line, names only).
2. Using `kubectl`, extract the documentation of the field `spec.retentionDays` of the resource `Backup` and save it to `~/cka/t06/retention.txt`.
3. Create a `Backup` named `nightly` in namespace `ops` with schedule `0 2 * * *`, `retentionDays` set to `7` and target `etcd`.
