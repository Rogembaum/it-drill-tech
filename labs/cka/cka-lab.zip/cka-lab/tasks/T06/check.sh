# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "crds.txt: backups.ops.cka.io и restores.ops.cka.io" 'grep -qx "backups.ops.cka.io" "$TD/crds.txt" && grep -qx "restores.ops.cka.io" "$TD/crds.txt"'
chk "crds.txt: нет CRD других групп" '[ -s "$TD/crds.txt" ] && ! grep -q -v "\.ops\.cka\.io$" "$TD/crds.txt"'
chk "retention.txt — вывод kubectl explain по retentionDays" 'grep -q retentionDays "$TD/retention.txt" && grep -qi integer "$TD/retention.txt"'
chk "Backup ops/nightly существует" 'kubectl -n ops get backup nightly'
chk "schedule = 0 2 * * *" '[ "$(jp -n ops backup nightly "{.spec.schedule}")" = "0 2 * * *" ]'
chk "retentionDays = 7, target = etcd" '[ "$(jp -n ops backup nightly "{.spec.retentionDays}/{.spec.target}")" = 7/etcd ]'
