# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_drop backend frontend other
