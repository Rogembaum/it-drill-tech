# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh backend frontend other
kubectl label ns frontend team=frontend >/dev/null
kubectl label ns other team=other >/dev/null
kubectl -n backend create deployment api --image=nginx:1.27-alpine --port=80 >/dev/null
kubectl -n backend expose deployment api --port=80 >/dev/null
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-ingress
  namespace: backend
spec:
  podSelector: {}
  policyTypes: [Ingress]
EOF
rollout_wait backend deploy/api
