# сгенерировано src/build.py — правьте src/tasks/*.yaml
U=http://api.backend.svc.cluster.local
chk "политика allow-web-to-api существует" 'kubectl -n backend get netpol allow-web-to-api'
chk "default-deny-ingress на месте" 'kubectl -n backend get netpol allow-web-to-api && kubectl -n backend get netpol default-deny-ingress'
chk "frontend, role=web → api: доступ есть" 'http_ok frontend "role=web" $U'
chk "frontend, role=admin → api: заблокировано" 'kubectl -n backend get netpol allow-web-to-api && ! http_ok frontend "role=admin" $U'
chk "other, role=web → api: заблокировано" 'kubectl -n backend get netpol allow-web-to-api && ! http_ok other "role=web" $U'
chk "в политике только порт 80/TCP" '[ "$(jp -n backend netpol allow-web-to-api "{.spec.ingress[*].ports[*].port}")" = 80 ]'
probes_clean
