Namespace `backend` has a default-deny ingress policy.

Create a NetworkPolicy `allow-web-to-api` in namespace `backend` that allows ingress to Pods with label `app=api` **only** from Pods that have the label `role=web` **and** run in a namespace labeled `team=frontend`, and only on TCP port `80`.

Do not modify or delete existing policies.
