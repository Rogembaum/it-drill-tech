# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "overlays/prod/kustomization.yaml существует и рендерится" 'kubectl kustomize "$TD/overlays/prod"'
chk "overlay ссылается на base, а не копирует его" 'grep -q "\.\./\.\./base" "$TD/overlays/prod/kustomization.yaml"'
chk "Deployment prod/prod-web: 3 готовые реплики" 'rollout_wait prod deploy/prod-web 90s && [ "$(jp -n prod deploy prod-web "{.status.readyReplicas}")" = 3 ]'
chk "образ nginx:1.28-alpine" '[ "$(jp -n prod deploy prod-web "{.spec.template.spec.containers[0].image}")" = nginx:1.28-alpine ]'
chk "у Deployment метка env=prod" '[ "$(jp -n prod deploy prod-web "{.metadata.labels.env}")" = prod ]'
chk "Service prod/prod-web с меткой env=prod" '[ "$(jp -n prod svc prod-web "{.metadata.labels.env}")" = prod ]'
