# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh prod
rm -rf "$TD"; mkdir -p "$TD/base"
cat > "$TD/base/deployment.yaml" <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web
  labels: {app: web}
spec:
  replicas: 1
  selector:
    matchLabels: {app: web}
  template:
    metadata:
      labels: {app: web}
    spec:
      containers:
      - name: web
        image: nginx:1.27-alpine
        ports:
        - containerPort: 80
EOF
cat > "$TD/base/service.yaml" <<'EOF'
apiVersion: v1
kind: Service
metadata:
  name: web
  labels: {app: web}
spec:
  selector: {app: web}
  ports:
  - port: 80
    targetPort: 80
EOF
cat > "$TD/base/kustomization.yaml" <<'EOF'
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
- deployment.yaml
- service.yaml
EOF
