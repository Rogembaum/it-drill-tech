# сгенерировано src/build.py — правьте src/tasks/*.yaml
mkdir -p "$TD/overlays/prod"
cat > "$TD/overlays/prod/kustomization.yaml" <<'EOF'
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
- ../../base
namespace: prod
namePrefix: prod-
labels:
- pairs:
    env: prod
replicas:
- name: web
  count: 3
images:
- name: nginx
  newTag: 1.28-alpine
EOF
kubectl apply -k "$TD/overlays/prod"
