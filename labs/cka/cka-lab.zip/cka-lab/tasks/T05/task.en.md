A Kustomize base for the application `web` is located in `~/cka/t05/base`.

Create an overlay in `~/cka/t05/overlays/prod` that:
- deploys all resources into namespace `prod` (it already exists),
- adds the name prefix `prod-`,
- adds the label `env: prod` to all resources,
- sets the replicas of Deployment `web` to `3`,
- changes the tag of image `nginx` to `1.28-alpine`.

Apply the overlay to the cluster using kubectl.
