Deployment `legacy-app` в `logging` пишет лог только в файл `/var/log/app/app.log`, поэтому `kubectl logs` ничего не показывает.

Добавьте sidecar-контейнер `log-shipper` (образ `busybox:1.36`) с командой `tail -n+1 -F /var/log/app/app.log`. Общий каталог логов — том `logs`, смонтированный в `/var/log/app` в обоих контейнерах.

Команду существующего контейнера не меняйте. После правки `kubectl logs deploy/legacy-app -c log-shipper` должен показывать лог приложения.
