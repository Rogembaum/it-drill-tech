# сгенерировано src/build.py — правьте src/tasks/*.yaml
s() { jp -n logging deploy legacy-app "$1"; }
chk "контейнер log-shipper добавлен (обычный или нативный sidecar)" 's "{.spec.template.spec.containers[*].name} {.spec.template.spec.initContainers[*].name}" | grep -qw log-shipper'
chk "команда log-shipper — tail -F /var/log/app/app.log" 's "{.spec.template.spec.containers[?(@.name==\"log-shipper\")].command} {.spec.template.spec.containers[?(@.name==\"log-shipper\")].args} {.spec.template.spec.initContainers[?(@.name==\"log-shipper\")].command} {.spec.template.spec.initContainers[?(@.name==\"log-shipper\")].args}" | grep -q "/var/log/app/app.log"'
chk "том logs смонтирован в /var/log/app у обоих контейнеров" '[ "$(s "{.spec.template.spec..volumeMounts[?(@.name==\"logs\")].mountPath}" | tr " " "\n" | grep -cx /var/log/app)" -ge 2 ]'
chk "команда контейнера app не изменилась" 's "{.spec.template.spec.containers[*].name} {.spec.template.spec.initContainers[*].name}" | grep -qw log-shipper && s "{.spec.template.spec.containers[?(@.name==\"app\")].command}" | grep -q "request"'
one_pod() { local i; for i in $(seq 40); do [ "$(kubectl -n logging get pods -l app=legacy-app --no-headers 2>/dev/null | wc -l | tr -d " ")" = 1 ] && return 0; sleep 2; done; return 1; }
chk "kubectl logs -c log-shipper показывает лог приложения" 'rollout_wait logging deploy/legacy-app 90s && one_pod && sleep 3 && kubectl -n logging logs deploy/legacy-app -c log-shipper --tail=20 | grep -q "INFO request"'
