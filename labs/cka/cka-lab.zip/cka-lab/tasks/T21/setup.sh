# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh logging
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: legacy-app
  namespace: logging
spec:
  replicas: 1
  selector:
    matchLabels: {app: legacy-app}
  template:
    metadata:
      labels: {app: legacy-app}
    spec:
      terminationGracePeriodSeconds: 3
      containers:
      - name: app
        image: busybox:1.36
        command: ["sh", "-c", "mkdir -p /var/log/app; i=0; while true; do i=$((i+1)); echo \"$(date) INFO request $i ok\" >> /var/log/app/app.log; sleep 2; done"]
EOF
