# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n logging patch deploy legacy-app --type=strategic -p '
spec:
  template:
    spec:
      volumes:
      - name: logs
        emptyDir: {}
      initContainers:
      - name: log-shipper
        image: busybox:1.36
        restartPolicy: Always
        command: ["sh", "-c", "tail -n+1 -F /var/log/app/app.log"]
        volumeMounts:
        - {name: logs, mountPath: /var/log/app}
      containers:
      - name: app
        volumeMounts:
        - {name: logs, mountPath: /var/log/app}
'
kubectl -n logging rollout status deploy/legacy-app --timeout=90s
