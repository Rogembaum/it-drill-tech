The Deployment `legacy-app` in namespace `logging` writes its log only to the file `/var/log/app/app.log` inside the container, so `kubectl logs` shows nothing.

Add a sidecar container named `log-shipper` (image `busybox:1.36`) that runs `tail -n+1 -F /var/log/app/app.log`. Share the log directory between both containers using a volume named `logs` mounted at `/var/log/app`.

Do not change the command of the existing container. Afterwards `kubectl logs deploy/legacy-app -c log-shipper` must show the application log.
