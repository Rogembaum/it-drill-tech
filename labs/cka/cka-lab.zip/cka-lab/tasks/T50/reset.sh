# сгенерировано src/build.py — правьте src/tasks/*.yaml
manifest_restore kube-controller-manager
ns_drop cm-lab
