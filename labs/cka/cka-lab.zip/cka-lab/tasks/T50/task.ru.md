Deployment `cm-test` в `cm-lab` создан, но подов нет — нет даже ReplicaSet.

Найдите и исправьте неисправный компонент control plane на `cka-control-plane`.
