# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $CP "sed -i 's#- kube-controller-manger\$#- kube-controller-manager#' /etc/kubernetes/manifests/kube-controller-manager.yaml"
sleep 20
kubectl -n cm-lab rollout status deploy/cm-test --timeout=120s
