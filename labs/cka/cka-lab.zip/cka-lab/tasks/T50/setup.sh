# сгенерировано src/build.py — правьте src/tasks/*.yaml
manifest_backup kube-controller-manager
node $CP "sed -i 's#^\(\s*\)- kube-controller-manager\$#\1- kube-controller-manger#' /etc/kubernetes/manifests/kube-controller-manager.yaml"
sleep 25
ns_fresh cm-lab
kubectl -n cm-lab create deployment cm-test --image=nginx:1.27-alpine --replicas=2 >/dev/null
