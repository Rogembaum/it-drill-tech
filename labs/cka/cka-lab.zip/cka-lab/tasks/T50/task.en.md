The Deployment `cm-test` in namespace `cm-lab` was created, but it has no Pods — not even a ReplicaSet exists.

Find and fix the faulty control plane component on node `cka-control-plane`.
