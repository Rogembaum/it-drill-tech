# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "команда в манифесте — kube-controller-manager" 'node $CP "grep -Eq \"^\s*- kube-controller-manager\$\" /etc/kubernetes/manifests/kube-controller-manager.yaml"'
chk "под kube-controller-manager Ready" 'kubectl -n kube-system wait --for=condition=Ready pod -l component=kube-controller-manager --timeout=60s'
chk "cm-test: 2 реплики Ready" 'rollout_wait cm-lab deploy/cm-test 120s'
