# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "PV не пересоздавался (тот же UID)" '[ "$(jp pv archive-pv "{.status.phase}")" = Bound ] && [ "$(jp pv archive-pv "{.metadata.uid}")" = "$(cat "$LAB/.state/archive-pv.uid")" ]'
chk "PV Bound к archive/archive-claim-2" '[ "$(jp pv archive-pv "{.status.phase}/{.spec.claimRef.namespace}/{.spec.claimRef.name}")" = Bound/archive/archive-claim-2 ]'
chk "reclaimPolicy осталась Retain" '[ "$(jp pv archive-pv "{.status.phase}")" = Bound ] && [ "$(jp pv archive-pv "{.spec.persistentVolumeReclaimPolicy}")" = Retain ]'
chk "PVC archive-claim-2 Bound" '[ "$(jp -n archive pvc archive-claim-2 "{.status.phase}")" = Bound ]'
