The PersistentVolume `archive-pv` was used by a PVC that has been deleted. The PV is now in phase `Released` and contains data that must be kept.

Make the PV reusable **without deleting or recreating it**, and bind it to a new PVC `archive-claim-2` (`1Gi`, `ReadWriteOnce`, storage class `manual`) in namespace `archive`.
