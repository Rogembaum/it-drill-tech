# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_drop archive
kubectl delete pv archive-pv --ignore-not-found --wait=false >/dev/null
rm -f "$LAB/.state/archive-pv.uid"
