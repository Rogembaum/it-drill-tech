# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl patch pv archive-pv --type=json -p '[{"op":"remove","path":"/spec/claimRef"}]'
cat <<'EOF' | kubectl apply -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: archive-claim-2
  namespace: archive
spec:
  storageClassName: manual
  accessModes: [ReadWriteOnce]
  resources: {requests: {storage: 1Gi}}
EOF
for i in $(seq 20); do [ "$(kubectl -n archive get pvc archive-claim-2 -o jsonpath='{.status.phase}')" = Bound ] && break; sleep 1; done
