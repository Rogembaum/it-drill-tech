# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh archive
kubectl delete pv archive-pv --ignore-not-found >/dev/null
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: v1
kind: PersistentVolume
metadata:
  name: archive-pv
spec:
  capacity: {storage: 1Gi}
  accessModes: [ReadWriteOnce]
  persistentVolumeReclaimPolicy: Retain
  storageClassName: manual
  hostPath: {path: /tmp/cka-archive, type: DirectoryOrCreate}
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: archive-claim
  namespace: archive
spec:
  storageClassName: manual
  accessModes: [ReadWriteOnce]
  resources: {requests: {storage: 1Gi}}
EOF
for i in $(seq 30); do [ "$(jp pv archive-pv '{.status.phase}')" = Bound ] && break; sleep 1; done
kubectl -n archive delete pvc archive-claim >/dev/null
for i in $(seq 30); do [ "$(jp pv archive-pv '{.status.phase}')" = Released ] && break; sleep 1; done
mkdir -p "$LAB/.state"; jp pv archive-pv '{.metadata.uid}' > "$LAB/.state/archive-pv.uid"
