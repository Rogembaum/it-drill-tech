PersistentVolume `archive-pv` использовался PVC, который удалили. PV в состоянии `Released`, на нём данные, которые нужно сохранить.

Сделайте PV снова доступным **без удаления и пересоздания** и свяжите его с новым PVC `archive-claim-2` (`1Gi`, `ReadWriteOnce`, класс `manual`) в `archive`.
