# сгенерировано src/build.py — правьте src/tasks/*.yaml
manifest_restore kube-apiserver
api_wait 60 || true
