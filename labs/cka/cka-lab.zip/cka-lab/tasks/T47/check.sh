# сгенерировано src/build.py — правьте src/tasks/*.yaml
api_wait 20
chk "--etcd-servers указывает на клиентский порт 2379" 'node $CP "grep -q -- --etcd-servers=https://127.0.0.1:2379 /etc/kubernetes/manifests/kube-apiserver.yaml"'
chk "API-сервер готов (/readyz)" 'kubectl get --raw=/readyz'
chk "все узлы Ready" '[ -z "$(kubectl get nodes --no-headers | grep -v " Ready ")" ]'
