After a migration of etcd, the kube-apiserver on node `cka-control-plane` stopped working and `kubectl` commands fail.

Investigate and fix the problem so that the cluster is fully functional again. Use the container runtime and kubelet tools on the node (`crictl`, `journalctl`) to find the cause.
