# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $CP "sed -i 's#--etcd-servers=https://127.0.0.1:2380#--etcd-servers=https://127.0.0.1:2379#' /etc/kubernetes/manifests/kube-apiserver.yaml"
sleep 20; api_wait 60
