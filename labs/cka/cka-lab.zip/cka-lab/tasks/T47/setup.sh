# сгенерировано src/build.py — правьте src/tasks/*.yaml
manifest_backup kube-apiserver
node $CP "sed -i 's#--etcd-servers=https://127.0.0.1:2379#--etcd-servers=https://127.0.0.1:2380#' /etc/kubernetes/manifests/kube-apiserver.yaml"
echo "  apiserver перезапускается со сломанной конфигурацией (~30–60 с)…"
sleep 30
