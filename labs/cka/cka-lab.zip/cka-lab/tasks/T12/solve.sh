# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $CP 'etcdutl snapshot restore /opt/cka/etcd-pre-change.db --data-dir /var/lib/etcd-restore >/dev/null 2>&1
sed -i "s#^\(\s*\)path: /var/lib/etcd\$#\1path: /var/lib/etcd-restore#" /etc/kubernetes/manifests/etcd.yaml'
sleep 20
for i in $(seq 60); do kubectl get --raw=/readyz >/dev/null 2>&1 && break; sleep 5; done
