# сгенерировано src/build.py — правьте src/tasks/*.yaml
for i in $(seq 30); do kubectl get --raw=/readyz >/dev/null 2>&1 && break; sleep 3; done
chk "манифест etcd использует /var/lib/etcd-restore" 'node $CP "grep -q /var/lib/etcd-restore /etc/kubernetes/manifests/etcd.yaml"'
chk "каталог /var/lib/etcd-restore содержит данные etcd" 'node $CP "test -d /var/lib/etcd-restore/member"'
chk "API-сервер отвечает (/readyz)" 'kubectl get --raw=/readyz'
chk "ConfigMap etcd-lab/marker восстановлен" 'kubectl -n etcd-lab get cm marker'
chk "ConfigMap etcd-lab/after-change отсутствует" '! kubectl -n etcd-lab get cm after-change'
chk "все узлы Ready" '[ -z "$(kubectl get nodes --no-headers | grep -v " Ready ")" ]'
