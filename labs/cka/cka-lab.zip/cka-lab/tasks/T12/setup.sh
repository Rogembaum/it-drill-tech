# сгенерировано src/build.py — правьте src/tasks/*.yaml
etcd_tools
ns_fresh etcd-lab
kubectl -n etcd-lab create configmap marker --from-literal=state=before >/dev/null
if node $CP 'grep -q /var/lib/etcd-restore /etc/kubernetes/manifests/etcd.yaml'; then
  echo "  etcd сейчас работает из /var/lib/etcd-restore — возвращаю /var/lib/etcd…"
  node $CP 'sed -i "s#path: /var/lib/etcd-restore#path: /var/lib/etcd#" /etc/kubernetes/manifests/etcd.yaml'
  sleep 25; api_wait 60
  ns_fresh etcd-lab
fi
node $CP 'rm -rf /var/lib/etcd-restore; mkdir -p /opt/cka
etcdctl --endpoints=https://127.0.0.1:2379 --cacert=/etc/kubernetes/pki/etcd/ca.crt \
  --cert=/etc/kubernetes/pki/etcd/server.crt --key=/etc/kubernetes/pki/etcd/server.key \
  snapshot save /opt/cka/etcd-pre-change.db >/dev/null 2>&1'
kubectl -n etcd-lab delete configmap marker >/dev/null
kubectl -n etcd-lab create configmap after-change --from-literal=state=after >/dev/null
