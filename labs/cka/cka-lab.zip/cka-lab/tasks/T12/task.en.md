A snapshot of etcd was taken before an accidental change and saved to `/opt/cka/etcd-pre-change.db` on node `cka-control-plane`.

Restore the cluster state from this snapshot:
- restore the data into the **new** directory `/var/lib/etcd-restore`,
- reconfigure the etcd static Pod to use it,
- make sure the cluster is healthy afterwards (all control plane Pods running, `kubectl` works).

After a correct restore, ConfigMap `marker` exists in namespace `etcd-lab` and ConfigMap `after-change` does not.
