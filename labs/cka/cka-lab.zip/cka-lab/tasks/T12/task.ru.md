Перед ошибочным изменением сделали снимок etcd: `/opt/cka/etcd-pre-change.db` на узле `cka-control-plane`.

Восстановите состояние кластера из снимка:
- разверните данные в **новый** каталог `/var/lib/etcd-restore`,
- перенастройте static pod etcd на этот каталог,
- убедитесь, что кластер здоров (поды control plane работают, `kubectl` отвечает).

После правильного восстановления в `etcd-lab` есть ConfigMap `marker` и нет ConfigMap `after-change`.
