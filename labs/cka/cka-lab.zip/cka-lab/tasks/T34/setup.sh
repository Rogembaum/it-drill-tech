# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh gw-demo
for v in v1 v2; do
  kubectl -n gw-demo create deployment store-$v --image=busybox:1.36 -- sh -c "mkdir -p /www && echo store-$v > /www/index.html && echo store-$v > /www/v2 && httpd -f -p 80 -h /www" >/dev/null
  kubectl -n gw-demo expose deployment store-$v --port=80 >/dev/null
done
rollout_wait gw-demo deploy/store-v1; rollout_wait gw-demo deploy/store-v2
