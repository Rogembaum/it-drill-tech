# сгенерировано src/build.py — правьте src/tasks/*.yaml
G=http://traefik.traefik.svc.cluster.local
cond() { jp -n gw-demo "$1" "{.status.conditions[?(@.type==\"$2\")].status}"; }
rcond() { jp -n gw-demo httproute store "{.status.parents[0].conditions[?(@.type==\"$1\")].status}"; }
chk "Gateway store-gw: класс traefik, listener http:8000 HTTP" '[ "$(jp -n gw-demo gateway store-gw "{.spec.gatewayClassName}/{.spec.listeners[0].name}/{.spec.listeners[0].port}/{.spec.listeners[0].protocol}")" = traefik/http/8000/HTTP ]'
chk "Gateway принят и запрограммирован" 'sleep 3; [ "$(cond gateway/store-gw Accepted)" = True ] && [ "$(cond gateway/store-gw Programmed)" = True ]'
chk "HTTPRoute store принят, ссылки разрешены" '[ "$(rcond Accepted)" = True ] && [ "$(rcond ResolvedRefs)" = True ]'
chk "веса 80/20 для v1/v2" 'jp -n gw-demo httproute store "{range .spec.rules[*].backendRefs[*]}{.name}={.weight} {end}" | grep -q "store-v1=80 store-v2=20"'
chk "/v2 всегда отвечает store-v2" 'for i in 1 2 3 4; do probe default "" "wget -qO- -T3 --header \"Host: store.cka.local\" $G/v2" | grep -q store-v2 || exit 1; done'
chk "/ отвечает store-v1 или store-v2" 'probe default "" "wget -qO- -T3 --header \"Host: store.cka.local\" $G/" | grep -q "store-v"'
probes_clean
