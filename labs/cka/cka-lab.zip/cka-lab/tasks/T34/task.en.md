In namespace `gw-demo`:
1. Create a Gateway `store-gw` using the GatewayClass `traefik` with one HTTP listener named `http` on port `8000` for the hostname `store.cka.local`. (The lab controller only accepts listeners on ports `8000`/`8443`.)
2. Create an HTTPRoute `store` attached to this Gateway for hostname `store.cka.local` that:
   - sends requests with the path prefix `/v2` to Service `store-v2` on port `80`,
   - splits all other requests: **80%** to Service `store-v1` and **20%** to Service `store-v2` (port `80`).
