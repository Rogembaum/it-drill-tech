# сгенерировано src/build.py — правьте src/tasks/*.yaml
cat <<'EOF' | kubectl apply -f -
apiVersion: gateway.networking.k8s.io/v1
kind: Gateway
metadata:
  name: store-gw
  namespace: gw-demo
spec:
  gatewayClassName: traefik
  listeners:
  - name: http
    protocol: HTTP
    port: 8000
    hostname: store.cka.local
---
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: store
  namespace: gw-demo
spec:
  parentRefs:
  - name: store-gw
  hostnames: ["store.cka.local"]
  rules:
  - matches:
    - path: {type: PathPrefix, value: /v2}
    backendRefs:
    - {name: store-v2, port: 80}
  - backendRefs:
    - {name: store-v1, port: 80, weight: 80}
    - {name: store-v2, port: 80, weight: 20}
EOF
sleep 5
