В `gw-demo`:
1. Создайте Gateway `store-gw` с GatewayClass `traefik` и одним HTTP-listener `http` на порту `8000` для хоста `store.cka.local` (контроллер лабы принимает только порты `8000`/`8443`).
2. Создайте HTTPRoute `store`, привязанный к этому Gateway, для хоста `store.cka.local`:
   - запросы с префиксом `/v2` → Service `store-v2`, порт `80`,
   - остальные делятся: **80%** → `store-v1`, **20%** → `store-v2` (порт `80`).
