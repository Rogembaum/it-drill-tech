# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_drop gw-demo
