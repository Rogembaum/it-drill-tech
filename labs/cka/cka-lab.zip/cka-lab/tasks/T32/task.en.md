In namespace `locked`:
1. Create a NetworkPolicy `default-deny-all` that denies **all ingress and egress** traffic for all Pods.
2. Create a NetworkPolicy `client-egress` that allows Pods with label `app=client` to:
   - send DNS queries (UDP and TCP port `53`) to any namespace,
   - connect to Pods with label `app=db` in the same namespace on TCP port `80`.
3. Create a NetworkPolicy `db-ingress` that allows ingress to Pods with label `app=db` from Pods with label `app=client` on TCP port `80`.

Clients must not be able to reach anything else (for example the Service `web` in namespace `outside`).
