# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh locked outside
kubectl -n locked create deployment db --image=nginx:1.27-alpine --port=80 >/dev/null
kubectl -n locked expose deployment db --port=80 >/dev/null
kubectl -n outside create deployment web --image=nginx:1.27-alpine --port=80 >/dev/null
kubectl -n outside expose deployment web --port=80 >/dev/null
kubectl -n locked run client --image=busybox:1.36 --labels=app=client --command -- sleep 36000 >/dev/null
rollout_wait locked deploy/db; rollout_wait outside deploy/web
