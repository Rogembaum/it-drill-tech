# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "default-deny-all: все поды, Ingress и Egress, без правил" '[ "$(jp -n locked netpol default-deny-all "{.spec.podSelector}|{.spec.policyTypes}|{.spec.ingress}{.spec.egress}")" = "{}|[\"Ingress\",\"Egress\"]|" ]'
chk "client: DNS работает" 'kubectl -n locked get netpol default-deny-all && probe locked "app=client" "nslookup db.locked.svc.cluster.local" | grep -q Address'
chk "client → db:80 работает" 'kubectl -n locked get netpol default-deny-all && http_ok locked "app=client" http://db.locked.svc.cluster.local'
chk "client → web.outside заблокировано" '! http_ok locked "app=client" http://web.outside.svc.cluster.local'
chk "под без метки client → db заблокировано" '! http_ok locked "app=other" http://db.locked.svc.cluster.local'
probes_clean
