В `locked`:
1. Создайте NetworkPolicy `default-deny-all`, запрещающую **весь входящий и исходящий** трафик всех подов.
2. Создайте `client-egress`: подам `app=client` разрешены
   - DNS-запросы (UDP и TCP `53`) в любой namespace,
   - соединения с подами `app=db` в этом же namespace на TCP `80`.
3. Создайте `db-ingress`: к подам `app=db` разрешён входящий трафик от `app=client` на TCP `80`.

Больше клиентам ничего не доступно (например, Service `web` в `outside`).
