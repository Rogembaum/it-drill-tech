A PersistentVolume `ledger-pv` already exists.

1. In namespace `ledger` create a PVC `ledger-pvc` that binds to this PV: request `250Mi`, access mode `ReadWriteOnce`, storage class `manual`.
2. Edit the Deployment manifest `~/cka/t38/ledger-deploy.yaml` so that the container mounts the PVC at `/var/lib/ledger`, then apply it.
3. Make sure the Deployment is running and the PVC is `Bound` to `ledger-pv`.
