PersistentVolume `ledger-pv` уже существует.

1. В `ledger` создайте PVC `ledger-pvc`, который свяжется с этим PV: `250Mi`, `ReadWriteOnce`, класс `manual`.
2. Отредактируйте манифест `~/cka/t38/ledger-deploy.yaml`, чтобы контейнер монтировал PVC в `/var/lib/ledger`, и примените его.
3. Убедитесь, что Deployment работает, а PVC в состоянии `Bound` с `ledger-pv`.
