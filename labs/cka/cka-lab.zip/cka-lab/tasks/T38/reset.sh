# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_drop ledger
kubectl delete pv ledger-pv --ignore-not-found --wait=false >/dev/null
