# сгенерировано src/build.py — правьте src/tasks/*.yaml
cat <<'EOF' | kubectl apply -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: ledger-pvc
  namespace: ledger
spec:
  storageClassName: manual
  accessModes: [ReadWriteOnce]
  resources:
    requests:
      storage: 250Mi
EOF
cat >> "$TD/ledger-deploy.yaml" <<'EOF'
        volumeMounts:
        - name: data
          mountPath: /var/lib/ledger
      volumes:
      - name: data
        persistentVolumeClaim:
          claimName: ledger-pvc
EOF
kubectl apply -f "$TD/ledger-deploy.yaml"
kubectl -n ledger rollout status deploy/ledger --timeout=90s
