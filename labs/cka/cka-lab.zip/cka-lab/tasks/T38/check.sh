# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "PVC ledger-pvc Bound к ledger-pv" '[ "$(jp -n ledger pvc ledger-pvc "{.status.phase}/{.spec.volumeName}")" = Bound/ledger-pv ]'
chk "PVC: класс manual, 250Mi, RWO" '[ "$(jp -n ledger pvc ledger-pvc "{.spec.storageClassName}/{.spec.resources.requests.storage}/{.spec.accessModes[0]}")" = manual/250Mi/ReadWriteOnce ]'
chk "Deployment монтирует ledger-pvc в /var/lib/ledger" '[ "$(jp -n ledger deploy ledger "{.spec.template.spec.volumes[?(@.persistentVolumeClaim.claimName==\"ledger-pvc\")].name}")" != "" ] && jp -n ledger deploy ledger "{.spec.template.spec.containers[0].volumeMounts[*].mountPath}" | grep -qw /var/lib/ledger'
chk "манифест в файле тоже исправлен" 'grep -q "claimName: *ledger-pvc" "$TD/ledger-deploy.yaml"'
chk "Deployment готов" 'rollout_wait ledger deploy/ledger 90s'
