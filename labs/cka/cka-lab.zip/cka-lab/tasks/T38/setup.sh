# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh ledger
kubectl delete pv ledger-pv --ignore-not-found >/dev/null
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: v1
kind: PersistentVolume
metadata:
  name: ledger-pv
spec:
  capacity:
    storage: 500Mi
  accessModes: [ReadWriteOnce]
  persistentVolumeReclaimPolicy: Retain
  storageClassName: manual
  hostPath:
    path: /tmp/cka-ledger
    type: DirectoryOrCreate
EOF
mkdir -p "$TD"
cat > "$TD/ledger-deploy.yaml" <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ledger
  namespace: ledger
spec:
  replicas: 1
  selector:
    matchLabels: {app: ledger}
  template:
    metadata:
      labels: {app: ledger}
    spec:
      containers:
      - name: ledger
        image: busybox:1.36
        command: ["sh", "-c", "while true; do date >> /var/lib/ledger/journal.log; sleep 10; done"]
EOF
