In namespace `batch` create a CronJob `cleanup` (image `busybox:1.36`, command `sh -c "echo cleaning; sleep 5"`) that:
- runs every 10 minutes,
- keeps 3 successful and 1 failed finished Jobs,
- terminates its Jobs after 60 seconds (`activeDeadlineSeconds`) and retries them at most 2 times,
- never starts a new Job while the previous one is still running.

Then immediately start a Job `cleanup-manual` from this CronJob and make sure it completes.
