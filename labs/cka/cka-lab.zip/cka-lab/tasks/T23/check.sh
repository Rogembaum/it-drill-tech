# сгенерировано src/build.py — правьте src/tasks/*.yaml
c() { jp -n batch cronjob cleanup "$1"; }
chk "расписание */10 * * * *" '[ "$(c "{.spec.schedule}")" = "*/10 * * * *" ]'
chk "история: 3 успешных, 1 неуспешное" '[ "$(c "{.spec.successfulJobsHistoryLimit}/{.spec.failedJobsHistoryLimit}")" = 3/1 ]'
chk "activeDeadlineSeconds=60, backoffLimit=2" '[ "$(c "{.spec.jobTemplate.spec.activeDeadlineSeconds}/{.spec.jobTemplate.spec.backoffLimit}")" = 60/2 ]'
chk "concurrencyPolicy=Forbid" '[ "$(c "{.spec.concurrencyPolicy}")" = Forbid ]'
chk "Job cleanup-manual создан из CronJob и завершён" '[ "$(jp -n batch job cleanup-manual "{.metadata.annotations.cronjob\.kubernetes\.io/instantiate}")" = manual ] && kubectl -n batch wait --for=condition=Complete job/cleanup-manual --timeout=60s'
