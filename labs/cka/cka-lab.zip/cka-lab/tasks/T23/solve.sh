# сгенерировано src/build.py — правьте src/tasks/*.yaml
cat <<'EOF' | kubectl apply -f -
apiVersion: batch/v1
kind: CronJob
metadata:
  name: cleanup
  namespace: batch
spec:
  schedule: "*/10 * * * *"
  concurrencyPolicy: Forbid
  successfulJobsHistoryLimit: 3
  failedJobsHistoryLimit: 1
  jobTemplate:
    spec:
      activeDeadlineSeconds: 60
      backoffLimit: 2
      template:
        spec:
          restartPolicy: Never
          containers:
          - name: cleanup
            image: busybox:1.36
            command: ["sh", "-c", "echo cleaning; sleep 5"]
EOF
kubectl -n batch create job cleanup-manual --from=cronjob/cleanup
kubectl -n batch wait --for=condition=Complete job/cleanup-manual --timeout=90s
