# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh checkout
cat <<'EOF' | kubectl apply -f - >/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: checkout
  namespace: checkout
spec:
  replicas: 3
  selector:
    matchLabels: {app: checkout}
  template:
    metadata:
      labels: {app: checkout}
    spec:
      containers:
      - name: web
        image: nginx:1.27-alpne
        ports:
        - containerPort: 80
        readinessProbe:
          httpGet: {path: /, port: 8080}
          periodSeconds: 3
EOF
