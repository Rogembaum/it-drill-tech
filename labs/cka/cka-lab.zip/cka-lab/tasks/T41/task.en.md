The Deployment `checkout` in namespace `checkout` has no available Pods.

Find and fix **all** problems so that all 3 replicas become `Ready`. The application listens on port `80` and must use the image `nginx:1.27-alpine`.
