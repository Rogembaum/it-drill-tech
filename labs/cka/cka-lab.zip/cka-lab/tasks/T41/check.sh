# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "образ nginx:1.27-alpine" '[ "$(jp -n checkout deploy checkout "{.spec.template.spec.containers[0].image}")" = nginx:1.27-alpine ]'
chk "readinessProbe проверяет порт 80" '[ "$(jp -n checkout deploy checkout "{.spec.template.spec.containers[0].readinessProbe.httpGet.port}")" = 80 ]'
chk "3 реплики Ready" 'rollout_wait checkout deploy/checkout 90s && [ "$(jp -n checkout deploy checkout "{.status.readyReplicas}")" = 3 ]'
