# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n checkout set image deploy/checkout web=nginx:1.27-alpine
kubectl -n checkout patch deploy checkout --type=json -p '[{"op":"replace","path":"/spec/template/spec/containers/0/readinessProbe/httpGet/port","value":80}]'
kubectl -n checkout rollout status deploy/checkout --timeout=90s
