Add the following probes to the container of the Deployment `frontend` in namespace `health`:
- a **readiness** probe: HTTP GET `/` on port `80`, initial delay `5s`, period `5s`;
- a **liveness** probe: TCP socket on port `80`, initial delay `10s`, period `15s`, failure threshold `3`.

Make sure the rollout completes.
