# сгенерировано src/build.py — правьте src/tasks/*.yaml
p() { jp -n health deploy frontend "$1"; }
chk "readiness: httpGet / :80" '[ "$(p "{.spec.template.spec.containers[0].readinessProbe.httpGet.path}:{.spec.template.spec.containers[0].readinessProbe.httpGet.port}")" = /:80 ]'
chk "readiness: delay 5, period 5" '[ "$(p "{.spec.template.spec.containers[0].readinessProbe.initialDelaySeconds}/{.spec.template.spec.containers[0].readinessProbe.periodSeconds}")" = 5/5 ]'
chk "liveness: tcpSocket :80" '[ "$(p "{.spec.template.spec.containers[0].livenessProbe.tcpSocket.port}")" = 80 ]'
chk "liveness: delay 10, period 15, failureThreshold 3" '[ "$(p "{.spec.template.spec.containers[0].livenessProbe.initialDelaySeconds}/{.spec.template.spec.containers[0].livenessProbe.periodSeconds}/{.spec.template.spec.containers[0].livenessProbe.failureThreshold}")" = 10/15/3 ]'
chk "обновление завершено, 2 реплики готовы" '[ -n "$(p "{.spec.template.spec.containers[0].readinessProbe}")" ] && rollout_wait health deploy/frontend 90s && [ "$(p "{.status.readyReplicas}")" = 2 ] && [ "$(p "{.status.updatedReplicas}")" = 2 ]'
