# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n health patch deploy frontend --type=json -p '[
  {"op":"add","path":"/spec/template/spec/containers/0/readinessProbe","value":{"httpGet":{"path":"/","port":80},"initialDelaySeconds":5,"periodSeconds":5}},
  {"op":"add","path":"/spec/template/spec/containers/0/livenessProbe","value":{"tcpSocket":{"port":80},"initialDelaySeconds":10,"periodSeconds":15,"failureThreshold":3}}]'
kubectl -n health rollout status deploy/frontend --timeout=90s
