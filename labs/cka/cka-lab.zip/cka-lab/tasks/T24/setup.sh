# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh health
kubectl -n health create deployment frontend --image=nginx:1.27-alpine --replicas=2 --port=80 >/dev/null
