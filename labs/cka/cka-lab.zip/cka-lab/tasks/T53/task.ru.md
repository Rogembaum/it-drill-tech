Под `rt-app` в `runtime` работает на `cka-worker`. На этом узле с помощью `crictl`:
1. Запишите ID контейнера пода в `/root/rt-app.id`.
2. Запишите логи контейнера в `/root/rt-app.log`.
3. Запишите вывод `crictl version` в `/root/runtime.txt`.
