# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh runtime
node $W1 'rm -f /root/rt-app.id /root/rt-app.log /root/runtime.txt'
kubectl -n runtime run rt-app --image=busybox:1.36 --overrides="{\"spec\":{\"nodeSelector\":{\"kubernetes.io/hostname\":\"$W1\"}}}" --command -- sh -c 'echo "rt-app started on $(hostname)"; sleep 36000' >/dev/null
kubectl -n runtime wait --for=condition=Ready pod/rt-app --timeout=90s >/dev/null
