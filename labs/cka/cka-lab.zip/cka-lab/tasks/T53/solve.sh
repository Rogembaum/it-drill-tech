# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $W1 'id=$(crictl ps --name rt-app -q | head -1); echo $id > /root/rt-app.id; crictl logs $id > /root/rt-app.log 2>&1; crictl version > /root/runtime.txt'
