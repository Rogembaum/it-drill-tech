# сгенерировано src/build.py — правьте src/tasks/*.yaml
id_ok() { nsh $W1 <<'EOF'
real=$(crictl ps --name rt-app -q | head -1)
got=$(tr -d ' \n' < /root/rt-app.id)
[ ${#got} -ge 12 ] && case "$real" in "$got"*) exit 0;; esac; exit 1
EOF
}
chk "rt-app.id — ID контейнера пода" id_ok
chk "rt-app.log — логи контейнера" 'node $W1 "grep -q \"rt-app started\" /root/rt-app.log"'
chk "runtime.txt — вывод crictl version (containerd)" 'node $W1 "grep -q RuntimeName /root/runtime.txt && grep -q containerd /root/runtime.txt"'
