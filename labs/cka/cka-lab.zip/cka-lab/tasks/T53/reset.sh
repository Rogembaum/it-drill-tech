# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $W1 'rm -f /root/rt-app.id /root/rt-app.log /root/runtime.txt' || true
ns_drop runtime
