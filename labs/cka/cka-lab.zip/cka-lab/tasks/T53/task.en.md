The Pod `rt-app` in namespace `runtime` runs on node `cka-worker`. On that node, using `crictl`:
1. Write the ID of the container of this Pod to `/root/rt-app.id`.
2. Write the logs of this container to `/root/rt-app.log`.
3. Write the output of `crictl version` (runtime name and version) to `/root/runtime.txt`.
