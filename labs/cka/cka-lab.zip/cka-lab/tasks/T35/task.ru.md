Приложение в `legacy-web` опубликовано через Ingress `secure` (HTTPS, хост `secure.cka.local`, секрет `secure-tls`). Перенесите его на Gateway API:

1. Создайте Gateway `secure-gw` (GatewayClass `traefik`) с HTTPS-listener `https` на порту `8443` для хоста `secure.cka.local`, который **терминирует** TLS сертификатом из секрета `secure-tls`.
2. Создайте HTTPRoute `secure`: `/` → Service `secure-app`, порт `80`, через этот listener.
3. Когда маршрут заработает, удалите Ingress `secure`.
