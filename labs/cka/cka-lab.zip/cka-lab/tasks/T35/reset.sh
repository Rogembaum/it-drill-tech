# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_drop legacy-web
