The application in namespace `legacy-web` is exposed by the Ingress `secure` (HTTPS, host `secure.cka.local`, TLS Secret `secure-tls`). Migrate it to the Gateway API:

1. Create a Gateway `secure-gw` (GatewayClass `traefik`) with an HTTPS listener named `https` on port `8443` for host `secure.cka.local` that **terminates** TLS using the existing Secret `secure-tls`.
2. Create an HTTPRoute `secure` that routes `/` to Service `secure-app` on port `80` through this listener.
3. After the new route works, delete the Ingress `secure`.
