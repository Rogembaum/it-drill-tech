# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh legacy-web
d=$(mktemp -d)
openssl req -x509 -nodes -newkey rsa:2048 -days 365 -subj "/CN=secure.cka.local" \
  -addext "subjectAltName=DNS:secure.cka.local" -keyout "$d/tls.key" -out "$d/tls.crt" 2>/dev/null
kubectl -n legacy-web create secret tls secure-tls --cert="$d/tls.crt" --key="$d/tls.key" >/dev/null
rm -rf "$d"
kubectl -n legacy-web create deployment secure-app --image=busybox:1.36 -- sh -c "mkdir -p /www && echo secure-ok > /www/index.html && httpd -f -p 80 -h /www" >/dev/null
kubectl -n legacy-web expose deployment secure-app --port=80 >/dev/null
kubectl -n legacy-web create ingress secure --class=traefik --rule="secure.cka.local/*=secure-app:80,tls=secure-tls" >/dev/null
rollout_wait legacy-web deploy/secure-app
