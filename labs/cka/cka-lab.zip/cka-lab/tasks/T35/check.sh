# сгенерировано src/build.py — правьте src/tasks/*.yaml
L='{.spec.listeners[?(@.name=="https")]'
cond() { jp -n legacy-web gateway secure-gw "{.status.conditions[?(@.type==\"$1\")].status}"; }
chk "listener https: HTTPS, 8443, secure.cka.local" '[ "$(jp -n legacy-web gateway secure-gw "$L.protocol}/$L.port}/$L.hostname}")" = HTTPS/8443/secure.cka.local ]'
chk "TLS Terminate с секретом secure-tls" '[ "$(jp -n legacy-web gateway secure-gw "$L.tls.certificateRefs[0].name}")" = secure-tls ] && [ "$(jp -n legacy-web gateway secure-gw "$L.tls.mode}")" != Passthrough ]'
chk "Gateway Accepted и Programmed" 'sleep 3; [ "$(cond Accepted)" = True ] && [ "$(cond Programmed)" = True ]'
chk "HTTPRoute secure принят и привязан к listener" '[ "$(jp -n legacy-web httproute secure "{.status.parents[0].conditions[?(@.type==\"Accepted\")].status}")" = True ] && [ "$(jp -n legacy-web gateway secure-gw "{.status.listeners[?(@.name==\"https\")].attachedRoutes}")" -ge 1 ]'
chk "backend: secure-app:80" '[ "$(jp -n legacy-web httproute secure "{.spec.rules[0].backendRefs[0].name}:{.spec.rules[0].backendRefs[0].port}")" = secure-app:80 ]'
chk "Ingress secure удалён" '! kubectl -n legacy-web get ingress secure'
