# сгенерировано src/build.py — правьте src/tasks/*.yaml
cat <<'EOF' | kubectl apply -f -
apiVersion: gateway.networking.k8s.io/v1
kind: Gateway
metadata:
  name: secure-gw
  namespace: legacy-web
spec:
  gatewayClassName: traefik
  listeners:
  - name: https
    protocol: HTTPS
    port: 8443
    hostname: secure.cka.local
    tls:
      mode: Terminate
      certificateRefs:
      - kind: Secret
        name: secure-tls
---
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: secure
  namespace: legacy-web
spec:
  parentRefs:
  - name: secure-gw
    sectionName: https
  hostnames: ["secure.cka.local"]
  rules:
  - matches:
    - path: {type: PathPrefix, value: /}
    backendRefs:
    - {name: secure-app, port: 80}
EOF
sleep 5
kubectl -n legacy-web delete ingress secure
