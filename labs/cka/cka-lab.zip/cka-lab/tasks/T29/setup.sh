# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh dns-lab
mkdir -p "$TD"; rm -f "$TD"/svc.txt "$TD"/pod.txt
kubectl -n dns-lab create deployment db --image=nginx:1.27-alpine --port=80 >/dev/null
kubectl -n dns-lab expose deployment db --port=80 >/dev/null
kubectl -n dns-lab run web --image=nginx:1.27-alpine >/dev/null
kubectl -n dns-lab wait --for=condition=Ready pod/web --timeout=90s >/dev/null
