# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_drop dns-lab
