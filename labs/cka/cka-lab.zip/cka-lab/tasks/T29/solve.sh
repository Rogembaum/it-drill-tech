# сгенерировано src/build.py — правьте src/tasks/*.yaml
pip=$(kubectl -n dns-lab get pod web -o jsonpath='{.status.podIP}')
kubectl -n dns-lab run dns-check --image=busybox:1.36 --restart=Never --command -- sleep 600 >/dev/null
kubectl -n dns-lab wait --for=condition=Ready pod/dns-check --timeout=60s >/dev/null
kubectl -n dns-lab exec dns-check -- nslookup db.dns-lab.svc.cluster.local > "$TD/svc.txt"
kubectl -n dns-lab exec dns-check -- nslookup "${pip//./-}.dns-lab.pod.cluster.local" > "$TD/pod.txt"
kubectl -n dns-lab delete pod dns-check --now >/dev/null
