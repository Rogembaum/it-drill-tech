# сгенерировано src/build.py — правьте src/tasks/*.yaml
sip=$(jp -n dns-lab svc db '{.spec.clusterIP}')
pip=$(jp -n dns-lab pod web '{.status.podIP}')
chk "svc.txt: запрос по FQDN db.dns-lab.svc.cluster.local" 'grep -q "db.dns-lab.svc.cluster.local" "$TD/svc.txt"'
chk "svc.txt: в ответе ClusterIP сервиса db" 'grep -q "Address:* *$sip" "$TD/svc.txt"'
chk "pod.txt: имя вида a-b-c-d.dns-lab.pod.cluster.local" 'grep -q "${pip//./-}.dns-lab.pod.cluster.local" "$TD/pod.txt"'
chk "pod.txt: в ответе IP пода web" 'grep -q "Address:* *$pip" "$TD/pod.txt"'
