In namespace `dns-lab`:
1. Using a temporary Pod `dns-check` with image `busybox:1.36`, look up the Service `db` by its **fully qualified domain name** and save the output of `nslookup` to `~/cka/t29/svc.txt`.
2. Look up the Pod `web` by its DNS name (derived from its IP address) and save the output of `nslookup` to `~/cka/t29/pod.txt`.
