# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $CP 'rm -f /root/join-worker.sh /root/apiserver-expiry.txt; openssl x509 -in /etc/kubernetes/pki/apiserver-kubelet-client.crt -noout -serial > /root/.cka-akc-serial'
