На узле `cka-control-plane`:
1. Создайте bootstrap-токен со сроком **2 часа** и запишите полную команду `kubeadm join` для рабочего узла в `/root/join-worker.sh`.
2. Запишите дату истечения сертификата `apiserver` (как её показывает kubeadm) в `/root/apiserver-expiry.txt`.
3. Перевыпустите сертификат `apiserver-kubelet-client` средствами kubeadm.
