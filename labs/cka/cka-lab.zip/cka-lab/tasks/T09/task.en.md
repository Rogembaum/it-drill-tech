On node `cka-control-plane`:
1. Create a new bootstrap token that is valid for **2 hours** and write the complete `kubeadm join` command for a worker node to `/root/join-worker.sh`.
2. Write the expiration date of the `apiserver` certificate, as reported by kubeadm, to `/root/apiserver-expiry.txt`.
3. Renew the certificate `apiserver-kubelet-client` using kubeadm.
