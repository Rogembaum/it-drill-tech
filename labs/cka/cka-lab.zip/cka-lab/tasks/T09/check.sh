# сгенерировано src/build.py — правьте src/tasks/*.yaml
join_ok() { nsh $CP <<'EOF'
f=/root/join-worker.sh
grep -q "kubeadm join" $f && grep -q -- "--token" $f && grep -q -- "--discovery-token-ca-cert-hash sha256:" $f
EOF
}
ttl_ok() { nsh $CP <<'EOF'
t=$(grep -o -- "--token [^ ]*" /root/join-worker.sh | awk '{print $2}')
ttl=$(kubeadm token list 2>/dev/null | awk -v t="$t" '$1==t{print $2}')
echo "$ttl" | grep -Eq '^(1h[0-9]*m?|2h0?m?|[0-9]+m)$'
EOF
}
exp_ok() { nsh $CP <<'EOF'
d=$(kubeadm certs check-expiration 2>/dev/null | awk '$1=="apiserver"{print $2, $3, $4}')
[ -n "$d" ] && grep -qF "$d" /root/apiserver-expiry.txt
EOF
}
renew_ok() { nsh $CP <<'EOF'
[ -s /root/.cka-akc-serial ] && [ "$(openssl x509 -in /etc/kubernetes/pki/apiserver-kubelet-client.crt -noout -serial)" != "$(cat /root/.cka-akc-serial)" ]
EOF
}
chk "join-worker.sh: kubeadm join с токеном и хэшем CA" join_ok
chk "токен существует и живёт не дольше 2 ч" ttl_ok
chk "apiserver-expiry.txt совпадает с kubeadm certs check-expiration" exp_ok
chk "apiserver-kubelet-client перевыпущен после старта задачи" renew_ok
