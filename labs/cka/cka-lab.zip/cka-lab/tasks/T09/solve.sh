# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $CP 'kubeadm token create --ttl 2h --print-join-command > /root/join-worker.sh
kubeadm certs check-expiration | awk "\$1==\"apiserver\"{print \$2, \$3, \$4, \$5}" > /root/apiserver-expiry.txt
kubeadm certs renew apiserver-kubelet-client'
