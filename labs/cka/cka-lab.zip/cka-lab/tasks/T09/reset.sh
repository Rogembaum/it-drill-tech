# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $CP 'rm -f /root/join-worker.sh /root/apiserver-expiry.txt /root/.cka-akc-serial'
