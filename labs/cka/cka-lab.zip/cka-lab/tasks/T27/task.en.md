Create a static Pod `static-web` (image `nginx:1.27-alpine`, container port `80`) on node `cka-worker`. It must be managed directly by the kubelet of that node.

Verify that its mirror Pod is visible through the API.
