# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl run static-web --image=nginx:1.27-alpine --port=80 --dry-run=client -o yaml | node $W1 'cat > /etc/kubernetes/manifests/static-web.yaml'
sleep 15
