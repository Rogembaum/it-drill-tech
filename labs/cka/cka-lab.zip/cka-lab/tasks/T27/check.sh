# сгенерировано src/build.py — правьте src/tasks/*.yaml
sp=$(node $W1 'awk "/staticPodPath/{print \$2}" /var/lib/kubelet/config.yaml')
chk "манифест лежит в staticPodPath узла" 'node $W1 "grep -l static-web ${sp:-/etc/kubernetes/manifests}/*.yaml"'
chk "зеркальный под static-web-$W1 Running" 'kubectl wait --for=condition=Ready pod/static-web-$W1 -n default --timeout=60s'
chk "под управляется узлом (ownerReference Node)" '[ "$(jp -n default pod static-web-$W1 "{.metadata.ownerReferences[0].kind}")" = Node ]'
