# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $W1 'rm -f /etc/kubernetes/manifests/static-web*.yaml'
