In namespace `config`:

1. Create a ConfigMap `app-config` with the key `APP_MODE=production` and a key `app.properties` whose content is taken from the file `~/cka/t15/app.properties`.
2. Create a generic Secret `db-cred` with `username=admin` and `password=S3cr3t!`.
3. Create a Deployment `api` (image `busybox:1.36`, command `sleep 3600`) that:
   - mounts the ConfigMap `app-config` as a volume at `/etc/app`,
   - exposes the Secret keys as environment variables `DB_USER` (from `username`) and `DB_PASS` (from `password`),
   - sets the environment variable `APP_MODE` from the ConfigMap key `APP_MODE`.
