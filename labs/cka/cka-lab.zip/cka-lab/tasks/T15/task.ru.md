В пространстве имён `config`:

1. Создайте ConfigMap `app-config` с ключом `APP_MODE=production` и ключом `app.properties` из файла `~/cka/t15/app.properties`.
2. Создайте Secret `db-cred` (generic): `username=admin`, `password=S3cr3t!`.
3. Создайте Deployment `api` (образ `busybox:1.36`, команда `sleep 3600`), который:
   - монтирует ConfigMap `app-config` томом в `/etc/app`,
   - получает переменные `DB_USER` (из `username`) и `DB_PASS` (из `password`) из секрета,
   - получает `APP_MODE` из ключа ConfigMap `APP_MODE`.
