# сгенерировано src/build.py — правьте src/tasks/*.yaml
pod() { kubectl -n config get pods -l app=api --field-selector=status.phase=Running -o jsonpath='{.items[0].metadata.name}'; }
ex() { kubectl -n config exec "$(pod)" -- "$@"; }
chk "ConfigMap: APP_MODE=production и app.properties из файла" '[ "$(jp -n config cm app-config "{.data.APP_MODE}")" = production ] && jp -n config cm app-config "{.data.app\.properties}" | grep -q "cache.size=256"'
chk "Secret db-cred: admin / S3cr3t!" '[ "$(jp -n config secret db-cred "{.data.username}" | base64 -d)" = admin ] && [ "$(jp -n config secret db-cred "{.data.password}" | base64 -d)" = "S3cr3t!" ]'
chk "Deployment api готов" 'rollout_wait config deploy/api 90s'
chk "в поде DB_USER=admin и DB_PASS=S3cr3t!" '[ "$(ex printenv DB_USER)" = admin ] && [ "$(ex printenv DB_PASS)" = "S3cr3t!" ]'
chk "в поде APP_MODE=production" '[ "$(ex printenv APP_MODE)" = production ]'
chk "файл /etc/app/app.properties смонтирован" 'ex cat /etc/app/app.properties | grep -q log.level=info'
