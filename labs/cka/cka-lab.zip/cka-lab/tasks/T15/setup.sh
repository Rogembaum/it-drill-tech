# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh config
mkdir -p "$TD"
printf 'log.level=info\ncache.size=256\n' > "$TD/app.properties"
