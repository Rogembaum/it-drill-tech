# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl -n config create configmap app-config --from-literal=APP_MODE=production --from-file=app.properties="$TD/app.properties"
kubectl -n config create secret generic db-cred --from-literal=username=admin --from-literal=password='S3cr3t!'
cat <<'EOF' | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api
  namespace: config
spec:
  replicas: 1
  selector:
    matchLabels: {app: api}
  template:
    metadata:
      labels: {app: api}
    spec:
      containers:
      - name: api
        image: busybox:1.36
        command: ["sleep", "3600"]
        env:
        - name: DB_USER
          valueFrom: {secretKeyRef: {name: db-cred, key: username}}
        - name: DB_PASS
          valueFrom: {secretKeyRef: {name: db-cred, key: password}}
        - name: APP_MODE
          valueFrom: {configMapKeyRef: {name: app-config, key: APP_MODE}}
        volumeMounts:
        - name: cfg
          mountPath: /etc/app
      volumes:
      - name: cfg
        configMap: {name: app-config}
EOF
kubectl -n config rollout status deploy/api --timeout=90s
