1. Поставьте узлу `cka-worker` метку `disktype=ssd`.
2. В `sched` создайте Deployment `cache` (образ `nginx:1.27-alpine`, 2 реплики), поды которого:
   - **обязательно** размещаются на узлах с `disktype=ssd` (через node affinity, не `nodeSelector`),
   - **предпочитают** узлы с `zone=eu-1` (вес `50`).
