1. Label the node `cka-worker` with `disktype=ssd`.
2. In namespace `sched` create a Deployment `cache` (image `nginx:1.27-alpine`, 2 replicas) whose Pods:
   - **must** run on nodes labeled `disktype=ssd` (use node affinity, not `nodeSelector`),
   - **prefer** nodes labeled `zone=eu-1` (weight `50`).
