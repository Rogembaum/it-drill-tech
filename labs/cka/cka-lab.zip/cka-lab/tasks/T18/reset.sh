# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl label nodes --all disktype- zone- >/dev/null 2>&1 || true
ns_drop sched
