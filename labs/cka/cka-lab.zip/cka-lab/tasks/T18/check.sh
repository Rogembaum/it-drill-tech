# сгенерировано src/build.py — правьте src/tasks/*.yaml
a() { jp -n sched deploy cache "$1"; }
chk "у $W1 метка disktype=ssd" '[ "$(jp node $W1 "{.metadata.labels.disktype}")" = ssd ]'
chk "required: disktype In [ssd]" '[ "$(a "{.spec.template.spec.affinity.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution.nodeSelectorTerms[0].matchExpressions[0].key}/{.spec.template.spec.affinity.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution.nodeSelectorTerms[0].matchExpressions[0].values[0]}")" = disktype/ssd ]'
chk "preferred: zone=eu-1, weight 50" '[ "$(a "{.spec.template.spec.affinity.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].weight}/{.spec.template.spec.affinity.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].preference.matchExpressions[0].values[0]}")" = 50/eu-1 ]'
chk "nodeSelector не используется" 'kubectl -n sched get deploy cache && [ -z "$(a "{.spec.template.spec.nodeSelector}")" ]'
chk "2 пода работают на $W1" 'rollout_wait sched deploy/cache 90s && [ "$(kubectl -n sched get pods -l app=cache -o jsonpath="{.items[*].spec.nodeName}" | tr " " "\n" | grep -cx $W1)" = 2 ]'
