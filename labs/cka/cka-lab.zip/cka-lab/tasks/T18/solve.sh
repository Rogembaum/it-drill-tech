# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl label node $W1 disktype=ssd --overwrite
cat <<'EOF' | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cache
  namespace: sched
spec:
  replicas: 2
  selector:
    matchLabels: {app: cache}
  template:
    metadata:
      labels: {app: cache}
    spec:
      affinity:
        nodeAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            nodeSelectorTerms:
            - matchExpressions:
              - {key: disktype, operator: In, values: [ssd]}
          preferredDuringSchedulingIgnoredDuringExecution:
          - weight: 50
            preference:
              matchExpressions:
              - {key: zone, operator: In, values: [eu-1]}
      containers:
      - name: nginx
        image: nginx:1.27-alpine
EOF
kubectl -n sched rollout status deploy/cache --timeout=90s
