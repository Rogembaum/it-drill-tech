# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh sched
kubectl label nodes --all disktype- zone- >/dev/null 2>&1 || true
