# сгенерировано src/build.py — правьте src/tasks/*.yaml
etcd_tools
node $CP 'rm -rf /var/lib/backup'
