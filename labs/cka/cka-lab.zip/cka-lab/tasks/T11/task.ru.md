На узле `cka-control-plane` создайте снимок etcd (`https://127.0.0.1:2379`) в файле `/var/lib/backup/etcd-snapshot.db`.

Сертификаты в `/etc/kubernetes/pki/etcd/`: CA `ca.crt`, клиентский сертификат `server.crt`, ключ `server.key`.

Проверьте снимок утилитой `etcdutl` и сохраните его статус в табличном виде в `/var/lib/backup/snapshot-status.txt`.
