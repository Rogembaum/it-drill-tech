# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "снимок существует и не пуст" 'node $CP "test -s /var/lib/backup/etcd-snapshot.db"'
chk "снимок корректен (etcdutl snapshot status)" 'node $CP "etcdutl snapshot status /var/lib/backup/etcd-snapshot.db"'
chk "snapshot-status.txt — таблица со статусом" 'node $CP "grep -q HASH /var/lib/backup/snapshot-status.txt && grep -q \"|\" /var/lib/backup/snapshot-status.txt"'
