# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $CP 'mkdir -p /var/lib/backup
etcdctl --endpoints=https://127.0.0.1:2379 \
  --cacert=/etc/kubernetes/pki/etcd/ca.crt --cert=/etc/kubernetes/pki/etcd/server.crt --key=/etc/kubernetes/pki/etcd/server.key \
  snapshot save /var/lib/backup/etcd-snapshot.db
etcdutl snapshot status /var/lib/backup/etcd-snapshot.db -w table > /var/lib/backup/snapshot-status.txt'
