On node `cka-control-plane` create a snapshot of the etcd instance running at `https://127.0.0.1:2379` and save it to `/var/lib/backup/etcd-snapshot.db`.

Use the certificates in `/etc/kubernetes/pki/etcd/`: CA `ca.crt`, client certificate `server.crt`, client key `server.key`.

Then verify the snapshot with `etcdutl` and save its status in table format to `/var/lib/backup/snapshot-status.txt`.
