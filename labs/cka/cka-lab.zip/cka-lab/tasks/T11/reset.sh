# сгенерировано src/build.py — правьте src/tasks/*.yaml
node $CP 'rm -rf /var/lib/backup'
