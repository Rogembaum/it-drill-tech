1. Taint the node `cka-worker2` with `dedicated=monitoring:NoSchedule`.
2. In namespace `monitoring` create a Pod `agent` (image `busybox:1.36`, command `sleep 3600`) that tolerates this taint and runs on `cka-worker2` (use a `nodeSelector` on the label `kubernetes.io/hostname`).
