# сгенерировано src/build.py — правьте src/tasks/*.yaml
ns_fresh monitoring
kubectl taint nodes --all dedicated- >/dev/null 2>&1 || true
