# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl taint node $W2 dedicated=monitoring:NoSchedule --overwrite
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Pod
metadata:
  name: agent
  namespace: monitoring
spec:
  nodeSelector:
    kubernetes.io/hostname: $W2
  tolerations:
  - key: dedicated
    operator: Equal
    value: monitoring
    effect: NoSchedule
  containers:
  - name: agent
    image: busybox:1.36
    command: ["sleep", "3600"]
EOF
kubectl -n monitoring wait --for=condition=Ready pod/agent --timeout=60s
