1. Поставьте на узел `cka-worker2` taint `dedicated=monitoring:NoSchedule`.
2. В `monitoring` создайте Pod `agent` (образ `busybox:1.36`, команда `sleep 3600`), который допускает этот taint и работает на `cka-worker2` (через `nodeSelector` по метке `kubernetes.io/hostname`).
