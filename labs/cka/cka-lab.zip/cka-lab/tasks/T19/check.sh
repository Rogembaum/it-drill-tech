# сгенерировано src/build.py — правьте src/tasks/*.yaml
chk "taint dedicated=monitoring:NoSchedule на $W2" 'jp node $W2 "{range .spec.taints[*]}{.key}={.value}:{.effect}{\"\\n\"}{end}" | grep -qx "dedicated=monitoring:NoSchedule"'
chk "у пода agent есть toleration для этого taint" 'jp -n monitoring pod agent "{range .spec.tolerations[*]}{.key}|{.value}|{.effect}|{.operator}{\"\\n\"}{end}" | grep -Eq "^dedicated\|(monitoring)?\|(NoSchedule)?\|(Equal|Exists)?$"'
chk "nodeSelector kubernetes.io/hostname=$W2" '[ "$(jp -n monitoring pod agent "{.spec.nodeSelector.kubernetes\.io/hostname}")" = $W2 ]'
chk "под agent Running на $W2" 'kubectl -n monitoring wait --for=condition=Ready pod/agent --timeout=60s && [ "$(jp -n monitoring pod agent "{.spec.nodeName}")" = $W2 ]'
