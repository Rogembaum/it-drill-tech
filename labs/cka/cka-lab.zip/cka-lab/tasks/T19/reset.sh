# сгенерировано src/build.py — правьте src/tasks/*.yaml
kubectl taint nodes --all dedicated- >/dev/null 2>&1 || true
ns_drop monitoring
