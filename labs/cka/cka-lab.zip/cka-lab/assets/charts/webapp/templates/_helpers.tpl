{{- define "webapp.fullname" -}}
{{- printf "%s-webapp" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "webapp.labels" -}}
app.kubernetes.io/name: webapp
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}
