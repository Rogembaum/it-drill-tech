# shellcheck shell=bash
# Общие функции для setup/check/solve/reset сценариев.
# Подключается раннером ./cka; напрямую запускать не нужно.

: "${CKA_CLUSTER:=cka}"
: "${LAB:=$HOME/cka}"
CP="${CKA_CLUSTER}-control-plane"
W1="${CKA_CLUSTER}-worker"
W2="${CKA_CLUSTER}-worker2"
export CP W1 W2 LAB

k() { kubectl "$@"; }

# Выполнить команду внутри узла kind (аналог ssh на экзамене)
node() { local n=$1; shift; docker exec -i "$n" bash -c "$*"; }
# Выполнить скрипт со stdin внутри узла: nsh <узел> <<'EOF' … EOF
nsh() { docker exec -i "$1" bash -s; }

# Скопировать etcdctl/etcdutl на control plane из образа etcd (на экзамене они уже установлены)
etcd_tools() {
  nsh "$CP" <<'EOF'
for b in etcdctl etcdutl; do
  command -v $b >/dev/null 2>&1 && continue
  for p in /proc/[0-9]*; do
    [ "$(cat $p/comm 2>/dev/null)" = etcd ] || continue
    f=$(find $p/root/usr/local/bin $p/root/usr/bin $p/root/bin -maxdepth 1 -name $b 2>/dev/null | head -1)
    [ -n "$f" ] && cp "$f" /usr/local/bin/$b && chmod +x /usr/local/bin/$b && break
  done
done
command -v etcdctl >/dev/null && command -v etcdutl >/dev/null
EOF
}

# Сохранить копию манифеста static pod перед поломкой (для reset)
manifest_backup() { node "$CP" "cp -n /etc/kubernetes/manifests/$1.yaml /root/.cka-$1.yaml.orig"; }
manifest_restore() { node "$CP" "[ -f /root/.cka-$1.yaml.orig ] && cp /root/.cka-$1.yaml.orig /etc/kubernetes/manifests/$1.yaml && rm -f /root/.cka-$1.yaml.orig || true"; }
api_wait() { local i; for i in $(seq "${1:-60}"); do kubectl get --raw=/readyz >/dev/null 2>&1 && return 0; sleep 3; done; return 1; }

# Пересоздать пространства имён
ns_fresh() {
  local n
  for n in "$@"; do
    kubectl delete ns "$n" --ignore-not-found --wait=true --timeout=180s >/dev/null 2>&1
    kubectl create ns "$n" >/dev/null
  done
}
ns_drop() {
  local n
  for n in "$@"; do kubectl delete ns "$n" --ignore-not-found --wait=false >/dev/null 2>&1; done
}

# Дождаться готовности ресурса (deploy/ds/sts)
rollout_wait() { kubectl -n "$1" rollout status "$2" --timeout="${3:-120s}" >/dev/null 2>&1; }

# jsonpath: jp <аргументы kubectl get…> '<jsonpath>'
jp() { local p="${*: -1}"; kubectl get "${@:1:$#-1}" -o jsonpath="$p" 2>/dev/null; }

# ---------- проверки ----------
P=0; T=0
chk() {
  local d=$1; shift
  if ( eval "$*" ) >/dev/null 2>&1; then printf '  \033[32m✔\033[0m %s\n' "$d"; P=$((P+1));
  else printf '  \033[31m✘\033[0m %s\n' "$d"; fi
  T=$((T+1))
}
result() { echo "RESULT ${TASK_ID:-T??} $P/$T"; }

# Пробный под: probe <ns> "<labels>" "<команда>"
# Создаёт (или переиспользует) busybox-под с нужными метками и выполняет команду внутри.
probe() {
  local ns=$1 labels=$2 cmd=$3 h name lb
  h=$(printf '%s' "$ns|$labels" | cksum | cut -d' ' -f1)
  name="cka-probe-${h:0:8}"
  lb="cka-probe=1"; [ -n "$labels" ] && lb="$lb,$labels"
  if ! kubectl -n "$ns" get pod "$name" >/dev/null 2>&1; then
    kubectl -n "$ns" run "$name" --image=busybox:1.36 --labels="$lb" --restart=Never \
      --overrides='{"spec":{"terminationGracePeriodSeconds":0}}' --command -- sleep 3600 >/dev/null 2>&1
  fi
  kubectl -n "$ns" wait --for=condition=Ready "pod/$name" --timeout=90s >/dev/null 2>&1 || return 1
  kubectl -n "$ns" exec "$name" -- sh -c "$cmd" 2>/dev/null
}
probes_clean() { kubectl delete pod -A -l cka-probe=1 --wait=false >/dev/null 2>&1 || true; }
# HTTP-запрос из кластера: http_ok <ns> "<labels>" <url> [ожидаемая подстрока]
http_ok() {
  local out; out=$(probe "$1" "$2" "wget -qO- -T 3 $3") || return 1
  [ -z "${4:-}" ] || printf '%s' "$out" | grep -q -- "$4"
}
